package jp.co.crawler.tools

import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.SparkContext._
import org.apache.spark.rdd.RDD
import it.nerdammer.spark.hbase._
import org.apache.nutch.util.TableUtil
import org.apache.nutch.util.URLUtil
import java.net._
import scala.sys.process._
import java.io._
import scala.io._
import it.nerdammer.spark.hbase.conversion._

object FetchSummary {
  implicit def byteReader: FieldReader[Array[Byte]] = new SingleColumnConcreteFieldReader[Array[Byte]]{
     def columnMap(cols: Array[Byte]) : Array[Byte] = cols
  }
  def main(args: Array[String]): Unit = {
    val sc = new SparkContext(new SparkConf().setAppName("FetchSummary"))
    val hbaseRDD = sc.hbaseTable[(String, Option[Array[Byte]])]("webpage")
        .select("cnt")
        .inColumnFamily("f")
    hbaseRDD.foreach( t => {
        val url = TableUtil.unreverseUrl(t._1)
        val f = new File("/home/nutch/webpage/" + TableUtil.unreverseUrl(t._1).replaceAll("/","_"))
        val content = getEncode(t._2.get)
        val bw = new BufferedWriter(new FileWriter(f))
        bw.write(content)
        bw.close()
    })
  }
  def getEncode(bytes: Array[Byte]): String = {
      new String (bytes, "UTF-8")
  }
  def urltoDomain(url: String): String = {
      val reveseurl = TableUtil.unreverseUrl(url)
      val dom = new URL(reveseurl)
      dom.getHost
  }
}
