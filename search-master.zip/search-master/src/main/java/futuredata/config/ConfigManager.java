package futuredata.config;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

public class ConfigManager {

    @SuppressWarnings("unchecked")
    public static <T> T converyXmlToJavaBean(String filePath, Class<T> c) {

        T t = null;
        try {

            JAXBContext context = JAXBContext.newInstance(c);
            Unmarshaller unmarshaller = context.createUnmarshaller();
            t = (T) unmarshaller.unmarshal(new File(filePath));
        } catch (Exception e) {

            e.printStackTrace();
        }
        return t;
    }
    
    public static Config extendUrlOfConfig(Config config) throws CloneNotSupportedException {
        
        Config returnConfig = new Config();
        List<HttpConfig> httpConFigList = new ArrayList<HttpConfig>();
        returnConfig.setHttpConfigList(httpConFigList);
        
        for (HttpConfig httpConfig : config.getHttpConfigList()){
            
            String httpUrl = httpConfig.getHttpUrl();
            
            if (httpUrl.indexOf("edinet-fsa") > -1) {
                
                for (int i = 1; i <= 10; i++) {
                    
                    String url = httpUrl.replace("idx=0", "idx="+i);
                    
                    HttpConfig newHttpConfig = new HttpConfig();
                    newHttpConfig = (HttpConfig)httpConfig.clone();
                    newHttpConfig.setHttpUrl(url);
                    newHttpConfig.setSaveName(httpConfig.getSaveName() + i);
                    
                    httpConFigList.add(newHttpConfig);
                }
            } else {
                httpConFigList.add((HttpConfig)httpConfig.clone());
            }
        }

        return returnConfig;
    }
    
}
