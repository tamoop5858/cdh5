#### 開発用jarの作成
```shell
mvn clean package -P dev -DskipTests
```

#### 本番（デモ）用jarファイルの作成
```shell
mvn clean package -P production -DskipTests
```

#### Storm app execution command ####
storm jar <PATH_TO_YOUR_JAR> MainTopology


#### Storm app log ####
/var/log/storm/logs/workers-artifacts/