package com.iot.platform.storm.bolt.collection;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.apache.storm.trident.operation.BaseFunction;
import org.apache.storm.trident.operation.TridentCollector;
import org.apache.storm.trident.operation.TridentOperationContext;
import org.apache.storm.trident.tuple.TridentTuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.iot.platform.storm.define.gson.SchemaDto;
import com.iot.platform.storm.helper.SpringContext;
import com.iot.platform.storm.service.HBaseService;
import com.iot.platform.storm.service.StringService;


public class HBRowKeyMake extends BaseFunction {

    HBaseService hbase = null;
    Logger logger = null;

    @Override
    public void prepare(Map conf, TridentOperationContext context) {
        try {
            hbase = (HBaseService)SpringContext.getBean("HBaseService");
            logger = LoggerFactory.getLogger(HBRowKeyMake.class);
        }
        catch (Exception e) {
            logger.warn("[iot] HBRowKeyMake Prepare Exception!");
            e.printStackTrace();
        }
    }

    @Override
    public void execute(TridentTuple tuple, TridentCollector collector) {

        HashMap<String, String> data = StringService.getParsedResult(tuple.getStringByField("value"));
        HashMap<String, String> rt = new HashMap<String, String>();

        //Hbaseからスキーマ情報を取得する
        String rowKey = "";
        String json = "";

        try {

            String collection = data.get("org") + "_" + data.get("collection");
            rt = hbase.get("schema", collection);
            json = rt.get("col:json");

            SchemaDto schema = StringService.getSchma(json);

            //rowKeyの作成
            if (schema.getPrimaryKeys().size() > 0) {
                for (int i = 0; i < schema.getPrimaryKeys().size(); i++) {
                    rowKey = rowKey + String.valueOf(data.get(schema.getPrimaryKeys().get(i)));
                }
                rowKey =(String.valueOf(rowKey.hashCode()));
            } else {
                rowKey = UUID.randomUUID().toString();
            }

            logger.info("[iot] HBRowKeyMake Success [" + rowKey + "]");

        } catch (Exception e) {
            logger.warn("[iot] HBRowKeyMake Exception!");
            e.printStackTrace();
        }
        collector.emit(new Values(rowKey,json));
    }
}
