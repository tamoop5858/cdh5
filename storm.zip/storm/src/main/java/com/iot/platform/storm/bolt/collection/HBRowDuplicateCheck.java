package com.iot.platform.storm.bolt.collection;

import java.util.HashMap;
import java.util.Map;

import org.apache.storm.trident.operation.TridentOperationContext;
import org.apache.storm.trident.operation.impl.TrueFilter;
import org.apache.storm.trident.tuple.TridentTuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.iot.platform.storm.helper.SpringContext;
import com.iot.platform.storm.service.HBaseService;
import com.iot.platform.storm.service.StringService;

public class HBRowDuplicateCheck extends TrueFilter {

    HBaseService hbase = null;
    Logger logger = null;

    @Override
    public void prepare(Map conf, TridentOperationContext context) {
        try {
            hbase = (HBaseService)SpringContext.getBean("HBaseService");
            logger = LoggerFactory.getLogger(HBRowDuplicateCheck.class);
        }
        catch (Exception e) {
            logger.warn("[iot] HBRowDuplicateCheck Prepare Exception!");
            e.printStackTrace();
        }
    }

    @Override
    public boolean isKeep(TridentTuple tuple) {

        HashMap<String, String> data = StringService.getParsedResult(tuple.getStringByField("value"));
        String rowkey = tuple.getStringByField("rowKey");

        HashMap<String, String> rt = new HashMap<String, String>();
        String collection = StringService.getHBaseCollectionName(data.get("org"),data.get("collection"));

        try {
            rt = hbase.get(collection, rowkey);
        } catch (Exception e) {
            logger.warn("[iot] HBRowDuplicateCheck Exception!");
            e.printStackTrace();
        }

        logger.info("[iot] HBRowDuplicateCheck Success");

        if (rt.size() == 0) {
            return true;
        }
        else{
            logger.error("[iot] RowkeyCheckError:collection_" + collection + "rowkey[" + rowkey + "]");
            return false;
        }
    }
}
