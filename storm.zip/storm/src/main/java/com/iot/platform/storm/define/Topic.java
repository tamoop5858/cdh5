package com.iot.platform.storm.define;
/**
 *
 */
public enum Topic {
    /** スキーマ情報 */
    TOPIC_SCHEMA("a"),
    /** 収集データ情報 */
    TOPIC_COLLECTION("b");

    private String name;
    /**
     * @param name
     */
    private Topic(String name) {
        this.name = name;
    }


    public static Topic getByName(String name) {
        for (Topic e : values()) {
            if (e.name.equals(name))
                return e;
        }
        return null;
    }

    public String getName() {
        return this.name;
    }
}
