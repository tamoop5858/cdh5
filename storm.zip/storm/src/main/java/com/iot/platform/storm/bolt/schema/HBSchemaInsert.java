package com.iot.platform.storm.bolt.schema;

import java.util.HashMap;
import java.util.Map;

import org.apache.storm.trident.operation.BaseFunction;
import org.apache.storm.trident.operation.TridentCollector;
import org.apache.storm.trident.operation.TridentOperationContext;
import org.apache.storm.trident.tuple.TridentTuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.iot.platform.storm.define.gson.SchemaDto;
import com.iot.platform.storm.helper.SpringContext;
import com.iot.platform.storm.service.HBaseService;
import com.iot.platform.storm.service.StringService;

public class HBSchemaInsert extends BaseFunction {

    HBaseService hbase = null;
    Logger logger = null;

    @Override
    public void prepare(Map conf, TridentOperationContext context) {
        try {
            hbase = (HBaseService)SpringContext.getBean("HBaseService");
            logger = LoggerFactory.getLogger(HBSchemaInsert.class);
        }
        catch (Exception e) {
            logger.warn("[iot] HBSchemaInsert Prepare Exception!");
            e.printStackTrace();
        }
    }

    @Override
    public void execute(TridentTuple tuple, TridentCollector collector) {

        SchemaDto schema = StringService.getSchma(tuple.getStringByField("value"));
        String collection = schema.getOrgCollection();

        try {

            HashMap<String, String> hm = new HashMap<String, String>();
            hm.put("desc", schema.getDesc());
            hm.put("primary_keys", schema.getPrimaryKeys().toString());
            hm.put("index_keys", schema.getIndexKeys().toString());
            hm.put("fields", StringService.getJson(schema.getFields()));
            hm.put("json", tuple.getStringByField("value"));
            hbase.put("schema", collection, "col", hm);

        } catch (Exception e) {
            logger.warn("[iot] HBSchemaInsert Exception!");
            e.printStackTrace();
        }

        collector.emit(new Values());

    }
}
