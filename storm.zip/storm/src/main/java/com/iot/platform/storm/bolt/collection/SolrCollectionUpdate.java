package com.iot.platform.storm.bolt.collection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.storm.trident.operation.BaseFunction;
import org.apache.storm.trident.operation.TridentCollector;
import org.apache.storm.trident.operation.TridentOperationContext;
import org.apache.storm.trident.tuple.TridentTuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.iot.platform.storm.define.gson.SchemaDto;
import com.iot.platform.storm.helper.SpringContext;
import com.iot.platform.storm.service.SolrService;
import com.iot.platform.storm.service.StringService;


public class SolrCollectionUpdate extends BaseFunction {

    SolrService solr = null;
    Logger logger = null;

    @Override
    public void prepare(Map conf, TridentOperationContext context) {
        try {
            solr = (SolrService)SpringContext.getBean("SolrService");
            logger = LoggerFactory.getLogger(SolrCollectionUpdate.class);
        }
        catch (Exception e) {
            logger.warn("[iot] SolrCollectionUpdate Prepare Exception!");
            e.printStackTrace();
        }
    }

    @Override
    public void execute(TridentTuple tuple, TridentCollector collector) {

        HashMap<String, String> data = StringService.getParsedResult(tuple.getStringByField("value"));
        String rowkey = tuple.getStringByField("rowKey");
        SchemaDto schema = StringService.getSchma(tuple.getStringByField("json"));

        try {
            //Solrに検索項目を登録
            if (schema.getIndexKeys().size() > 0) {

                //検索項目のみに絞り込み
                HashMap<String, String> indexList = new HashMap<String, String>();
                Iterator<Map.Entry<String, String>> it = data.entrySet().iterator();
                while (it.hasNext()) {
                    Map.Entry<String, String> entry = it.next();
                    if (schema.getIndexKeys().contains(entry.getKey())) {
                        String key = StringService.getSolrFieldName(entry.getKey());
                        String value = StringService.getArrayValue(entry.getKey(), entry.getValue(),schema);
                        indexList.put(key, value);
                    }
                }
                indexList.put("comm_hb_rowkey", rowkey);

                solr.addDoc(schema.getOrgCollection(), indexList);
            }

            logger.info("[iot] SolrCollectionUpdate Success");

        } catch (Exception e) {
            logger.warn("[iot] SolrCollectionUpdate Exception!");
            e.printStackTrace();
        }
        collector.emit(new Values());
    }
}
