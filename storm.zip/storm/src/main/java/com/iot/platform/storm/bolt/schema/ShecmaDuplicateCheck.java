package com.iot.platform.storm.bolt.schema;

import java.util.HashMap;
import java.util.Map;

import org.apache.storm.trident.operation.TridentOperationContext;
import org.apache.storm.trident.operation.impl.TrueFilter;
import org.apache.storm.trident.tuple.TridentTuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.iot.platform.storm.define.gson.SchemaDto;
import com.iot.platform.storm.helper.SpringContext;
import com.iot.platform.storm.service.HBaseService;
import com.iot.platform.storm.service.StringService;


public class ShecmaDuplicateCheck extends TrueFilter {

    HBaseService hbase = null;
    Logger logger = null;

    @Override
    public void prepare(Map conf, TridentOperationContext context) {
        try {
            hbase = (HBaseService)SpringContext.getBean("HBaseService");
            logger = LoggerFactory.getLogger(ShecmaDuplicateCheck.class);
        }
        catch (Exception e) {
            logger.warn("[iot] ShecmaDuplicateCheck Prepare Exception!");
            e.printStackTrace();
        }
    }

    @Override
    public boolean isKeep(TridentTuple tuple) {

        SchemaDto schema = StringService.getSchma(tuple.getStringByField("value"));
        String collection = schema.getOrgCollection();

        HashMap<String, String> rt = new HashMap<String, String>();

        try {
            rt = hbase.get("schema", collection);
        } catch (Exception e) {
            logger.warn("[iot] ShecmaDuplicateCheck Exception!");
            e.printStackTrace();
        }

        if (rt.size() == 0) {
            return true;
        }
        else{
            logger.error("[iot] ShecmaDuplicateCheck Error:" + collection);
            return false;
        }

    }
}
