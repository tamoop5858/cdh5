package com.iot.platform.storm.bolt.schema;

import java.util.Map;

import org.apache.storm.trident.operation.BaseFunction;
import org.apache.storm.trident.operation.TridentCollector;
import org.apache.storm.trident.operation.TridentOperationContext;
import org.apache.storm.trident.tuple.TridentTuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.iot.platform.storm.define.gson.SchemaDto;
import com.iot.platform.storm.helper.SpringContext;
import com.iot.platform.storm.service.HBaseService;
import com.iot.platform.storm.service.StringService;

public class HBCollectionCreate extends BaseFunction {

    HBaseService hbase = null;
    Logger logger = null;

    @Override
    public void prepare(Map conf, TridentOperationContext context) {
        try {
            hbase = (HBaseService)SpringContext.getBean("HBaseService");
            logger = LoggerFactory.getLogger(HBCollectionCreate.class);
        }
        catch (Exception e) {
            logger.warn("[iot] HBCollectionCreate Prepare Exception!");
            e.printStackTrace();
        }
    }

    @Override
    public void execute(TridentTuple tuple, TridentCollector collector) {

        SchemaDto schema = StringService.getSchma(tuple.getStringByField("value"));
        String collection = StringService.getHBaseCollectionName(schema.getOrgCollection());

        try {
            hbase.createTable(collection);
        } catch (Exception e) {
            logger.warn("[iot] HBCollectionCreate Exception!");
            e.printStackTrace();
        }

        collector.emit(new Values());

    }
}
