package com.iot.platform.storm.bolt.schema;

import java.util.Map;

import org.apache.storm.trident.operation.BaseFunction;
import org.apache.storm.trident.operation.TridentCollector;
import org.apache.storm.trident.operation.TridentOperationContext;
import org.apache.storm.trident.tuple.TridentTuple;
import org.apache.storm.tuple.Values;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.iot.platform.storm.define.gson.SchemaDto;
import com.iot.platform.storm.helper.SpringContext;
import com.iot.platform.storm.service.SolrService;
import com.iot.platform.storm.service.StringService;

public class SolrCollectionCreate extends BaseFunction {

    SolrService solr = null;
    Logger logger = null;

    @Override
    public void prepare(Map conf, TridentOperationContext context) {
        try {
            solr = (SolrService)SpringContext.getBean("SolrService");
            logger = LoggerFactory.getLogger(SolrCollectionCreate.class);
        }
        catch (Exception e) {
            logger.warn("[iot] SolrCollectionCreate Prepare Exception!");
            e.printStackTrace();
        }
    }

    @Override
    public void execute(TridentTuple tuple, TridentCollector collector) {

        SchemaDto schema = StringService.getSchma(tuple.getStringByField("value"));
        String collection = schema.getOrgCollection();

        if (schema.getIndexKeys().size() > 0) {

            try {
                if (!solr.isExistsCollection(collection)) {
                    solr.createCollection(collection);
                    solr.createSchema(collection, schema);
                }
            } catch (Exception e) {
                logger.warn("[iot] SolrCollectionCreate Exception!");
                e.printStackTrace();
            }
        }

        collector.emit(new Values());
    }
}
