import java.util.HashMap;

import org.apache.storm.Config;
import org.apache.storm.LocalCluster;
import org.apache.storm.StormSubmitter;
import org.apache.storm.trident.Stream;
import org.apache.storm.trident.TridentTopology;
import org.apache.storm.trident.operation.Filter;
import org.apache.storm.trident.operation.Function;
import org.apache.storm.tuple.Fields;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.iot.platform.storm.define.gson.MapperDto;
import com.iot.platform.storm.define.gson.MapperDto.edge;
import com.iot.platform.storm.define.gson.MapperDto.node;
import com.iot.platform.storm.define.gson.MapperDto.stream;
import com.iot.platform.storm.helper.SpringContext;
import com.iot.platform.storm.helper.TridentKafkaSpout;
import com.iot.platform.storm.helper.XmlMapper;

public class MainTopology {

    private String kafka_topic_prefix;
    private boolean debug;
    private boolean storm_cloud_mode;
    private String topicName;
    private static final Logger logger = LoggerFactory.getLogger(MainTopology.class);

    public void setKafka_topic_prefix(String kafka_topic_prefix) {
        this.kafka_topic_prefix = kafka_topic_prefix;
    }

    public void setDebug(boolean debug) {
        this.debug = debug;
    }

    public void setStorm_cloud_mode(boolean storm_cloud_mode) {
        this.storm_cloud_mode = storm_cloud_mode;
    }

    public static void main(String[] args) {
        MainTopology topology = (MainTopology)SpringContext.getBean("MainTopology");
        topology.start();
    }

    public MainTopology() {
    }

    public void start() {

        TridentTopology topology = new TridentTopology();

        XmlMapper xml = (XmlMapper)SpringContext.getBean("XmlMapper");
        MapperDto mapper = xml.getTopology();
        Stream MyStream = null;
        HashMap<String, Stream> hmStream = new HashMap<String, Stream>();

        TridentKafkaSpout kafkaSpout = (TridentKafkaSpout)SpringContext.getBean("TridentKafkaSpout");

        try {
            for (stream stream : mapper.getStreams()) {

                topicName = kafka_topic_prefix + stream.getKafakTopic();
                MyStream = topology.newStream(topicName + "_kafkaspout",kafkaSpout.getKafkaSpout(topicName))
                                   .shuffle();
                hmStream.put("KafkaSpout", MyStream);

                for (edge edge : stream.getEdges()) {

                    MyStream = hmStream.get(edge.getFrom());

                    for (node node : stream.getNodes()) {

                        if (!edge.getTo().equals(node.getName())){
                            continue;
                        }

                        Fields inField = new Fields();
                        Fields outField = new Fields();
                        if (node.getIn_Field() !=null)
                        {
                            inField = new Fields(node.getIn_Field());
                        }
                        if (node.getOut_Field() !=null)
                        {
                            outField = new Fields(node.getOut_Field());
                        }

                        if ("function".equals(node.getType())) {
                            MyStream = MyStream.each(inField,(Function)SpringContext.getBean(node.getBean()),outField);
                        } else if ("filter".equals(node.getType())) {
                            MyStream = MyStream.each(inField,(Filter)SpringContext.getBean(node.getBean()));
                        }

                        break;
                    }

                    hmStream.put(edge.getTo(), MyStream);
                }

                MyStream = MyStream.parallelismHint(stream.getParallelismHint());
            }

            Config topologyConfig = new Config();
            topologyConfig.setDebug(debug);
            topologyConfig.setNumWorkers(6);
            String topologyName = kafka_topic_prefix + "iot-platform";

            if (!storm_cloud_mode) {
                LocalCluster cluster = new LocalCluster();
                cluster.submitTopology(topologyName, topologyConfig, topology.build());
                //cluster.killTopology(topologyName);
                //cluster.shutdown();
            } else {
                StormSubmitter.submitTopology(topologyName, topologyConfig, topology.build());
            }

        } catch (Exception e) {
            logger.warn("[iot] submitTopology Exception!");
            e.printStackTrace();
        }
    }
}
