import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.storm.kafka.trident.TransactionalTridentKafkaSpout;

import com.iot.platform.storm.define.gson.SchemaDto;
import com.iot.platform.storm.helper.SpringContext;
import com.iot.platform.storm.helper.TridentKafkaSpout;
import com.iot.platform.storm.service.StringService;

/**
 * Created by hsu on 2016/08/04.
 */

public class TestJsonParser {
    public static void main(String[] args) {
        new TestJsonParser();
    }

    public TestJsonParser() {

        TridentKafkaSpout kafkaSpout = (TridentKafkaSpout)SpringContext.getBean("TridentKafkaSpout");
        TransactionalTridentKafkaSpout tran = kafkaSpout.getKafkaSpout("topic-schema");
        System.out.println(tran.getOutputFields());

    }

    public void TestSchmaJson() {

        String jsonStr = "{\"org\": \"noah\",\"collection\": \"printer10\",\"desc\": \"自動紙折り機仕様情報\",\"fields\": [{\"field_name\": \"model_name\",\"field_name_logical\": \"機種名\",\"field_type\": \"string\",\"required\": true},{\"field_name\": \"paper_info\",\"field_name_logical\": \"用紙サイズ\",\"field_type\": \"array\",\"required\": true}],\"primary_keys\": [\"model_name\"],\"index_keys\": [\"model_name\",\"paper_info\"]}";
        System.out.println("input=" + jsonStr);
        SchemaDto schema = StringService.getSchma(jsonStr);


//        String collection = schema.getOrgCollection();
//        //Solrに検索項目を登録
//        if (schema.getIndexKeys().size() > 0) {
//            SolrUtil solr = new SolrUtil();
//            try {
//                if (!solr.isExistsCollection(collection)) {
//                    solr.createCollection(collection);
//                    solr.createSchema(collection, schema);
//                }
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        }
    }

    public void TestCollectionJson() {

        String jsonStr = "{\"org\": \"noah\",\"collection\": \"printer2\",\"model_name\":\"DJ80F\",\"paper_info\":[\"A4\",\"A5\"]}";
        System.out.println("input=" + jsonStr);

        HashMap<String, String> jsonResultList = StringService.getParsedResult(jsonStr);

        String jsonStrSchema = "{\"org\": \"noah\",\"collection\": \"printer\",\"desc\": \"自動紙折り機仕様情報\",\"fields\": [{\"field_name\": \"model_name\",\"field_name_logical\": \"機種名\",\"field_type\": \"string\",\"required\": true},{\"field_name\": \"paper_info\",\"field_name_logical\": \"用紙サイズ\",\"field_type\": \"array\",\"required\": true}],\"primary_keys\": [\"model_name\"],\"index_keys\": [\"model_name\",\"paper_info\"]}";
        System.out.println("input=" + jsonStrSchema);
        SchemaDto data = StringService.getSchma(jsonStrSchema);

        //Solrに検索項目を登録
        if (data.getIndexKeys().size() > 0) {

            //検索用項目を絞り込み
            HashMap<String, String> indexList = new HashMap<String, String>();
            Iterator<Map.Entry<String, String>> it = jsonResultList.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<String, String> entry = it.next();
                if (data.getIndexKeys().contains(entry.getKey())) {
                    indexList.put(entry.getKey(), entry.getValue());
                    System.out.println(entry.getKey() + ":" + StringService.getArrayValue(entry.getKey(), entry.getValue(), data));
                }
            }


        }
    }

    //    public TestJsonParser(){
    //
    //        SolrSchemaUtil solr = new SolrSchemaUtil();
    //
    //        try {
    //            solr.createSchema();
    //        } catch (IOException | SolrServerException e) {
    //            // TODO 自動生成された catch ブロック
    //            e.printStackTrace();
    //        }
    //
    //    }

    //
    //    public TestJsonParser(){
    //
    //        System.out.println("Start Creat Solr Collection...");
    //        CloudSolrClient solrClient = new CloudSolrClient("192.168.30.155:2181/solr");
    //
    //        solrClient.setDefaultCollection("jcm_cash_history");
    //        solrClient.setZkClientTimeout(10000);
    //        solrClient.setZkConnectTimeout(10000);
    //        solrClient.connect();
    //        System.out.println("The cloud Server has been connected !!!!");
    //
    //    }

    //    public TestJsonParser(){
    //        String jsonStr = "{\"model_name\":\"DJ80F\",\"paper_info\":[\"A4\",\"A5\"]}";
    //        System.out.println("input="+jsonStr);
    //        HashMap<String,String> data = JsonUtil.getParsedResult(jsonStr);
    //        System.out.println(data.get("model_name"));
    //    }

    //    Schma Jsonのテスト
    //    public TestJsonParser(){
    //        String jsonStr = "{\"desc\": \"自動紙折り機仕様情報\",\"fields\": [{\"field_name\": \"model_name\",\"field_name_logical\": \"機種名\",\"field_type\": \"string\",\"required\": true},{\"field_name\": \"paper_info\",\"field_name_logical\": \"用紙サイズ\",\"field_type\": \"array\",\"required\": true}],\"primary_keys\": [\"model_name\"],\"index_keys\": [\"model_name\",\"paper_info\"]}";
    //        System.out.println("input="+jsonStr);
    //        PackageSchma data = JsonUtil.getSchma(jsonStr);
    //        System.out.println(data.getIndexKeys().get(1));
    //    }

    //    public TestJsonParser(){
    //        String jsonStr = "{\"data\":[{\"sheetCount\":4,\"status\":\"0x01\",\"cashSource\":\"スーパーA\",\"billAmount\":1000,\"slipId\":\"1000001\",\"currency\":\"JPY\"},{\"sheetCount\":3,\"status\":\"0x01\",\"cashSource\":\"スーパーA\",\"billAmount\":5000,\"slipId\":\"1000001\",\"currency\":\"JPY\"},{\"sheetCount\":1,\"status\":\"0x01\",\"cashSource\":\"スーパーA\",\"billAmount\":10000,\"slipId\":\"1000001\",\"currency\":\"JPY\"},{\"sheetCount\":2,\"status\":\"0x01\",\"cashSource\":\"スーパーA\",\"billAmount\":100,\"slipId\":\"1000001\",\"currency\":\"USD\"}]}";
    //        System.out.println("input="+jsonStr);
    //        ArrayList<HashMap<String,String>> jsonResultList = getParsedResult(jsonStr);
    //        for(int i = 0; i<jsonResultList.size();i++) {
    //            System.out.println(jsonResultList.get(i));
    //        }
    //    }

    //    public void TestJsonParser2() {
    //        String jsonStr = "{\"data\":{\"edition\":\"01\",\"captureImg\":\"...\",\"source\":\"スーパーA\",\"machineType\":\"1234567890\",\"ocrResult\":\"AAAY2486VPRC008645H5Y\",\"status\":\"0x01\",\"processedResultCode\":\"1234567890\",\"recordDate\":\"201608021710\",\"outputId\":\"1234567890\",\"billAmount\":1000,\"inputId\":\"1000001\",\"currency\":\"JPY\"}}";
    //        System.out.println("input=" + jsonStr);
    //        HashMap<String, String> jsonResult = getParsedResult2(jsonStr);
    //        System.out.println(jsonResult);
    //    }

    //    public ArrayList<HashMap<String, String>> getParsedResult(String jsonStr) {
    //        ArrayList<HashMap<String, String>> aList = new ArrayList();
    //        JSONObject root = new JSONObject(jsonStr);
    //        JSONArray list = new JSONArray(root.get("data").toString());
    //        for (int i = 0; i < list.length(); i++) {
    //            HashMap<String, String> hm = new HashMap();
    //            JSONObject obj = new JSONObject(list.get(i).toString());
    //            Iterator<String> keySet = obj.keys();
    //            while (keySet.hasNext()) {
    //                String key = keySet.next();
    //                hm.put(key, obj.get(key).toString());
    //            }
    //            aList.add(hm);
    //        }
    //        return aList;
    //    }

}
