export PATH=/usr/java/default/bin:${PATH}
export JAVA_HOME=/usr/java/default/
