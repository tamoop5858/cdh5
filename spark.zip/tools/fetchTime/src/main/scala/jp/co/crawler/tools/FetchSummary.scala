package jp.co.crawler.tools

import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.SparkContext._
import org.apache.spark.rdd.RDD
import it.nerdammer.spark.hbase._
import org.apache.nutch.util.TableUtil
import org.apache.nutch.util.URLUtil
import java.net._
import scala.sys.process._
import java.io._
import scala.io._
import it.nerdammer.spark.hbase.conversion._

object FetchSummary {

  def main(args: Array[String]): Unit = {
    val sc = new SparkContext(new SparkConf().setAppName("FetchSummary"))
    val hbaseRDD = sc.hbaseTable[(String, Int)]("webpage")
        .select("_rs_")
        .inColumnFamily("mtdt")
    hbaseRDD.map( t => (urltoDomain(t._1),t._2))
        .cache
        .reduceByKey(_ + _)
        .collect.foreach { r =>
           println(r._1.mkString("","","") + " " + r._2)
        }
    println("Finish Dumping")
  }
  def getEncode(bytes: Array[Byte]): String = {
      new String (bytes, "UTF-8")
  }
  def urltoDomain(url: String): String = {
      val reveseurl = TableUtil.unreverseUrl(url)
      val dom = new URL(reveseurl)
      dom.getHost
  }
}
