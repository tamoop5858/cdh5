package test.com.lietu;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.lietu.links.WebGraph;
import com.sleepycat.je.DatabaseException;

public class TestWebGraph {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 * @throws DatabaseException 
	 */
	public static void main(String[] args) throws FileNotFoundException, IOException, DatabaseException {
		WebGraph webGraph = new WebGraph("C:/Program Files/eclipse/workspace/gongkongSpider/bin/webgraph/");
		String[] links = webGraph.inLinks("http://jianneng.gongkong.com/sale/");
		for(int i=0;i<links.length;++i)
		{
			System.out.println(links[i]);
		}
		/*WebGraph webGraph = new WebGraph(new File("D:/lg/work/ca800/Link.txt"));
		//System.out.println(webGraph.URLToIdentifyer("http://jianneng.gongkong.com/product/script/detail.asp?id=19574"));
		String[] links = webGraph.inLinks("http://jianneng.gongkong.com/product/script/15923.asp");
		for(int i=0;i<links.length;++i)
		{
			System.out.println(links[i]);
		}
		//webGraph.inLinks("http://jianneng.gongkong.com/product/script/15067.asp");
		//
		 */
	}
	/*public static void main(String[] args) throws FileNotFoundException, IOException {
		WebGraph webGraph = new WebGraph(new File("D:/lg/work/ca800/Link.txt"));
		Map<Integer,Double> links = webGraph.inLinks("http://jianneng.gongkong.com/tech/class/detail.asp?id=89");
		
		for (Map.Entry<Integer,Double> e: links.entrySet())
		{
			System.out.println(e.getKey()+":"+e.getValue());
			System.out.println(webGraph.IdentifyerToURL(e.getKey()));
		}
		System.out.println(Integer.MAX_VALUE);
		//System.out.println(webGraph.URLToIdentifyer("http://www.lietu.com/news/"));
	}*/
	
	/*static void testEmpty()
	{
		WebGraph webGraph = new WebGraph();
		webGraph.addLink("http://www.lietu.com/news/", "http://www.lietu.com", 1.0);
		Map<Integer,Double> links = webGraph.inLinks("http://www.lietu.com");
		Set set = links.entrySet();
		Iterator it = set.iterator();
		while (it.hasNext())
		{
			System.out.println(it.next());
		}
		System.out.println(webGraph.URLToIdentifyer("http://www.lietu.com/news/"));
	}*/

}
