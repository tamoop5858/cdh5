package test.com.lietu;

import java.io.InputStream;
import java.net.URL;
import java.util.Properties;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
	    URL u = new URL("http://www.te-elc.com/admin/product/images2/picture/200782815133870530.jpg");
		InputStream stream = u.openStream();
		//byte[] imageByte = getAllBytes(stream);
			stream.close();					
	
		
	/*	Properties p = new Properties();
    	InputStream is=p.getClass().getResourceAsStream("./spider.properties");
    	p.load(is);
		is.close();
		String solr = p.getProperty("solr");
		System.out.println(solr);*/
	}

}
