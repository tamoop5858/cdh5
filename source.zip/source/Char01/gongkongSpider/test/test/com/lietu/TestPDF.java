package test.com.lietu;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

import org.pdfbox.pdmodel.PDDocument;
import org.pdfbox.util.PDFTextStripper;

import com.bitmechanic.spindle.HttpTimeoutHandler;
import com.lietu.filter.PDFBox;

public class TestPDF {

	public  static void main(String[] args) throws Exception{
		//System.out.println(getTxt(new File("c:/a.pdf")));
		
		//System.out.println(getTxt(new File("d:/other/C#�̳�.pdf")));
		//"http://www.tianning.cn/TN2002DOC.pdf"
		/*String url = "http://www.beckhoff.com.cn/cn/Document/applicat/CX1000_chinameikuang_0506015002.pdf";
		String text = null;
		HttpURLConnection uc = null;
		HttpTimeoutHandler xHTH = new HttpTimeoutHandler(600000);
		URL theURL = new URL((URL)null, url , xHTH);
		uc = (HttpURLConnection) theURL.openConnection();
		text = (new PDFBox()).getText(uc.getInputStream());
		System.out.println(text);*/
		
		try{
			String text = null;
			String fileName ="C:/Users/Administrator/Documents/�ҽ��յ����ļ�/ҳ����ȡ�ԣ� 16������00kz0113.pdf"; //"d:/other/C#�̳�.pdf"; //"d:/other/manual.pdf";//"c:/a.pdf";//
			InputStream is = new FileInputStream(fileName);
			text = PDFBox.getText(is);
			String title = PDFBox.getTitle(text);
			System.out.println(text);
			System.out.println(title);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static String getTxt(File f) throws Exception {
		  String ts="";
		  try{
		  String temp = "";
		  PDDocument pdfdocument = PDDocument.load(f);
		  ByteArrayOutputStream out = new ByteArrayOutputStream();
		  OutputStreamWriter writer = new OutputStreamWriter(out);
		  PDFTextStripper stripper = new PDFTextStripper();
		  stripper.writeText(pdfdocument.getDocument(), writer);
		  pdfdocument.close();
		  out.close();
		  writer.close();
		  byte[] contents = out.toByteArray();
		  ts = new String(contents,"UTF-8");
		  System.out.println(f.getName() + "length is:" + contents.length + "\n");
		  }catch(Exception e){
		   e.printStackTrace();
		  }
		  finally{
		   return ts;
		  }
	}
}

