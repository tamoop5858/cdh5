package test.com.lietu;

public class TestLCString {
	/*public static void main(String[] args) {
	//LCString lcs = new LCString();
	String str = null;
	
}*/
}
