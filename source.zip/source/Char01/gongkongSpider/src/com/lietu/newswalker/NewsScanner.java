/*
 * Created on 2005-2-24
 *
 */
package com.lietu.newswalker;

import com.bitmechanic.spindle.NewsSource;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Administrator
 * TODO: test expand filter
 */
public class NewsScanner {

    private NewsSource _file;
    private Filter _filter;
    private Filter _expandFilter;

    public NewsScanner(NewsSource file) {
        _file = file;
    }

    public NewsSource[] scanUpdateChanged() {
        final List results = new ArrayList();
        walkUpdateChanged(new FileVisitor() {
            public void visitFile(NewsSource file) {
                results.add(file);
            }
        }, _file);
        NewsSource[] resultsArray = new NewsSource[results.size()];
        results.toArray(resultsArray);
        return resultsArray;
    }

    private void walkUpdateChanged(FileVisitor visitor, NewsSource current) {
        visitor.visitFile(current);
    	if (_expandFilter.filter(current)) {
			NewsSource[] currentFiles = current.expandUpdateChanged();
			if (currentFiles == null)
			{
				return ;
			}
	        for (int i = 0; i < currentFiles.length; i++) {
	            if (!_filter.filter(currentFiles[i])) {
	                continue;
	            }
	            walkUpdateChanged(visitor, currentFiles[i]);
	        }
    	}
    }

    private void walk(FileVisitor visitor, NewsSource current) {
        visitor.visitFile(current);
    	if (_expandFilter.filter(current)) {
			NewsSource[] currentFiles = current.expand();
	        for (int i = 0; i < currentFiles.length; i++) {
	            if (!_filter.filter(currentFiles[i])) {
	                continue;
	            }
	            walk(visitor, currentFiles[i]);
	        }
    	}
    }

    public void addFilter(Filter filter) {
        _filter=filter;
    }

    public void addExpandFilter(Filter filter) {
        _expandFilter=filter;
    }
    
    public void scanUpdateChanged(FileVisitor fileVisitor) {
        walkUpdateChanged(fileVisitor, _file);
    }

    public void scan(FileVisitor fileVisitor) {
        walk(fileVisitor, _file);
    }
    
	/*public static void main(String[] args) throws Exception
	{
		NewsSource source = new NewsSource("http://www.chinamet.com.cn/cn/bizoppo/index.jsp","������Ϣ","cn/bizoppo",1);
		NewsScanner ds = new NewsScanner( source );
		
		Filter levelFilter = new Filter(){
		    public boolean filter(NewsSource file){
		    	//System.out.println("enter filter");
		    	if( file.level<5) return true;
		    	//System.out.println("going to return false");
		    	return false;
		    	}
		    };
		    
		ds.addFilter(levelFilter);

		Filter levelFilter2 = new Filter(){
		    public boolean filter(NewsSource file){
		    	//System.out.println("enter filter");
		    	if( file.level<4) return true;
		    	//System.out.println("going to return false");
		    	return false;
		    	}
		    };
		    
		ds.addExpandFilter(levelFilter2);
		ds.scanUpdateChanged( new FileVisitor() {
            public void visitFile(NewsSource file) {
                System.out.println(file);
            }
        });
	}*/
}
