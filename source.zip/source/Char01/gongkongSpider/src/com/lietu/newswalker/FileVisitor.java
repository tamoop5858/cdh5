/*
 * Created on 2005-2-2
 *
 */
package com.lietu.newswalker;

import com.bitmechanic.spindle.NewsSource;
//import java.io.File;

public interface FileVisitor {

    void visitFile(NewsSource file);

}

