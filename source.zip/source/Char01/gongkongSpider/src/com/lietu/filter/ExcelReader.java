package com.lietu.filter;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.StringTokenizer;

import org.apache.poi.hssf.extractor.ExcelExtractor;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

public class ExcelReader {

	public static String readDoc(InputStream is) throws IOException{
		HSSFWorkbook wb = new HSSFWorkbook(new POIFSFileSystem(is));
		ExcelExtractor extractor = new ExcelExtractor(wb);
	
		extractor.setFormulasNotResults(true);
		extractor.setIncludeSheetNames(false);
		String text = extractor.getText();
		return text;
	}
	
	public static String getTitle(String str){
		StringTokenizer st=new StringTokenizer(str ,"\n");
		if(!st.hasMoreTokens())
			return "";
		String title=st.nextToken();
		while("".equals(title.trim())){
			if(st.hasMoreTokens()){
				 title=st.nextToken();
			}
			else
			{
				break;
			}
		}
		if(title.length()>50){
			if(title.indexOf('')>0)
				title=title.substring(0, title.indexOf(''));
			else if(title.indexOf('��')>0)
				title=title.substring(0, title.indexOf('��'));
			else if(title.indexOf('.')>0)
				title=title.substring(0, title.indexOf('.'));
		}
		return title;
	}
	
	/**
	 * @param args
	 */
	/*public static void main(String[] args) {
		//application/vnd.ms-powerpoint
		try{
			String fileName = "D:/CableSizing2.xls";
			InputStream is = new FileInputStream(fileName);
			String text=ExcelReader.readDoc(is);
			System.out.println(getTitle(text));
			//System.out.println(text);
		}catch(Exception e){
			e.printStackTrace();
		}
	}*/
}
