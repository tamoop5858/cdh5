package com.lietu.filter;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.StringTokenizer;

import org.apache.poi.hwpf.extractor.WordExtractor;

public class WordReader {

	public static String readDoc(InputStream is) throws IOException{
		 //����WordExtractor
		 WordExtractor  extractor=new WordExtractor(is);
		 //	��DOC�ļ�������ȡ
		 String text = extractor.getText();
		 
		 return text;
	}

	public static String getTitle(String str){
		StringTokenizer st=new StringTokenizer(str ,"\n");
		String title=st.nextToken();
		while("".equals(title.trim())){
			if(st.hasMoreTokens()){
				 title=st.nextToken();
			}
			else
			{
				break;
			}
		}
		if(title.length()>50){
			if(title.indexOf('')>0)
				title=title.substring(0, title.indexOf(''));
			else if(title.indexOf('��')>0)
				title=title.substring(0, title.indexOf('��'));
			else if(title.indexOf('.')>0)
				title=title.substring(0, title.indexOf('.'));
		}
		return title;
	}
	
	/*public static void main(String[] args){
		try{
			String fileName = "D:/aaa.doc";//"D:/lg/work/xiaoxishu/Solr����.doc";
			InputStream is = new FileInputStream(fileName);
			String text=WordReader.readDoc(is);
			System.out.println(getTitle(text));
			System.out.println(text);
		}catch(Exception e){
			e.printStackTrace();
		}
	}*/
}
