package com.lietu.database;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: ijsp.net</p>
 * @author ccjsmile
 * @version 1.0
 */

import java.sql.*;
import java.io.*;

public class DBConnect {

  /**
* �����������
*/
        private Connection conn = null;
        private Statement stmt = null;
        private PreparedStatement prepstmt = null;
        private static DBConnectionManager dcm = null;
        private PrintWriter log;

        private static Object lock = new Object();

        public DBConnect() {
                init();
                try{
                        conn = dcm.getConnection();
                        stmt = conn.createStatement();
                }catch(Exception e){
                        System.err.println(e);
                }
}

/**
* �������ݿ�����Ӻͷ�����
* Ԥ����SQL���
* @param sql SQL���
*/
public DBConnect(String sql) throws Exception {
    init();
                try{
                        conn = dcm.getConnection();
                        stmt = conn.createStatement();
                }catch(Exception e){
                        System.err.println(e);
                }
        this.prepareStatement(sql);
}

/**
* �ر����ݿ�
*/
public void close() throws Exception {
        if (stmt != null)  {
                stmt.close();
                stmt = null;
        }
        if (prepstmt != null) {
                prepstmt.close();
                prepstmt = null;
        }
        if (conn!=null) {
                dcm.freeConnection(conn);
        }
}

/**
* �����ر�100�����ݿ�����
*/
public void destroyAll() throws Exception {
        dcm.destroy();
}

/**
* �������ݿ����ӵĻ�������
*/
public void init() {
        if(dcm==null) {
                synchronized (lock) {
                        if(dcm==null) {
                                LoadProp lp = new LoadProp();
                                lp = lp.prop();
                                try{
                //			dcm = new DBConnectionManager("org.gjt.mm.mysql.Driver","jdbc:mysql://localhost/forum","root","",3,50,"C:\\conlog.txt",1,true,60,2);
                                    dcm = new DBConnectionManager(lp.getDriver(),
                                    								lp.getUrl(),
                                                                    lp.getUser(),
                                                                    lp.getPassword(),
                                                                    lp.getMinconn(),
                                                                    lp.getMaxconn(),
                                                                    lp.getLogfile(),
                                                                    lp.getMaxconntime(),
                                                                    false,
                                                                    2,
                                                                    lp.getDebug()
                                                                    );

                                }catch(IOException ie){
                                        System.err.println(ie);
                                }
                        }
                }
        }
}


    public DBConnect(int resultSetType, int resultSetConcurrency)
            throws Exception {
        init();
                try{
                        conn = dcm.getConnection();
                stmt = conn.createStatement(resultSetType, resultSetConcurrency);
                }catch(Exception e){
                        System.err.println(e);
                }
    }



        public DBConnect(String sql, int resultSetType, int resultSetConcurrency)
            throws Exception {
        init();
                this.prepareStatement(sql, resultSetType, resultSetConcurrency);
        }

        /**
         * ��������
         * @return Connection ����
         */
        public Connection getConnection() {
                return conn;
        }

        /**
         * PreparedStatement
         * @return sql Ԥ��SQL���
         */
        public void prepareStatement(String sql) throws SQLException {
                prepstmt = conn.prepareStatement(sql);
        }

        public void prepareStatement(String sql, int resultSetType, int resultSetConcurrency)
            throws SQLException {
                prepstmt = conn.prepareStatement(sql, resultSetType, resultSetConcurrency);
        }

        /**
         * ���ö�Ӧֵ
     *
         * @param index ��������
         * @param value ��Ӧֵ
         */
        public void setString(int index,String value) throws SQLException {
                prepstmt.setString(index, value);
        }
        public void setInt(int index,int value) throws SQLException {
                prepstmt.setInt(index,value);
        }
        public void setBoolean(int index,boolean value) throws SQLException {
                prepstmt.setBoolean(index,value);
        }
		public void setDate(int index,java.util.Date value) throws SQLException {
			if (value == null){
				prepstmt.setDate(index,null);
			}
			else{
				java.sql.Date d1 = new java.sql.Date(value.getTime());
				prepstmt.setDate(index,d1);
			}
		}
        public void setLong(int index,long value) throws SQLException {
                prepstmt.setLong(index,value);
        }
        public void setFloat(int index,float value) throws SQLException {
                prepstmt.setFloat(index,value);
        }
        public void setBytes(int index,byte[] value) throws SQLException{
                prepstmt.setBytes(index,value);
        }

    public void clearParameters()
        throws SQLException
    {
        prepstmt.clearParameters();
                prepstmt=null;
    }
        /**
         * ����Ԥ��״̬
         */
        public PreparedStatement getPreparedStatement() {
                return prepstmt;
        }
        /**
         * ����״̬
         * @return Statement ״̬
         */
        public Statement getStatement() {
                return stmt;
        }
        /**
         * ִ��SQL��䷵���ֶμ�
         * @param sql SQL���
         * @return ResultSet �ֶμ�
         */
        public ResultSet executeQuery(String sql) throws SQLException {
                if (stmt != null) {
                        return stmt.executeQuery(sql);
                }
                else return null;
        }

        public ResultSet executeQuery() throws SQLException {
                if (prepstmt != null) {
                        return prepstmt.executeQuery();
                }
                else return null;
        }

        /**
         * ִ��SQL���
         * @param sql SQL���
         */
        public void executeUpdate(String sql) throws SQLException {
                if (stmt != null)
                        stmt.executeUpdate(sql);
        }
        public void executeUpdate() throws SQLException {
                if (prepstmt != null)
                        prepstmt.executeUpdate();
        }

}