package com.lietu.database;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Logger;

public final class connectDB {

	private static String url = "jdbc:mysql://202.104.149.165:3306/gongkong?useUnicode=true&characterEncoding=GB2312";
	
	private static String driverName = "com.mysql.jdbc.Driver";
	
	private static String userName = "root";
	
	private static String passWord = "";
	
	//String user = "me";
	//String passwd = "a+b=c";
	//Class.forName(driver);
	//Connection cn = DriverManager.getConnection(url, user, passwd);
	
	
	static{
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			Logger.getAnonymousLogger().info(e.getMessage());
		}
		
	}
	public static Connection getConnection(){
		Connection c = null;
		try {
			c = DriverManager.getConnection(url, userName, passWord);
			System.out.println("sucess");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			Logger.getAnonymousLogger().info(e.getMessage());
			//Logger.getAnonymousLogger().info(e.getLocalizedMessage());
		}
		return c;
	}
  /* public static void main(String[] srgs){
	   connectDB a=new connectDB();
	   Connection s=a.getConnection();
   }*/
}
