/*
 * Created on 2005-6-29
 *
 */
package com.lietu.database;

import java.util.Date;

/**
 * @author Administrator
 *
 */
public class DBItem {
	public String url;
	public String body = "";
	public String author = "";
	public String title = "";
	public String source = "";
	public Date accessDate = new Date();
}
