package com.lietu.database;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: ijsp.net</p>
 * @author ccjsmile
 * @version 1.0
 */

import java.io.*;
import java.util.*;

public class LoadProp {
	private	String driver,url,user,password,logfile;
	private	int minconn=0;
	private	int maxconn=0;
	private	int debug=0;
	private	String poolName;
	private	int maxconntime=0;
	private String indexPath;
	
	private static LoadProp prop;
	
	private static Object lock = new Object();
	
	public LoadProp() {}

	/*public static void main(String[] args) {
		LoadProp lp = new LoadProp();
		lp.prop();
	}*/
	
	/**
	* ��ȡ��������
	*/
	public LoadProp prop() {
	        System.out.println("��ȡ�����ļ���Ϣ");
	        if (prop == null) {
	       synchronized (lock) {
	         if (prop == null)
	              prop = init1();
	         }
	    }
	        return  prop;
	}

	/**
	* �����̬��Ϣ
	*/
	public void reSet() {
		LoadProp.prop = null;
	}

	/**
	* ���û�����Ϣ
	*/
	public void setDriver(String driver) {
	        this.driver = driver;
	}
	public void setUrl(String url) {
	        this.url = url;
	}
	public void setUser(String user) {
	        this.user = user;
	}
	public void setPassword(String password) {
	        this.password = password;
	}
	public void setLogfile(String logfile) {
	        this.logfile = logfile;
	}
	public void setMinconn(int minconn) {
	        this.minconn = minconn;
	}
	public void setMaxconn(int maxconn) {
	        this.maxconn = maxconn;
	}
	public void setDebug(int debug) {
	        this.debug = debug;
	}
	public void setMaxconntime(int maxconntime) {
	        this.maxconntime = maxconntime;
	}

	public String getDriver() {
	        return driver;
	}
	public String getUrl() {
	        return url;
	}
	public String getUser() {
	        return user;
	}
	public String getPassword() {
	        return password;
	}
	public String getLogfile() {
	        return logfile;
	}
	public int getMinconn() {
	        return minconn;
	}
	public int getMaxconn() {
	        return maxconn;
	}
	
	public int getDebug() {
	        return debug;
	}
	public int getMaxconntime() {
	        return maxconntime;
	}
	/**
	* �����ļ���ַ
	*/
	public void setIndexPath(String indexPath) {
	        this.indexPath = indexPath;
	}
	public String getIndexPath() {
	        return indexPath;
	}

	/**
	* ��ȡ����������Ϣ
	*/
	private synchronized LoadProp init1() {
        if(prop==null) {
                LoadProp lp = new LoadProp();
                /**
                * ��������Ϣ�ļ�
                */
                InputStream is = getClass().getResourceAsStream("/downloaddb.txt");
                Properties props = new Properties();
                try {
                    props.load(is);
                }catch (Exception e) {
                    System.err.println("���ܶ�ȡ�����ļ�. ��ȷ��downloaddb.txt��classesָ����·����");
                }
                
                Enumeration propNames = props.propertyNames();
                while (propNames.hasMoreElements()) {
	                String name = (String) propNames.nextElement();
	                if (name.endsWith(".driver")) {
                        poolName = name.substring(0, name.lastIndexOf("."));
                        lp.setDriver(props.getProperty(poolName + ".driver"));
                        lp.setUrl(props.getProperty(poolName + ".url"));
                        lp.setUser(props.getProperty(poolName + ".user"));
                        lp.setPassword(props.getProperty(poolName + ".password"));
                        lp.setLogfile(props.getProperty(poolName + ".logfile"));
                        lp.setMinconn(Integer.parseInt(props.getProperty(poolName + ".minconn")));
                        lp.setMaxconn(Integer.parseInt(props.getProperty(poolName + ".maxconn")));
                        lp.setMaxconntime(Integer.parseInt(props.getProperty(poolName + ".maxconntime")));
                        lp.setDebug(Integer.parseInt(props.getProperty(poolName + ".debug")));
	                }
	                lp.setIndexPath(props.getProperty("index.path"));
                }
                return lp;
        }else{
                return prop;
        }
	}

}
