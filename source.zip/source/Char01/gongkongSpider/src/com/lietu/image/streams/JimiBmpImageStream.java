package com.lietu.image.streams;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.lietu.image.objects.RawImage;
import com.sun.jimi.core.Jimi;
import com.sun.jimi.core.JimiException;

/**
 * JimiBmpImageStream class
 * 
 *  @author    
 *  @created   2005/11/14
 *  @version   1.0.0
 *  @copyright 
 * 
 */
public class JimiBmpImageStream extends BmpImageStream {
	/**
	 * Constractor with input stream.
	 * 
	 * @return com.lietu.image.streams.ImageStream
	 * @param stream java.io.InputStream
	 * @exception java.io.IOException
	 * @category Instance creation
	 */
	public static ImageStream On_(InputStream stream) throws IOException {
		return On_(new JimiBmpImageStream(), stream);
	}

	/**
	 * Constractor with output stream.
	 * 
	 * @return com.lietu.image.streams.ImageStream
	 * @param stream java.io.OutputStream
	 * @exception java.io.IOException
	 * @category Instance creation
	 */
	public static ImageStream On_(OutputStream stream) throws IOException {
		return On_(new JimiBmpImageStream(), stream);
	}

	/**
	 * Read the image on input stream. (used JIMI Software Development Kit)
	 * 
	 * @return com.lietu.image.objects.RawImage
	 * @exception java.io.IOException
	 * @category accessing
	 */
	public RawImage nextImage() throws IOException {
		if (inStream != null) {
			imageObject = new RawImage(Jimi.getImage(inStream, "image/bmp"));
		}
		return imageObject;
	}

	/**
	 * Write the image on output stream. (used JIMI Software Development Kit)
	 * 
	 * @param newImage com.lietu.image.objects.RawImage
	 * @exception java.io.IOException
	 * @category accessing
	 */
	public void nextPutImage_(RawImage newImage) throws IOException {
		if (outStream != null) {
			imageObject = newImage;
			try {
				Jimi.putImage("image/bmp", newImage.image(), outStream);
			} catch (JimiException e) {
				e.printStackTrace();
				throw new IOException(e.getMessage());
			}
		}
	}
}
