package com.lietu.image.objects;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.TreeMap;

/**
 * SystemSupport class
 * 
 *  @author    
 *  @created   2005/11/14
 *  @version   1.0.0
 *  @copyright 
 * 
 */
public class SystemSupport {
	public final static String _System = "ImageLib";
	public final static String _Version = "1.0.0";
	public final static String _Date = "2005/11/14";

	// When you search an image with a typical color and nine colors,
	// you can select the color space which you want to use.
	public final static int DEF_SPACE = 0;	//Default Color Space
	public final static int RGB_SPACE = 1;
	public final static int CYM_SPACE = 2;
	public final static int HSB_SPACE = 3;

	public static int DefaultColorSpace = RGB_SPACE;

	/**
	 * Answer the string of the copyright.
	 * 
	 * @return java.lang.String
	 * @category Copyright
	 */
	public static final String Copyright() {
		StringWriter sw = new StringWriter();
		PrintWriter pw = null;
		try {
			pw = new PrintWriter(sw);
			pw.println("\"ImageLib\"");
			pw.println();
			pw.println("All rights reserved.");
			pw.println();
			pw.println(JavaTM());
		} finally {
			if (pw != null) {
				pw.flush();
				pw.close();
			}
		}
		return sw.toString();
	}

	/**
	 * Answer the current Name of the system.
	 *
	 * @return java.lang.String
	 * @category Copyright
	 */
	public static final String Date() {
		return _Date;
	}

	/**
	 * Answer the string of the Java trademark legend.
	 * 
	 * @return java.lang.String
	 * @category Copyright
	 */
	public static final String JavaTM() {
		return "Java and all Java-based trademarks and logos are trademarks or registered trademarks of Sun Microsystems, Inc. in the U.S. or other countries, and are used under license. ";
	}

	/**
	 * Answer the current Name of the system.
	 *
	 * @return java.lang.String
	 * @category Copyright
	 */
	public static final String System() {
		return _System;
	}

	/**
	 * Answer the current Version of the system.
	 *
	 * @return java.lang.String
	 * @category Copyright
	 */
	public static final String Version() {
		return _Version;
	}

	/**
	 * Answer the system information.
	 *
	 * @return java.lang.String
	 * @category Information
	 */
	public static final String Information() {
		String indent = "    ";
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);

		try {
			pw.println("Versions");
			pw.println(indent + SystemSupport.System() + " : " + SystemSupport.Version() + " (" + SystemSupport.Date() + ")");
			pw.println();

			pw.println("Java Properties");
			TreeMap map = new TreeMap();
			map.putAll(System.getProperties());
			String lineSeparator = (String) map.get("line.separator");
			if (lineSeparator != null && lineSeparator.length() > 0) {
				String newLineSeparator = "";
				for (int i = 0; i < lineSeparator.length(); i++) {
					char c = lineSeparator.charAt(i);
					switch (c) {
						case '\n':
							newLineSeparator += "\\n";
							break;
						case '\r':
							newLineSeparator += "\\r";
							break;
						case '\f':
							newLineSeparator += "\\f";
							break;
						default:
							newLineSeparator += String.valueOf(c);
					}
				}
				map.put("line.separator", newLineSeparator);
			}
			Object[] keys = map.keySet().toArray();
			for (int i = 0; i < keys.length; i++) {
				pw.println(indent + keys[i].toString() + " : " + map.get(keys[i]).toString());
			}
		} finally {
			pw.flush();
			pw.close();
		}

		return sw.toString();
	}

	/**
	 * Answer default color space mode.
	 * 
	 * @return int
	 * @category Defaults
	 */
	public static final int GetDefaultColorSpace() {
		return DefaultColorSpace;
	}

	/**
	 * Set default color space mode.
	 * 
	 * @param colorSpaceMode int
	 * @throws java.lang.IllegalArgumentException
	 * @category Defaults
	 */
	public static void SetDefaultColorSpace(int colorSpaceMode) throws IllegalArgumentException {
		if (DEF_SPACE <= colorSpaceMode && colorSpaceMode <= HSB_SPACE) {
			DefaultColorSpace = colorSpaceMode;
		} else {
			throw new IllegalArgumentException("The color space parameter \"" + colorSpaceMode + "\" is missing.");
		}
	}

	/**
	 * Set default color space mode.
	 * 
	 * @param aString java.lang.String
	 * @throws java.lang.IllegalArgumentException
	 * @category Defaults
	 */
	public static void SetDefaultColorSpace(String aString) throws IllegalArgumentException {
		String colorSpaceMode = aString.toUpperCase();
		if (colorSpaceMode.equals("DEF") || colorSpaceMode.equals("PicSearcher".toUpperCase()) || colorSpaceMode.equals("Pic Searcher".toUpperCase())) {
			SystemSupport.SetDefaultColorSpace(SystemSupport.DEF_SPACE);
		} else if (colorSpaceMode.equals("RGB")) {
			SystemSupport.SetDefaultColorSpace(SystemSupport.RGB_SPACE);
		} else if (colorSpaceMode.equals("CYM")) {
			SystemSupport.SetDefaultColorSpace(SystemSupport.CYM_SPACE);
		} else if (colorSpaceMode.equals("HSB")) {
			SystemSupport.SetDefaultColorSpace(SystemSupport.HSB_SPACE);
		} else {
			throw new IllegalArgumentException("The color space parameter \"" + aString + "\" is missing.");
		}
	}
}