package com.lietu.image.objects;

import java.io.IOException;
import java.io.Writer;

/**
 * ByteArray class
 * 
 *  @author    
 *  @created   2005/11/14
 *  @version   1.0.0
 *  @copyright 
 * 
 */
public class ByteArray extends BaseObject {
	/** The array. */
	protected byte[] byteArray = null;

	/**
	 * Constructor Method
	 */
	public ByteArray() {
		this(0);
	}

	/**
	 * Create a new instance of ByteArray and initialize it with the array of
	 * bytes.
	 * 
	 * @param bytes byte[]
	 */
	public ByteArray(byte[] bytes) {
		byteArray = new byte[bytes.length];
		System.arraycopy(bytes, 0, byteArray, 0, bytes.length);
	}

	/**
	 * Create a new instance of ByteArray and initialize it with the array of
	 * ints.
	 * 
	 * @param ints int[]
	 */
	public ByteArray(int[] ints) {
		byteArray = new byte[ints.length];

		for (int i = 0; i < ints.length; i++) {
			byteArray[i] = (byte) ints[i];
		}
	}

	/**
	 * Create a new instance of ByteArray and initialize it.
	 * 
	 * @param size DOCUMENT ME!
	 */
	public ByteArray(int size) {
		byteArray = new byte[size];

		for (int i = 0; i < size; i++) {
			byteArray[i] = 0;
		}
	}

	/**
	 * Create a ByteArray from a packed string.
	 * 
	 * @param packedString String
	 * 
	 * @return com.lietu.image.objects.ByteArray
	 */
	public static ByteArray FromPackedString_(String packedString) {
		int size = packedString.length();

		if (size == 0) {
			return new ByteArray();
		}

		int last = packedString.charAt(size - 1);
		int resultSize = Math.round((float) size / 4) * 3;
		int extra;

		if (last >= 96) {
			resultSize = (resultSize - 3 + last) - 96;
			extra = 1;
		} else {
			extra = 0;
		}

		ByteArray result = new ByteArray(resultSize);

		if (size > 400) {
			// The fast RasterOp algorithm is not implemented yet.
			// Do it with the slower algorithm.
			SlowDecodeFromFrom_Starting_Into_(1, packedString, 1, result);
			//			FastDecodeFrom_Into_(packedString, result);
			//			SlowDecodeFromFrom_Starting_Into_(size - Math.round((float)extra/16)*12+1 , packedString , size - Math.round(((float)extra)/16)*16+1 , result);
		} else {
			SlowDecodeFromFrom_Starting_Into_(1, packedString, 1, result);
		}

		return result;
	}

	/**
	 * Decode a string into a ByteArray.
	 * 
	 * @param start start
	 * @param source String
	 * @param index index
	 * @param dest com.lietu.image.objects.ByteArray
	 */
	private static void SlowDecodeFromFrom_Starting_Into_(int start, String source, int index, ByteArray dest) {
		int w;
		int to = start;
		int from = index;
		int stop = dest.size();

		while (to <= stop) {
			w = ((source.charAt(from - 1)) & 63) << 18;
			w += (((source.charAt(from)) & 63) << 12);
			w += (((source.charAt(from + 1)) & 63) << 6);
			w += ((source.charAt(from + 2)) & 63);
			from += 4;
			dest.at_put_(to, (byte) (w >> 16));

			if (to < stop) {
				dest.at_put_(to + 1, (byte) ((w >> 8) & 255));

				if ((to + 1) < stop) {
					dest.at_put_(to + 2, (byte) (w & 255));
				}
			}

			to = to + 3;
		}
	}

	/**
	 * Convert this ByteArray as an array of byte.
	 * 
	 * @return byte[]
	 */
	public byte[] _asBytes() {
		byte[] newArray = new byte[byteArray.length];

		System.arraycopy(byteArray, 0, newArray, 0, byteArray.length);

		return newArray;
	}

	/**
	 * Convert this ByteArray as an array of int.
	 * 
	 * @return int[]
	 */
	public int[] _asInts() {
		int[] ints = new int[byteArray.length];

		for (int i = 0; i < byteArray.length; i++) {
			ints[i] = (int) byteArray[i] & 0xff;
		}

		return ints;
	}

	/**
	 * Encode the receiver into a printable string.
	 * 
	 * @return java.lang.String
	 */
	public String asPackedString() {
		int size = this.size();
		ByteArray result = new ByteArray((size + 2) / 3 * 4);

		if (size > 300) {
			// fast RasterOp algorithm is not supported.
			// use slower algorithm.
			this.slowEncodeFrom_into_startingAt_(1, result, 1);
		} else {
			this.slowEncodeFrom_into_startingAt_(1, result, 1);
		}

		byte[] bytes = result._asBytes();
		StringBuffer buffer = new StringBuffer(bytes.length);

		for (int i = 0; i < bytes.length; i++) {
			char ch = (char) bytes[i];

			if (ch == '\'') {
				buffer.append(ch);
			}

			buffer.append(ch);
		}

		return buffer.toString();
	}

	/**
	 * Answer the byte value at the specified place.
	 * 
	 * @param index int
	 * 
	 * @return byte
	 */
	public byte at_(int index) {
		return byteArray[index - 1];
	}

	/**
	 * Put the byte value at the specified place.
	 * 
	 * @param index int
	 * @param value byte
	 */
	public void at_put_(int index, byte value) {
		byteArray[index - 1] = value;
	}

	/**
	 * Answer the size of the byte array.
	 * 
	 * @return int
	 */
	public final int size() {
		return byteArray.length;
	}

	/**
	 * Store my string representation on the writer.
	 * 
	 * @param aWriter java.io.Writer
	 * 
	 * @throws IOException DOCUMENT ME!
	 */
	public void storeOn_(Writer aWriter) throws IOException {
		if (byteArray.length > 200) {
			aWriter.write("(ByteArray fromPackedString: '");
			aWriter.write(this.asPackedString());
			aWriter.write("')");
		} else {
			aWriter.write("#[");

			if (byteArray.length > 0) {
				aWriter.write(String.valueOf(byteArray[0] & 0xff));

				for (int i = 1; i < byteArray.length; i++) {
					aWriter.write(' ');
					aWriter.write(String.valueOf(byteArray[i] & 0xff));
				}
			}

			aWriter.write(']');
		}
	}

	/**
	 * Encode the receiver into printable characters.
	 * 
	 * @param start int
	 * @param dest com.lietu.image.objects.ByteArray
	 * @param index int
	 */
	private void slowEncodeFrom_into_startingAt_(int start, ByteArray dest, int index) {
		int from = start;
		int to = index;
		int stop = this.size();
		int w;

		while (from <= stop) {
			w = (this.at_(from) & 0xff) << 16;

			if (from < stop) {
				w += ((this.at_(from + 1) & 0xff) << 8);

				if ((from + 1) < stop) {
					w += (this.at_(from + 2) & 0xff);
				}
			}

			w = w ^ 8521760;
			from += 3;
			dest.at_put_(to, (byte) ((w >> 18) + 32));
			dest.at_put_(to + 1, (byte) (((w >> 12) & 63) + 32));
			dest.at_put_(to + 2, (byte) (((w >> 6) & 63) + 32));
			dest.at_put_(to + 3, (byte) ((w & 63) + 32));
			to += 4;
		}

		if ((stop % 3) != 0) {
			dest.at_put_(to - 1, (byte) (stop % 3 + 96));
		}
	}
}
