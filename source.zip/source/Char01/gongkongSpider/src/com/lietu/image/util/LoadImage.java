package com.lietu.image.util;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import com.lietu.image.objects.ImageAuxiliary;
import com.lietu.image.objects.ImageFileInfo;
import com.lietu.image.objects.RawImage;

/**
 * LoadImage class
 * 
 *  @author    
 *  @created   2005/11/14
 *  @version   1.0.0
 *  @copyright 
 * 
 */
public class LoadImage {

	/**
	* Constructor
	*/
	public LoadImage () {
	}

	/*
	* Process a image
	*
	* @return int
	* @param filename java.lang.String
	* @param keywords java.lang.String
	* @param description java.lang.String
	* @param urls java.lang.String
	* @param parent_urls java.lang.String
	* @param contentType java.lang.String
	* @param imageByte byte[]
	* @exception java.sql.IOException, java.sql.SQLException
	*/
	public Image doProcess(String filename, String keywords, String description, String urls, String parent_urls, String contentType, byte[] imageByte) throws IOException {
		ImageAuxiliary imageObject = null;
		ImageFileInfo originalImage = null;
		RawImage rawImage = null;
		
		// create image object and image file info objects.
		originalImage = new ImageFileInfo(filename, keywords, description, urls, parent_urls, contentType, imageByte);
		imageObject = originalImage.asImageObject();
		rawImage = imageObject.originalImage();
		if(rawImage!=null)
		{
			//System.out.println("ok");
		}

		return rawImage.image();
	}
	
	/* 
	* Load images from file
	* 
	* @return void
	* @param bRecursively boolean
	* @param imageFile java.io.File, image file
	*/
	public Image loadImageFromFile(File imageFile) throws IOException {
		//Is file
		if(imageFile.isFile()) {
			System.out.print("Processing file " + imageFile.getName() + "...");	  				
				System.out.print("Reading...");
				
				//read file
				//try {
				FileInputStream stream = new FileInputStream(imageFile);
				int bytesRead = 0;
				byte[] buffer = new byte[8192];
				byte[] imageByte = new byte[(int)imageFile.length()];
				int j = 0;
				while ((bytesRead = stream.read(buffer, 0, 8192)) != -1) {
					 for(int k = 0; k < bytesRead; k++) {
					 	imageByte[k + j * 8192] = buffer[k];						 	
					 }
					 j++;
				}
				//close the stream
				stream.close();					
				buffer = null;
				
				System.out.print(imageByte.length + " Bytes...Storing...");
				
				//process this image
				String filename = imageFile.getPath();							
				String contentType = imageFile.getName().substring(imageFile.getName().lastIndexOf(".") + 1).toLowerCase();
				if(contentType.equals("jpg"))
					contentType = "jpeg";
				contentType = "image/" + contentType;
				
				return doProcess(filename, null, null, null, null, contentType, imageByte);
		}
		return null;
	}
	
    public static byte[] getAllBytes(InputStream in) throws IOException {
        int chunkSize = 4096;
        byte[] b = new byte[chunkSize];
        int borb = -1;
        ByteArrayOutputStream fos = new ByteArrayOutputStream();
        while ((borb = in.read(b)) != -1) {
                fos.write(b, 0, borb);
        }
        return fos.toByteArray();
    }
  
    public void loadImageStream(URL imageFile) throws IOException {
		
		InputStream stream = imageFile.openStream();
		//Image src=loadImageFromURL(imageFile);
		
		byte[] imageByte = getAllBytes(stream);
		stream.close();						
		//process this image
		String filename = imageFile.getPath();	
		System.out.println("loadImageStream:"+filename);
		if (filename.contains("/")){
			filename=filename.substring(filename.lastIndexOf("/"), filename.length());
			
		}
		else if(filename.contains("\\"))
			filename=filename.substring(filename.lastIndexOf("\\"), filename.length());
		

/*		BufferedImage tag = new BufferedImage(wideth/2,height/2,BufferedImage.TYPE_INT_RGB);
		tag.getGraphics().drawImage(src,0,0,wideth/2,height/2,null); //������С���ͼ
		FileOutputStream out=new FileOutputStream("newfile.jpg"); //������ļ���
		JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);
		encoder.encode(tag); //��JPEG����
	*/
			
		//filename=filename.substring(filename.lastIndexOf("\\"), filename.length());
    	FileOutputStream fw = new FileOutputStream("d:\\zhangjihong\\image\\"+filename);
		fw.write(imageByte);
		fw.close();
} 
    
    
    
    
	public Image loadImageFromURL(URL imageFile) throws IOException {
		

	//	  urlcon=(HttpURLConnection)baiduUrl.openConnection();

	   //     urlcon.setRequestProperty("User-agent","Mozilla/4.0");     

	//urlcon.connect();
		
	  //  String header1 = request.getHeader("User-Agent");
      //  out.println(header1);
		
		HttpURLConnection httpcon = (HttpURLConnection) imageFile.openConnection(); 
		httpcon.addRequestProperty("User-Agent", "Mozilla/4.0"); 
	//	BufferedReader in = new BufferedReader(new InputStreamReader(httpcon.getInputStream()));			
		httpcon.connect();
		InputStream stream = httpcon.getInputStream();
		
	//	InputStream stream = imageFile.openStream();
				byte[] imageByte = getAllBytes(stream);
     			stream.close();					
			
				//process this image
				String filename = imageFile.getPath();	
			//	System.out.println("LoadImage:"+filename);
			//	FileOutputStream fw = new FileOutputStream("d:\\zhangjihong\\image\\"+filename);

				
			//	 fw.write(imageByte);
			//	 fw.close();

				
				
				String contentType = filename.substring(filename.lastIndexOf(".") + 1).toLowerCase();
				if(contentType.equals("jpg"))
					contentType = "jpeg";
				contentType = "image/" + contentType;
				
				return doProcess(filename, null, null, null, null, contentType, imageByte);
		//}
		//return null;
	}
	/* 
	* Load images from directory
	* 
	* @return void
	* @param bRecursively boolean
	* @param imagePath java.lang.String, image directory
	*/	
	public void loadImageFromDir(boolean bRecursively, String imagePath) throws IOException {
		
		File currDir = new File(imagePath);
		//Is dir
		if(currDir.isDirectory()) {
			System.out.println("\nProcessing directory " + currDir.getPath() + "...");
			
			File files[] = currDir.listFiles();
	  		for(int i = 0; i < files.length; i++) {
	  			if(files[i].isFile() && (files[i].getName().toLowerCase().endsWith(".jpg") 
	  					|| files[i].getName().toLowerCase().endsWith(".jpeg") 
	  					|| files[i].getName().toLowerCase().endsWith(".gif") 
	  					|| files[i].getName().toLowerCase().endsWith(".bmp") 
	  					|| files[i].getName().toLowerCase().endsWith(".png"))) {
	  				
	  				loadImageFromFile(files[i]);
	  				
	  			} else if (files[i].isDirectory() && bRecursively) { //Subdirectory
	  				//Process subdirectory recursively
	  				loadImageFromDir(bRecursively, files[i].getPath());
	  			}
	  		}
		}
	}

}
