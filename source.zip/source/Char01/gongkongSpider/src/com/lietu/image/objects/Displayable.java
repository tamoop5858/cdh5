package com.lietu.image.objects;

import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;

/**
 * Displayable interface
 * 
 *  @author    
 *  @created   2005/11/14
 *  @version   1.0.0
 *  @copyright 
 * 
 */
public interface Displayable {
	/**
	 * Answer the receiver as RawImage.
	 *
	 * @return com.lietu.image.objects.RawImage
	 * @category converting
	 */
	public RawImage asImage();

	/**
	 * Answer the bounding box of the receiver.
	 *
	 * @return java.awt.Rectangle
	 * @category bounds accessing
	 */
	public Rectangle bounds();

	/**
	 * Display the receiver on the graphics.
	 *
	 * @param aGraphics java.awt.Graphics
	 * @category displaying
	 */
	public void displayOn_(Graphics aGraphics);

	/**
	 * Display the receiver on the graphics at the specified point.
	 *
	 * @param aGraphics java.awt.Graphics
	 * @param aPoint java.awt.Point
	 * @category displaying
	 */
	public void displayOn_at_(Graphics aGraphics, Point aPoint);
}