package com.lietu.image.util;

import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class im extends Frame{   
	public im(){    
		addWindowListener(new WindowAdapter()   
		{ 
			public void windowClosing(WindowEvent e) { 
				System.exit(0); 
			}      
		}
		);    
		Testpanel tp = new Testpanel();    
		add(tp);    }   
	/*public static void main(String[] args)    {  
		im f = new im();    
	//	f.setSize(250,400);  
		f.setSize(400,300);  
		f.show(); 
		}*/
}