package com.lietu.image.streams;

import java.awt.Frame;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import com.lietu.image.objects.RawImage;

/**
 * DefaultImageStream class
 * 
 *  @author    
 *  @created   2005/11/14
 *  @version   1.0.0
 *  @copyright 
 * 
 */
public class DefaultImageStream extends ImageStream {
	/**
	 * Constractor with input stream.
	 * 
	 * @return com.lietu.image.streams.ImageStream
	 * @param stream java.io.InputStream
	 * @exception java.io.IOException
	 * @category Instance creation
	 */
	public static ImageStream On_(InputStream stream) throws IOException {
		return On_(new DefaultImageStream(), stream);
	}

	/**
	 * Constractor with output stream.
	 * 
	 * @return com.lietu.image.streams.ImageStream
	 * @param stream java.io.InputStream
	 * @exception java.io.IOException
	 * @category Instance creation
	 */
	public static ImageStream On_(OutputStream stream) throws IOException {
		throw new IOException("could not save image");
	}

	/**
	 * Read the image on input stream. (used Java core API - toolkil)
	 * 
	 * @return com.lietu.image.objects.RawImage
	 * @exception java.io.IOException
	 * @category accessing
	 */
	public RawImage nextImage() throws IOException {
		if (inStream != null) {
			Frame frame = new Frame();
			Toolkit toolkit = frame.getToolkit();
			Image image = toolkit.createImage(this.readInputStream());
			MediaTracker tracker = new MediaTracker(frame);
			tracker.addImage(image, 0);
			try {
				tracker.waitForAll();
			} catch (InterruptedException exception) {
				throw new IOException("image load interrupted.");
			}
			int status = tracker.statusAll(false);
			if (((status & MediaTracker.ABORTED) != 0) || ((status & MediaTracker.ERRORED) != 0)) {
				throw new IOException("image load interrupted.");
			}
			image.flush();
			imageObject = new RawImage(image);
		}
		return imageObject;
	}

	/**
	 * Write the image on output stream. (used Java core API - toolkil)
	 * 
	 * @param newImage com.lietu.image.objects.RawImage
	 * @exception java.io.IOException
	 * @category accessing
	 */
	public void nextPutImage_(RawImage newImage) throws IOException {
		throw new IOException("could not save image");
	}

	/**
	 * Set the output stream.
	 * 
	 * @param stream java.io.OutputStream
	 * @exception java.io.IOException
	 * @category initialize-release
	 */
	protected void on_(OutputStream stream) throws IOException {
		throw new IOException("could not save image");
	}

	/**
	 * Read the input stream.
	 * 
	 * @return com.lietu.image.objects.RawImage
	 * @exception java.io.IOException
	 * @category stream access
	 */
	private byte[] readInputStream() throws IOException {
		byte[] bytes = null;
		if (inStream != null) {
			ByteArrayOutputStream byteStream = null;
			BufferedOutputStream bufferedStream = null;
			try {
				byteStream = new ByteArrayOutputStream();
				bufferedStream = new BufferedOutputStream(byteStream);
				byte[] buffer = new byte[1024];
				int size;
				while ((size = inStream.read(buffer, 0, buffer.length)) != -1) {
					bufferedStream.write(buffer, 0, size);
				}
				bufferedStream.flush();
				bytes = byteStream.toByteArray();
			} finally {
				if (bufferedStream != null) {
					bufferedStream.close();
					bufferedStream = null;
				}
				if (byteStream != null) {
					byteStream.close();
					byteStream = null;
				}
			}
		}
		return bytes;
	}
}
