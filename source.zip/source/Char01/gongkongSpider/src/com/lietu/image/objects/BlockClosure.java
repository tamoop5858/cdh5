package com.lietu.image.objects;

import java.lang.reflect.*;

/**
 * BlockClosure class
 * 
 *  @author    
 *  @created   2005/11/14
 *  @version   1.0.0
 *  @copyright 
 * 
 */
public class BlockClosure extends BaseObject {

	/**
	 * Just return the number of arguments.
	 * 
	 * @return int
	 */
	public int numArgs() {
		Class myClass = this.getClass();
		if (myClass == BlockClosure.class) {
			return 0;
		}

		Method[] myMethods = myClass.getDeclaredMethods();
		if (myMethods.length != 1) {
			this.error_("There should be only one method defined for BlockClosure.");
		}

		return myMethods[0].getParameterTypes().length;
	}

	/**
	 * This is a abstract method for value
	 * 
	 * @return java.lang.Object
	 * 
	 * @throws com.lietu.image.objects.SystemException runtime exception
	 */
	public Object value() {
		return null;
	}

	/**
	 * This is a abstract method for value:
	 * 
	 * @param argument java.lang.Object
	 * 
	 * @return java.lang.Object
	 * 
	 * @throws com.lietu.image.objects.SystemException runtime exception
	 */
	public Object value_(Object argument) {
		return null;
	}

	/**
	 * This is a abstract method for value: value:
	 * 
	 * @param argument1 java.lang.Object
	 * @param argument2 java.lang.Object
	 * 
	 * @return java.lang.Object
	 * 
	 * @throws com.lietu.image.objects.SystemException runtime exception
	 */
	public Object value_value_(Object argument1, Object argument2) {
		return null;
	}

	/**
	 * This is a abstract method for value: value: value:
	 * 
	 * @param argument1 java.lang.Object
	 * @param argument2 java.lang.Object
	 * @param argument3 java.lang.Object
	 * 
	 * @return java.lang.Object
	 * 
	 * @throws com.lietu.image.objects.SystemException runtime exception
	 */
	public Object value_value_value_(Object argument1, Object argument2, Object argument3) {
		return null;
	}

	/**
	 * This is a abstract method for valueWithArguments:
	 * 
	 * @param anArray java.lang.Object[]
	 * 
	 * @return java.lang.Object
	 */
	public Object valueWithArguments_(Object[] anArray) {
		return null;
	}
}
