package com.lietu.image.objects;

import java.util.Hashtable;

/**
 * Symbol class
 * 
 *  @author    
 *  @created   2005/11/14
 *  @version   1.0.0
 *  @copyright 
 * 
 */
public class Symbol extends BaseObject {
	//
	protected static Hashtable _symbols = new Hashtable();

	/** The string representation. */
	protected String _string;

	/**
	 * The instance of Symbol should not be created with the default
	 * constructor.
	 */
	private Symbol() {
	}

	/**
	 * Create a new instance of Symbol.
	 * 
	 * @param aString java.lang.String
	 */
	private Symbol(String aString) {
		_string = aString.intern();
		_symbols.put(_string, this);
	}

	/**
	 * Answer the symbol specified with the String.
	 * 
	 * @param aString
	 * 
	 * @return com.lietu.image.objects.Symbol
	 */
	public static Symbol Intern_(String aString) {
		Symbol aSymbol = (Symbol) _symbols.get(aString.intern());

		if (aSymbol == null) {
			aSymbol = new Symbol(aString);
		}

		return aSymbol;
	}

	/**
	 * Answer true if the receiver is equal to the Object, otherwise false.
	 * 
	 * @param anObject java.lang.Object
	 * 
	 * @return boolean
	 */
	public boolean equals(Object anObject) {
		return (this == anObject);
	}

	/**
	 * DOCUMENT ME!
	 * 
	 * @param aSymbol com.lietu.image.objects.Symbol
	 * 
	 * @return boolean
	 * 
	 * @deprecated replaced by <code>==</code>.
	 */
	public boolean isEqual(Symbol aSymbol) {
		return (this == aSymbol);
	}

	/**
	 * Answer the size.
	 * 
	 * @return int
	 */
	public int size() {
		return _string.length();
	}

	/**
	 * Returns a string representation of the StString.
	 * 
	 * @return java.lang.String
	 */
	public String toString() {
		return _string;
	}
}
