package com.lietu.image.streams;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.lietu.image.objects.RawImage;
import com.sun.jimi.core.Jimi;
import com.sun.jimi.core.JimiException;

/**
 * JimiJpegImageStream class
 * 
 *  @author    
 *  @created   2005/11/14
 *  @version   1.0.0
 *  @copyright 
 * 
 */
public class JimiJpegImageStream extends JpegImageStream {
	/**
	 * Constractor with input stream.
	 * 
	 * @return com.lietu.image.streams.ImageStream
	 * @param stream java.io.InputStream
	 * @exception java.io.IOException
	 * @category Instance creation
	 */
	public static ImageStream On_(InputStream stream) throws IOException {
		throw new IOException("could not load image");
	}

	/**
	 * Constractor with output stream.
	 * 
	 * @return com.lietu.image.streams.ImageStream
	 * @param stream java.io.OutputStream
	 * @exception java.io.IOException
	 * @category Instance creation
	 */
	public static ImageStream On_(OutputStream stream) throws IOException {
		return On_(new JimiJpegImageStream(), stream);
	}

	/**
	 * Read the image on input stream. (used JIMI Software Development Kit)
	 * 
	 * @return com.lietu.image.objects.RawImage
	 * @exception java.io.IOException
	 * @category accessing
	 */
	public RawImage nextImage() throws IOException {
		if (inStream != null) {
			imageObject = new RawImage(Jimi.getImage(inStream, "image/jpeg"));
		}
		return imageObject;
	}

	/**
	 * Write the image on output stream. (used JIMI Software Development Kit)
	 * 
	 * @param newImage com.lietu.image.objects.RawImage
	 * @exception java.io.IOException
	 * @category accessing
	 */
	public void nextPutImage_(RawImage newImage) throws IOException {
		if (outStream != null) {
			imageObject = newImage;
			try {
				Jimi.putImage("image/jpeg", newImage.image(), outStream);
			} catch (JimiException e) {
				e.printStackTrace();
				throw new IOException(e.getMessage());
			}
		}
	}
}
