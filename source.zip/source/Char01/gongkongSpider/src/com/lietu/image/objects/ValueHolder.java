package com.lietu.image.objects;

import java.io.Writer;
import java.io.IOException;

/**
 * ValueHolder class
 * 
 *  @author    
 *  @created   2005/11/14
 *  @version   1.0.0
 *  @copyright 
 * 
 */
public class ValueHolder extends BaseObject {

	protected Object value = null;

	/**
	 * Default constructor.
	 */
	public ValueHolder() {
		super();
	}

	/**
	 * Create a new instance and initialize it with aNumber .
	 * 
	 * @param aNumber double
	 */
	public ValueHolder(double aNumber) {
		super();
		this.setValue_(new Double(aNumber));
	}

	/**
	 * Create a new instance and initialize it with aNumber .
	 * 
	 * @param aNumber float
	 */
	public ValueHolder(float aNumber) {
		super();
		this.setValue_(new Float(aNumber));
	}

	/**
	 * Create a new instance and initialize it with aNumber .
	 * 
	 * @param aNumber int
	 */
	public ValueHolder(int aNumber) {
		super();
		this.setValue_(new Integer(aNumber));
	}

	/**
	 * Create a new instance and initialize it with aNumber .
	 * 
	 * @param aNumber long
	 */
	public ValueHolder(long aNumber) {
		super();
		this.setValue_(new Long(aNumber));
	}

	/**
	 * Create a new instance and initialize it with aBoolean.
	 * 
	 * @param aBoolean boolean
	 */
	public ValueHolder(boolean aBoolean) {
		super();
		this.setValue_(new Boolean(aBoolean));
	}

	/**
	 * Create a new instance and initialize it with anObject.
	 * 
	 * @param anObject java.lang.Object
	 */
	public ValueHolder(Object anObject) {
		super();
		this.setValue_(anObject);
	}

	/**
	 * Create a new instance and initialize it with anObject.
	 * 
	 * @param aClass java.lang.Class
	 * @param anObject java.lang.Object
	 * 
	 * @return com.lietu.image.objects.ValueHolder
	 */
	public static ValueHolder With_(Class aClass, Object anObject) {
		return (ValueHolder) _New(aClass, anObject);
	}

	/**
	 * Create a new instance of ValueHolder and initialize it with anObject.
	 * 
	 * @param anObject java.lang.Object
	 * 
	 * @return com.lietu.image.objects.ValueHolder
	 */
	public static final ValueHolder With_(Object anObject) {
		return With_(ValueHolder.class, anObject);
	}

	/**
	 * Assume 'value' is a Boolean and return it as boolean.
	 * 
	 * @return boolean
	 */
	public boolean _booleanValue() {
		return ((Boolean) value).booleanValue();
	}

	/**
	 * Assume 'value' is a kind of Number and return it as double.
	 * 
	 * @return double
	 */
	public double _doubleValue() {
		return ((Number) value).doubleValue();
	}

	/**
	 * Assume 'value' is a kind of Number and return it as float.
	 * 
	 * @return float
	 */
	public float _floatValue() {
		return ((Number) value).floatValue();
	}

	/**
	 * Assume 'value' is a kind of Number and return it as int.
	 * 
	 * @return int
	 */
	public int _intValue() {
		return ((Number) value).intValue();
	}

	/**
	 * Assume 'value' is a kind of Number and return it as long.
	 * 
	 * @return long
	 */
	public long _longValue() {
		return ((Number) value).longValue();
	}

	/**
	 * Print my string representation on aWriter.
	 * 
	 * @param aWriter java.io.Writer
	 * @throws IOException
	 */
	public void printOn_(Writer aWriter) throws IOException {
		super.printOn_(aWriter);
		aWriter.write(" on: ");
		if (this.value() == null) {
			aWriter.write("null");
		} else {
			aWriter.write(this.value().toString());
		}
	}

	/**
	 * Set the currently stored value, without notifying dependents.
	 * 
	 * @param newValue java.lang.Object
	 */
	public void setValue_(Object newValue) {
		value = newValue;
	}

	/**
	 * Answer the currently stored value.
	 * 
	 * @return java.lang.Object
	 */
	public Object value() {
		return value;
	}

	/**
	 * Set the currently stored value.
	 * 
	 * @param aNumber double
	 */
	public void value_(double aNumber) {
		this.setValue_(new Double(aNumber));
	}

	/**
	 * Set the currently stored value.
	 * 
	 * @param aNumber float
	 */
	public void value_(float aNumber) {
		this.setValue_(new Float(aNumber));
	}

	/**
	 * Set the currently stored value.
	 * 
	 * @param aNumber int
	 */
	public void value_(int aNumber) {
		this.setValue_(new Integer(aNumber));
	}

	/**
	 * Set the currently stored value.
	 * 
	 * @param aNumber long
	 */
	public void value_(long aNumber) {
		this.setValue_(new Long(aNumber));
	}

	/**
	 * Set the currently stored value.
	 * 
	 * @param aBoolean boolean
	 */
	public void value_(boolean aBoolean) {
		this.setValue_(new Boolean(aBoolean));
	}
	
	/**
	 * Set the currently stored value.
	 * 
	 * @param anObject java.lang.Object
	 */
	public void value_(Object anObject) {
		this.setValue_(anObject);
	}	
}
