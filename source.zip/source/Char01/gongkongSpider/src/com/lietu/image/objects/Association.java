package com.lietu.image.objects;

import java.io.IOException;
import java.io.Writer;

/**
 * Association class
 * 
 *  @author    
 *  @created   2005/11/14
 *  @version   1.0.0
 *  @copyright 
 * 
 */
public class Association extends BaseObject {
	/** The key object of the association. */
	Object key = null;

	/** The value object of the association. */
	Object value = null;

	/**
	 * Create a new instance of Association.
	 * 
	 * @param keyObject java.lang.Object
	 * @param valueObject java.lang.Object
	 */
	public Association(Object keyObject, Object valueObject) {
		key = keyObject;
		value = valueObject;
	}

	/**
	 * Answer the key object of the receiver.
	 * 
	 * @return java.lang.Object
	 */
	public final Object key() {
		return key;
	}

	/**
	 * Print my string representation on aWriter.
	 * 
	 * @param aWriter java.io.Writer
	 * 
	 * @throws IOException DOCUMENT ME!
	 */
	public void printOn_(Writer aWriter) throws IOException {
		aWriter.write(key + "->" + value);
	}

	/**
	 * Returns a String that represents the value of this object.
	 * 
	 * @return a string representation of the receiver
	 */
	public String toString() {
		// Insert code to print the receiver here.
		// This implementation forwards the message to super. You may replace or supplement this.
		return super.toString();
	}

	/**
	 * Answer the value object of the receiver.
	 * 
	 * @return java.lang.Object
	 */
	public final Object value() {
		return value;
	}
}
