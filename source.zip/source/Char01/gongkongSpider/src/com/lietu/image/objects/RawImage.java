package com.lietu.image.objects;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.DirectColorModel;
import java.awt.image.IndexColorModel;
import java.awt.image.PixelGrabber;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.io.Writer;
import java.util.Hashtable;

/**
 * RawImage class
 * 
 *  @author    
 *  @created   2005/11/14
 *  @version   1.0.0
 *  @copyright 
 * 
 */
public class RawImage extends BaseObject implements Displayable, Serializable {

	// Serialize version
	private static final long serialVersionUID = -7647941984469789820L;

	// Constants
	public static final int WriteZeros = 0;
	public static final int And = 1;
	public static final int Over = 3;
	public static final int Erase = 4;
	public static final int Reverse = 6;
	public static final int Under = 7;
	public static final int ReverseUnder = 13;
	public static final int WriteOnes = 15;
	public static final int Paint = 16;

	protected static IndexColorModel MonoMaskColorModel;

	protected transient BufferedImage image;
	protected transient int rowByteSize;
	protected transient byte[] bits;

	/**
	 * Create a new instance of RawImage.
	 * 
	 * @param width int
	 * @param height int
	 * @category Instance creation
	 */
	public RawImage(int width, int height) {
		this(width, height, ColorModel.getRGBdefault());

		int[] pixels = new int[width * height];
		for (int i = 0; i < pixels.length; i++) {
			pixels[i] = -1;
		}
		this.setPixels(pixels);
	}

	/**
	 * Create a new instance of RawImage and initialize it.
	 * 
	 * @param width int
	 * @param height int
	 * @param colorModel java.awt.image.ColorModel
	 * @category Instance creation
	 */
	public RawImage(int width, int height, ColorModel colorModel) {
		image = new BufferedImage(colorModel, colorModel.createCompatibleWritableRaster(width, height), false, null);
		rowByteSize = (width * this.bitsPerPixel() + 31) >> 5 << 2;
	}

	/**
	 * Create a new instance of RawImage and initialize it.
	 * 
	 * @param width int
	 * @param height int
	 * @param bits byte[]
	 * @category Instance creation
	 */
	public RawImage(int width, int height, byte[] bits) {
		this(width, height, bits, ColorModel.getRGBdefault());
	}

	/**
	 * Create a new instance of RawImage and initialize it.
	 * 
	 * @param width int
	 * @param height int
	 * @param byteArray byte[]
	 * @param colorModel java.awt.image.ColorModel
	 * @category Instance creation
	 */
	public RawImage(int width, int height, byte[] byteArray, ColorModel colorModel) {
		this(width, height, colorModel);

		if (byteArray != null) {
			if ((rowByteSize * height) > byteArray.length) {
				throw SystemException.Error("Bitmap array has incorrect size.");
			}

			// Set the pixels.
			for (int y = 0; y < height; y++) {
				for (int x = 0; x < width; x++) {
					this.setPixel(x, y, this._getPixelFromBits(x, y, byteArray));
				}
			}

			// Set the bit array.
			bits = byteArray;
		}
	}

	/**
	 * Create a new instance of RawImage and initialize it.
	 * 
	 * @param width int
	 * @param height int
	 * @param pixels int[]
	 * @category Instance creation
	 */
	public RawImage(int width, int height, int[] pixels) {
		this(width, height, pixels, ColorModel.getRGBdefault());
	}

	/**
	 * Create a new instance of RawImage and initialize it.
	 * 
	 * @param width int
	 * @param height int
	 * @param pixels int[]
	 * @param colorModel java.awt.image.ColorModel
	 * @category Instance creation
	 */
	public RawImage(int width, int height, int[] pixels, ColorModel colorModel) {
		this(width, height, colorModel);
		this.setPixels(pixels);
	}

	/**
	 * Create a new instance of RawImage and initialize it.
	 * 
	 * @param width int
	 * @param height int
	 * @param byteArray com.lietu.image.objects.ByteArray
	 * @param colorModel java.awt.image.ColorModel
	 * @category Instance creation
	 */
	public RawImage(int width, int height, ByteArray byteArray, ColorModel colorModel) {
		this(width, height, byteArray._asBytes(), colorModel);
	}

	/**
	 * Create a new instance of RawImage and initialize it with the image.
	 * 
	 * @param originalImage java.awt.Image
	 * @category Instance creation
	 */
	public RawImage(Image originalImage) {
		if (originalImage instanceof BufferedImage) {
			BufferedImage bufferedImage = (BufferedImage) originalImage;
			image = bufferedImage.getSubimage(0, 0, bufferedImage.getWidth(), bufferedImage.getHeight());
		} else {
			Component medium = new Canvas();
			int width = originalImage.getWidth(medium);
			int height = originalImage.getHeight(medium);
			int[] pixels = new int[width * height];
			PixelGrabber grabber = new PixelGrabber(originalImage, 0, 0, width, height, pixels, 0, width);
			try {
				grabber.grabPixels();
			} catch (InterruptedException e) {
			}
			image = (new RawImage(width, height, pixels)).image();
			this.setPixels(pixels);
		}

		rowByteSize = (this.width() * this.bitsPerPixel() + 31) >> 5 << 2;
	}

	/**
	 * Create a new instance of RawImage.
	 * 
	 * @param extentPoint java.awt.Point
	 * @category Instance creation
	 */
	public RawImage(Point extentPoint) {
		this(extentPoint.x, extentPoint.y);
	}

	/**
	 * Answer the mono mask color model.
	 * 
	 * @return java.awt.image.IndexColorModel
	 * @category Constants of color model
	 */
	public static IndexColorModel MonoMaskColorModel() {
		if (MonoMaskColorModel == null) {
			byte[] bytes = {(byte) 0xFF, (byte) 0 };
			MonoMaskColorModel = new IndexColorModel(1, 2, bytes, bytes, bytes);
		}
		return MonoMaskColorModel;
	}

	/**
	 * Answer the number of the bits for one pixel.
	 * 
	 * @return int
	 * @category accessing
	 */
	public int bitsPerPixel() {
		return this.colorModel().getPixelSize();
	}

	/**
	 * Answer my current color model.
	 * 
	 * @return java.awt.image.ColorModel
	 * @category accessing
	 */
	public ColorModel colorModel() {
		return this.image().getColorModel();
	}

	/**
	 * Answer extent of this image.
	 * 
	 * @return java.awt.Point
	 * @category accessing
	 */
	public Point extent() {
		return new Point(this.width(), this.height());
	}

	/**
	 * Answer the height of this image.
	 * 
	 * @return int
	 * @category accessing
	 */
	public int height() {
		return this.image().getHeight();
	}

	/**
	 * Answer the image object.
	 * 
	 * @return java.awt.image.BufferedImage
	 * @category accessing
	 */
	public BufferedImage image() {
		return image;
	}

	/**
	 * Answer the width of this image.
	 * 
	 * @return int
	 * @category accessing
	 */
	public int width() {
		return this.image().getWidth();
	}

	/**
	 * Answer the bounds of this image.
	 * 
	 * @return java.awt.Rectangle
	 * @category bounds accessing
	 */
	public Rectangle bounds() {
		return new Rectangle(0, 0, this.width(), this.height());
	}

	/**
	 * Answer the pixel at the specified zero-based 2D index.
	 * 
	 * @param point java.awt.Point
	 * @return int
	 * @deprecated use getPixel(int x, int y) instead.
	 * @category bits accessing
	 */
	public int atPoint_(Point point) {
		return this.getPixel(point.x, point.y);
	}

	/**
	 * Set a pixel value at the specified zero-based 2D index.
	 * 
	 * @param point java.awt.Point
	 * @param pixelValue int
	 * @deprecated use setPixel(int x, int y, int pixel) instead.
	 * @category bits accessing
	 */
	public void atPoint_put_(Point point, int pixelValue) {
		this.setPixel(point.x, point.y, pixelValue);
	}

	/**
	 * Answer the pixel value at the specified point.
	 * 
	 * @param x int
	 * @param y int
	 * @return int
	 * @category bits accessing
	 */
	public int getPixel(int x, int y) {
		if (x >= this.width() || y >= this.height()) {
			throw new ArrayIndexOutOfBoundsException("Index out of Image Bounds Exception at (" + x + ", " + y + ")");
		}
		return this.image().getRGB(x, y);
	}

	/**
	 * Answer all of the pixel values.
	 * 
	 * @return int[]
	 * @category bits accessing
	 */
	public int[] getPixels() {
		int width = this.width();
		int height = this.height();
		return this.image().getRGB(0, 0, width, height, null, 0, width);
	}

	/**
	 * Answer the pixel value at the specified point in bits.
	 * 
	 * @param x int
	 * @param y int
	 * @param bits byte[]
	 * @return int
	 * @category bits accessing
	 */
	protected int _getPixelFromBits(int x, int y, byte[] bits) {
		int bitsPerPixel = this.bitsPerPixel();

		if (bitsPerPixel == 32) {
			return this._getPixel32FromBits(x, y, bits);
		} else if (bitsPerPixel == 24) {
			return this._getPixel24FromBits(x, y, bits);
		} else if (bitsPerPixel == 1) {
			return this._getPixel1FromBits(x, y, bits);
		}

		throw new SystemException("can't handle an " + bitsPerPixel + "-color image");
	}

	/**
	 * Answer the pixel value as a 1-bit color image at the specified point in bits.
	 * 
	 * @param x int
	 * @param y int
	 * @param bits int[]
	 * @return int
	 * @category bits accessing
	 */
	protected int _getPixel1FromBits(int x, int y, byte[] bits) {
		int pixel = bits[(y * rowByteSize) + (x >> 3)] & 0xff;
		pixel = pixel >> (7 - (x & 7));
		pixel = pixel & 1;
		return this.image().getColorModel().getRGB(pixel);
	}

	/**
	 * Answer the pixel value as a 24-bit color image at the specified point in bits.
	 * 
	 * @param x int
	 * @param y int
	 * @param bits int[]
	 * @return int
	 * @category bits accessing
	 */
	protected int _getPixel24FromBits(int x, int y, byte[] bits) {
		int byteIndex = (y * rowByteSize) + x + x + x;
		int r = bits[byteIndex + 0] & 0xff;
		int g = bits[byteIndex + 1] & 0xff;
		int b = bits[byteIndex + 2] & 0xff;
		return this.image().getColorModel().getRGB((new Color(r, g, b)).getRGB());
	}

	/**
	 * Answer the pixel value as a 32-bit color image at the specified point in bits.
	 * 
	 * @param x int
	 * @param y int
	 * @param bits byte[]
	 * @return int
	 * @category bits accessing
	 */
	protected int _getPixel32FromBits(int x, int y, byte[] bits) {
		int byteIndex = (y * rowByteSize) + x + x + x + x;
		int a = 0xff - (bits[byteIndex + 0] & 0xff);
		int r = bits[byteIndex + 1] & 0xff;
		int g = bits[byteIndex + 2] & 0xff;
		int b = bits[byteIndex + 3] & 0xff;
		return this.image().getColorModel().getRGB((new Color(r, g, b, a)).getRGB());
	}

	/**
	 * Set the pixel value to the specified point.
	 * 
	 * @param x int
	 * @param y int
	 * @param pixel int
	 * @category bits accessing
	 */
	public void setPixel(int x, int y, int pixel) {
		this.image().setRGB(x, y, pixel);
		this._flushBits();
	}

	/**
	 * Set the specified pixel values.
	 * 
	 * @param pixels int[]
	 * @category bits accessing
	 */
	public void setPixels(int[] pixels) {
		int width = this.width();
		int height = this.height();
		if (pixels == null) {
			pixels = new int[width * height];
		} else if ((width * height) > pixels.length) {
			throw SystemException.Error("Pixel array has incorrect size.");
		}
		this.image().setRGB(0, 0, width, height, pixels, 0, width);
		this._flushBits();
	}

	/**
	 * Set the pixel value at the specified point in bits.
	 * 
	 * @param x int
	 * @param y int
	 * @param bits byte[]
	 * @return int
	 * @category bits accessing
	 */
	protected int _setPixelIntoBits(int x, int y, byte[] bits) {
		int bitsPerPixel = this.bitsPerPixel();

		if (bitsPerPixel == 32) {
			return this._setPixel32IntoBits(x, y, bits);
		} else if (bitsPerPixel == 24) {
			return this._setPixel24IntoBits(x, y, bits);
		} else if (bitsPerPixel == 1) {
			return this._setPixel1IntoBits(x, y, bits);
		}

		throw new SystemException("can't handle an " + bitsPerPixel + "-color image");
	}

	/**
	 * Set the pixel value as a 1-bit color image at the specified point in bits.
	 * 
	 * @param x int
	 * @param y int
	 * @param bits byte[]
	 * @return int
	 * @category bits accessing
	 */
	protected int _setPixel1IntoBits(int x, int y, byte[] bits) {
		ColorModel colorModel = this.image().getColorModel();
		int pixelValue = colorModel.getRGB(this.getPixel(x, y) & 0xff);
		int byteIndex = (y * rowByteSize) + (x >> 3);
		int whichBit = 7 - (x & 7);
		int value = (pixelValue == 0) ? (bits[byteIndex] & (-1 - (1 << whichBit))) : bits[byteIndex] | (1 << whichBit);
		bits[byteIndex] = (byte) value;
		return pixelValue;
	}

	/**
	 * Set the pixel value as a 24-bit color image at the specified point in bits.
	 * 
	 * @param x int
	 * @param y int
	 * @param bits byte[]
	 * @return int
	 * @category bits accessing
	 */
	protected int _setPixel24IntoBits(int x, int y, byte[] bits) {
		ColorModel colorModel = this.image().getColorModel();
		int pixelValue = this.getPixel(x, y);
		int byteIndex = (y * rowByteSize) + x + x + x;
		bits[byteIndex + 0] = (byte) colorModel.getRed(pixelValue);
		bits[byteIndex + 1] = (byte) colorModel.getGreen(pixelValue);
		bits[byteIndex + 2] = (byte) colorModel.getBlue(pixelValue);
		return pixelValue;
	}

	/**
	 * Set the pixel value as a 32-bit color image at the specified point in bits.
	 * 
	 * @param x int
	 * @param y int
	 * @param bits byte[]
	 * @return int
	 * @category bits accessing
	 */
	protected int _setPixel32IntoBits(int x, int y, byte[] bits) {
		ColorModel colorModel = this.image().getColorModel();
		int pixelValue = this.getPixel(x, y);
		int byteIndex = (y * rowByteSize) + x + x + x + x;
		bits[byteIndex + 0] = (byte) (0xff - colorModel.getAlpha(pixelValue));
		bits[byteIndex + 1] = (byte) colorModel.getRed(pixelValue);
		bits[byteIndex + 2] = (byte) colorModel.getGreen(pixelValue);
		bits[byteIndex + 3] = (byte) colorModel.getBlue(pixelValue);
		return pixelValue;
	}

	/**
	 * Answer the value at aPoint according to this image interpretation.
	 * 
	 * @param point java.awt.Point
	 * @return java.awt.Color
	 * @category bits accessing
	 */
	public Color valueAtPoint_(Point point) {
		return new Color(this.getPixel(point.x, point.y), this.colorModel().hasAlpha());
	}

	/**
	 * Set the value at aPoint according to this image interpretation.
	 * 
	 * @param point java.awt.Point
	 * @param color java.awt.Color
	 * @category bits accessing
	 */
	public void valueAtPoint_put_(Point point, Color color) {
		this.setPixel(point.x, point.y, color.getRGB());
	}

	/**
	 * Display the receiver on the graphics.
	 * 
	 * @param aGraphics java.awt.Graphics
	 * @category displaying
	 */
	public void displayOn_(Graphics aGraphics) {
		this.displayOn_at_(aGraphics, new Point(0, 0));
	}

	/**
	 * Dislplay the receiver on the graphics at the specified point.
	 * 
	 * @param aGraphics java.awt.Graphics
	 * @param aPoint java.awt.Point
	 * @category displaying
	 */
	public void displayOn_at_(Graphics aGraphics, Point aPoint) {
		aGraphics.drawImage(this.image(), aPoint.x, aPoint.y, null);
	}

	/**
	 * Create a copy of the RawImage.
	 * 
	 * @return java.lang.Object
	 * @category copying
	 */
	public Object clone() {
		return new RawImage(this.width(), this.height(), this.getPixels(), this.image().getColorModel());
	}

	/**
	 * Answer a new Image with the same extent, depth as the this image.
	 * 
	 * @param newExtent java.awt.Point
	 * @return com.lietu.image.objects.RawImage
	 * @category copying
	 */
	public RawImage copyEmpty() {
		return this.copyEmpty_(this.extent());
	}

	/**
	 * Answer a new Image with the same extent, depth as the this image.
	 * 
	 * @param newExtent java.awt.Point
	 * @return com.lietu.image.objects.RawImage
	 * @category copying
	 */
	public RawImage copyEmpty_(Point newExtent) {
		return new RawImage(newExtent.x, newExtent.y);
	}

	/**
	 * Answer the receiver as RawImage.
	 *
	 * @return com.lietu.image.objects.RawImage
	 * @category converting
	 */
	public RawImage asImage() {
		return this;
	}

	/**
	 * Answer image representing my contents using the palette aPalette.
	 * 
	 * @param aPalette java.awt.image.ColorModel
	 * @return com.lietu.image.objects.RawImage
	 * @category converting
	 */
	public RawImage convertToPalette_(IndexColorModel aPalette) {
		return this._convertToPalette_RenderedByNearistPaint(aPalette);
	}

	/**
	 * Answer image representing my contents using the palette aPalette. Use
	 * ErrorDiffusionImageRender to render the new image. ErrorDiffusion
	 * generate halftones using the Floyd-Steinberg errod diffusion algorithm.
	 * 
	 * @param aPalette java.awt.image.IndexColorModel
	 * @return com.lietu.image.objects.RawImage
	 * @category converting
	 */
	public RawImage _convertToPalette_RenderedByErrorDiffusion(IndexColorModel aPalette) {
		RawImage newImage = (RawImage) this.clone();
		int width = this.width();
		int height = this.height();

		Hashtable colorDictionary = new Hashtable();
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				Integer pixel = new Integer(newImage.getPixel(x, y));
				Color currentColor = new Color(pixel.intValue());
				if (colorDictionary.containsKey(pixel)) {
					newImage.setPixel(x, y, ((Integer) colorDictionary.get(pixel)).intValue());
				} else {
					int fit = ColorValue._MaxDistanceSquared() + 1;
					int fitRGB = 0xFF000000;
					for (int j = 0; j < aPalette.getMapSize(); j++) {
						int pixelRGB = aPalette.getRGB(j);
						Color newColor = new Color(pixelRGB);
						Integer d = ColorValue._DistanceSquaredFrom_ifLessThan_(newColor, currentColor, fit);
						if (d != null) {
							fit = d.intValue();
							fitRGB = pixelRGB;
						}
					}
					colorDictionary.put(pixel, new Integer(fitRGB));
					newImage.setPixel(x, y, fitRGB);
				}

				Color actualColor = new Color(newImage.getPixel(x, y));
				float redError = (currentColor.getRed() - actualColor.getRed()) / 16.0f;
				float greenError = (currentColor.getGreen() - actualColor.getGreen()) / 16.0f;
				float blueError = (currentColor.getBlue() - actualColor.getBlue()) / 16.0f;
				if (x < (width - 1)) {
					Color rightColor = new Color(newImage.getPixel(x + 1, y));
					rightColor =
						new Color(Math.min(255, Math.max(0, rightColor.getRed() + (int) (redError * 7))), Math.min(255, Math.max(0, rightColor.getGreen() + (int) (greenError * 7))), Math.min(255, Math.max(0, rightColor.getBlue() + (int) (blueError * 7))));
					newImage.setPixel(x + 1, y, rightColor.getRGB());
				}

				if (y < (height - 1)) {
					if (x > 0) {
						Color leftDownColor = new Color(newImage.getPixel(x - 1, y + 1));
						leftDownColor =
							new Color(
								Math.min(255, Math.max(0, leftDownColor.getRed() + (int) (redError * 3))),
								Math.min(255, Math.max(0, leftDownColor.getGreen() + (int) (greenError * 3))),
								Math.min(255, Math.max(0, leftDownColor.getBlue() + (int) (blueError * 3))));
						newImage.setPixel(x - 1, y + 1, leftDownColor.getRGB());
					}

					Color centerDownColor = new Color(newImage.getPixel(x, y + 1));
					centerDownColor =
						new Color(
							Math.min(255, Math.max(0, centerDownColor.getRed() + (int) (redError * 5))),
							Math.min(255, Math.max(0, centerDownColor.getGreen() + (int) (greenError * 5))),
							Math.min(255, Math.max(0, centerDownColor.getBlue() + (int) (blueError * 5))));
					newImage.setPixel(x, y + 1, centerDownColor.getRGB());

					if (x < (newImage.width() - 1)) {
						Color rightDownColor = new Color(newImage.getPixel(x + 1, y + 1));
						rightDownColor =
							new Color(Math.min(255, Math.max(0, rightDownColor.getRed() + (int) redError)), Math.min(255, Math.max(0, rightDownColor.getGreen() + (int) greenError)), Math.min(255, Math.max(0, rightDownColor.getBlue() + (int) blueError)));
						newImage.setPixel(x + 1, y + 1, rightDownColor.getRGB());
					}
				}
			}
		}

		return newImage;
	}

	/**
	 * Answer image representing my contents using the palette aPalette. Use
	 * NearistPatintImageRender to render the new image.
	 * 
	 * @param aPalette java.awt.image.IndexColorModel
	 * @return com.lietu.image.objects.RawImage
	 * @category converting
	 */
	public RawImage _convertToPalette_RenderedByNearistPaint(IndexColorModel aPalette) {
		int width = this.width();
		int height = this.height();
		RawImage newImage = new RawImage(width, height);

		Hashtable colorDictionary = new Hashtable();
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				Integer pixel = new Integer(this.getPixel(x, y));
				if (colorDictionary.containsKey(pixel)) {
					newImage.setPixel(x, y, ((Integer) colorDictionary.get(pixel)).intValue());
				} else {
					int fit = ColorValue._MaxDistanceSquared() + 1;
					int fitRGB = 0xFF000000;
					Color oldColor = new Color(pixel.intValue());
					for (int j = 0; j < aPalette.getMapSize(); j++) {
						int pixelRGB = aPalette.getRGB(j);
						Color newColor = new Color(pixelRGB);
						Integer d = ColorValue._DistanceSquaredFrom_ifLessThan_(newColor, oldColor, fit);
						if (d != null) {
							fit = d.intValue();
							fitRGB = pixelRGB;
						}
					}
					colorDictionary.put(pixel, new Integer(fitRGB));
					newImage.setPixel(x, y, fitRGB);
				}
			}
		}

		return newImage;
	}

	/**
	 * Print my storeable string representation on the writer.
	 * 
	 * @param aWriter java.io.Writer
	 * @exception IOException The exception description.
	 * @category printing
	 */
	public void storeOn_(Writer aWriter) throws IOException {
		aWriter.write("(Image extent: ");
		aWriter.write(String.valueOf(this.width()));
		aWriter.write('@');
		aWriter.write(String.valueOf(this.height()));
		aWriter.write(" depth: ");
		aWriter.write(String.valueOf(this.bitsPerPixel()));
		aWriter.write(" bitsPerPixel: ");
		aWriter.write(String.valueOf(this.bitsPerPixel()));
		aWriter.write(" palette: ");
		this.storePaletteOn_(aWriter);
		aWriter.write(" usingBits: ");
		(new ByteArray(this.bits())).storeOn_(aWriter);
		aWriter.write(')');
	}

	/**
	 * Print the storeable string representation of my palette on the writer.
	 * 
	 * @param aWriter java.io.Writer
	 * @exception java.io.IOException
	 * @category printing
	 */
	protected void storePaletteOn_(Writer aWriter) throws IOException {
		ColorModel colorModel = this.image().getColorModel();

		if (colorModel instanceof DirectColorModel) {
			aWriter.write("(FixedPalette redShift: ");
			aWriter.write(String.valueOf((int) (Math.log(((DirectColorModel) colorModel).getRedMask() / 255) / Math.log(2))));
			aWriter.write(" redMask: 255 greenShift: ");
			aWriter.write(String.valueOf((int) (Math.log(((DirectColorModel) colorModel).getGreenMask() / 255) / Math.log(2))));
			aWriter.write(" greenMask: 255 blueShift: ");
			aWriter.write(String.valueOf((int) (Math.log(((DirectColorModel) colorModel).getBlueMask() / 255) / Math.log(2))));
			aWriter.write(" blueMask: 255)");
		} else if (colorModel instanceof IndexColorModel) {
			IndexColorModel indexColorModel = (IndexColorModel) colorModel;
			int map_size = indexColorModel.getMapSize();
			aWriter.write("(MappedPalette withColors: ");
			aWriter.write("((Array new: " + map_size + ") ");
			for (int i = 0; i < map_size; i++) {
				aWriter.write("at: " + (i + 1) + " put: ");
				aWriter.write(ColorValue._StoreStringOf(new Color(indexColorModel.getRGB(i))));
				aWriter.write("; ");
			}
			aWriter.write(" yourself))");
		} else {
			throw new SystemException("The color model [" + colorModel.getClass() + "] is not supported yet.");
		}
	}

	/**
	 * Copy into the destination rectangle destRectangle in the receiver  those
	 * bits in the sourceImage starting at position sourcePt, according the
	 * combination rule rule.
	 * 
	 * @param destRectangle java.awt.Rectangle
	 * @param sourcePt java.awt.Point
	 * @param sourceImage com.lietu.image.objects.RawImage
	 * @param combinationRule int
	 * @return com.lietu.image.objects.RawImage
	 * @category bit processing
	 */
	public RawImage copy_from_in_rule_(Rectangle destRectangle, Point sourcePt, RawImage sourceImage, int combinationRule) {
		if (this.bounds().contains(destRectangle.x, destRectangle.y) == false) {
			return null;
		}
		if (this.bounds().contains(destRectangle.x + destRectangle.width - 1, destRectangle.y + destRectangle.height - 1) == false) {
			return null;
		}
		if (sourceImage.bounds().contains(sourcePt.x, sourcePt.y) == false) {
			return null;
		}
		if (sourceImage.bounds().contains(sourcePt.x + destRectangle.width - 1, sourcePt.y + destRectangle.height - 1) == false) {
			return null;
		}

		for (int y = 0; y < destRectangle.height; y++) {
			for (int x = 0; x < destRectangle.width; x++) {
				int srcX = sourcePt.x + x;
				int srcY = sourcePt.y + y;
				int dstX = destRectangle.x + x;
				int dstY = destRectangle.y + y;
				int newPaint = this._combinationedColorFrom_to_in_(sourceImage.getPixel(srcX, srcY), this.getPixel(dstX, dstY), combinationRule);
				this.setPixel(dstX, dstY, newPaint);
			}
		}

		return this;
	}

	/**
	 * Tile the destination rectangle destRectangle in the receiver with copies
	 * of the sourceImage, according to the combination rule rule. The
	 * sourcePt in the sourceImage is aligned with 0&064;0 in the receiver.
	 * 
	 * @param destRectangle java.awt.Rectangle
	 * @param sourcePt java.awt.Point
	 * @param sourceImage com.lietu.image.objects.RawImage
	 * @param combinationRule int
	 * @return com.lietu.image.objects.RawImage
	 * @category bit processing
	 */
	public RawImage tile_from_in_rule_(Rectangle destRectangle, Point sourcePt, RawImage sourceImage, int combinationRule) {
		if (this.bounds().contains(destRectangle.x, destRectangle.y) == false) {
			return null;
		}
		if (this.bounds().contains(destRectangle.x + destRectangle.width - 1, destRectangle.y + destRectangle.height - 1) == false) {
			return null;
		}

		int srcImageWidth = sourceImage.width();
		int srcImageHeight = sourceImage.height();
		for (int y = 0; y < destRectangle.height; y++) {
			for (int x = 0; x < destRectangle.width; x++) {
				int srcX = (sourcePt.x + x) % srcImageWidth;
				int srcY = (sourcePt.y + y) % srcImageHeight;
				int dstX = destRectangle.x + x;
				int dstY = destRectangle.y + y;
				int newPaint = this._combinationedColorFrom_to_in_(sourceImage.getPixel(srcX, srcY), this.getPixel(dstX, dstY), combinationRule);
				this.setPixel(dstX, dstY, newPaint);
			}
		}

		return this;
	}

	/**
	 * Answer the combination of the colors regarding the rule.
	 * 
	 * @param sourceColor int
	 * @param destinationColor int
	 * @param combinationRule int
	 * @return int
	 * @category 
	 */
	protected int _combinationedColorFrom_to_in_(int srcColor, int dstColor, int combinationRule) {
		switch (combinationRule) {
			case WriteZeros :
				return 0xFFFFFFFF;
			case And :
				return 0xFF000000 | (srcColor | dstColor);
			case 2 :
				return 0xFF000000 | (srcColor | ~dstColor);
			case Over :
				return 0xFF000000 | srcColor;
			case Erase :
				return 0xFF000000 | (~srcColor | dstColor);
			case 5 :
				return 0xFF000000 | dstColor;
			case Reverse :
				return 0xFF000000 | ~(~srcColor ^ ~dstColor);
			case Under :
				return 0xFF000000 | (srcColor & dstColor);
			case 8 :
				return 0xFF000000 | ~(srcColor & dstColor);
			case 9 :
				return 0xFF000000 | (~srcColor ^ ~dstColor);
			case 10 :
				return 0xFF000000 | ~dstColor;
			case 11 :
				return 0xFF000000 | ~(~srcColor | dstColor);
			case 12 :
				return 0xFF000000 | ~srcColor;
			case ReverseUnder :
				return 0xFF000000 | ~(srcColor | ~dstColor);
			case 14 :
				return 0xFF000000 | ~(srcColor | dstColor);
			case WriteOnes :
				return 0xFF000000;
		}

		throw new SystemException("unknown combination rule - " + combinationRule);
	}

	/**
	 * Fill newImage with a copy of the receiver rotated clockwise by quads * 90 degress.
	 * quads = 0 means unchnaged, 1 means clockwise 90 degrees, and so on.
	 * Answer newImage.
	 * 
	 * @return com.lietu.image.objects.RawImage
	 * @param quads int
	 * @param newImage com.lietu.image.objects.RawImage
	 * @category image processing
	 */
	public RawImage rotateByQuadrants_to_(int quads, RawImage newImage) {
		if (newImage == this) {
			return ((RawImage) this.copy()).rotateByQuadrants_to_(quads, newImage);
		}

		int angle = quads & 3; // take angle mod 360 degress
		if (angle == 0) {
			return newImage.copy_from_in_rule_(this.bounds(), new Point(0, 0), this, RawImage.Over);
		}

		Graphics2D graphics = null;
		try {
			graphics = (Graphics2D) newImage.image().getGraphics();
			if (angle == 1) {
				graphics.translate(newImage.width(), 0);
			} else if (angle == 2) {
				graphics.translate(newImage.width(), newImage.height());
			} else {
				// angle = 3
				graphics.translate(0, newImage.height());
			}
			AffineTransform transform = AffineTransform.getRotateInstance(angle * Math.PI / 2);
			graphics.drawImage(this.image(), transform, null);
		} finally {
			if (graphics != null) {
				graphics.dispose();
			}
		}

		return newImage;
	}

	/**
	 * Answer a copied image rotated clockwise by angle in units of 90 degrees.
	 * quads = 0 means unchnaged, 1 means clockwise 90 degrees, and so on.
	 * 
	 * @return com.lietu.image.objects.RawImage
	 * @param quads int
	 * @category image processing
	 */
	public RawImage rotatedByQuadrants_(int quads) {
		RawImage newImage = (quads % 2 == 0) ? this.copyEmpty() : this.copyEmpty_(new Point(this.extent().y, this.extent().x));
		return this.rotateByQuadrants_to_(quads, newImage);
	}

	/**
	 * Answer the pixel at location (x, y).
	 * 
	 * @param x int
	 * @param y int
	 * @return int
	 * @deprecated use getPixel(int x, int y) instead.
	 * @category private
	 */
	public int atX_y_(int x, int y) {
		return this.getPixel(x, y);
	}

	/**
	 * Set the pixel at location (x, y).
	 * 
	 * @param x int
	 * @param y int
	 * @param pixelValue int
	 * @deprecated use setPixel(int x, int y, int pixel) instead.
	 * @category private
	 */
	public void atX_y_put_(int x, int y, int pixelValue) {
		this.setPixel(x, y, pixelValue);
	}

	/**
	 * Flush the bit array.
	 * 
	 * @category private-bit processing
	 */
	protected void _flushBits() {
		bits = null;
	}

	/**
	 * Answer the bitmap contents of this image.
	 * 
	 * @return byte[]
	 * @category private-bit processing
	 */
	protected byte[] bits() {
		if (bits == null) {
			int width = this.width();
			int height = this.height();
			bits = new byte[rowByteSize * height];
			for (int y = 0; y < height; y++) {
				for (int x = 0; x < width; x++) {
					this._setPixelIntoBits(x, y, bits);
				}
			}
		}

		return bits;
	}

	/**
	 * Answer resized image with (x, y).
	 * 
	 * @param scaleX double
	 * @param scaleY double
	 * @return java.awt.Point
	 * @category private-image processing
	 */
	public Point scaledExtent_(double scaleX, double scaleY) {
		Double x = new Double((this.width() * 1.0) / scaleX);
		Double y = new Double((this.height() * 1.0) / scaleY);
		return new Point(x.intValue(), y.intValue());
	}

	/**
	 * Restores this object from a object stream (i.e., deserializes it).
	 * 
	 * @param stream java.io.ObjectInputStream
	 * @exception IOException
	 * @exception ClassNotFoundException
	 * @category private-serializing
	 */
	private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
		stream.defaultReadObject();

		// read width, height and pixels.
		int width = stream.readInt();
		int height = stream.readInt();
		int[] pixels = (int[]) stream.readObject();

		// read ColorModel.
		String colorModelName = stream.readUTF();
		ColorModel colorModel = null;
		if (colorModelName.equals("DirectColorModel")) {
			int pixelSize = stream.readInt();
			int redMask = stream.readInt();
			int greenMask = stream.readInt();
			int blueMask = stream.readInt();
			int alphaMask = stream.readInt();
			colorModel = new DirectColorModel(pixelSize, redMask, greenMask, blueMask, alphaMask);
		} else if (colorModelName.equals("IndexColorModel")) {
			int pixelSize = stream.readInt();
			int mapSize = stream.readInt();
			byte[] r = new byte[mapSize];
			byte[] g = new byte[mapSize];
			byte[] b = new byte[mapSize];
			byte[] a = new byte[mapSize];
			for (int i = 0; i < mapSize; i++) {
				r[i] = (byte) stream.read();
			}
			for (int i = 0; i < mapSize; i++) {
				g[i] = (byte) stream.read();
			}
			for (int i = 0; i < mapSize; i++) {
				b[i] = (byte) stream.read();
			}
			for (int i = 0; i < mapSize; i++) {
				a[i] = (byte) stream.read();
			}
			colorModel = new IndexColorModel(pixelSize, mapSize, r, g, b, a);
		} else {
			throw new IOException("The color model [" + colorModel.getClass() + "] is not supported yet.");
		}

		// create image.
		image = new BufferedImage(colorModel, colorModel.createCompatibleWritableRaster(width, height), false, null);
		rowByteSize = (width * this.bitsPerPixel() + 31) >> 5 << 2;
		this.setPixels(pixels);
	}

	/**
	 * Writes this object out to a stream (i.e., serializes it).
	 * 
	 * @param stream java.io.ObjectOutputStream
	 * @exception IOException
	 * @exception ClassNotFoundException
	 * @category private-serializing
	 */
	private void writeObject(ObjectOutputStream stream) throws IOException, ClassNotFoundException {
		stream.defaultWriteObject();

		// write width, height and pixels.
		stream.writeInt(this.width());
		stream.writeInt(this.height());
		stream.writeObject(this.getPixels());

		// write ColorModel.
		ColorModel colorModel = this.image().getColorModel();
		if (colorModel instanceof DirectColorModel) {
			DirectColorModel directColorModel = (DirectColorModel) colorModel;
			stream.writeUTF("DirectColorModel");
			stream.writeInt(directColorModel.getPixelSize());
			stream.writeInt(directColorModel.getRedMask());
			stream.writeInt(directColorModel.getGreenMask());
			stream.writeInt(directColorModel.getBlueMask());
			stream.writeInt(directColorModel.getAlphaMask());
		} else if (colorModel instanceof IndexColorModel) {
			IndexColorModel indexColorModel = (IndexColorModel) colorModel;
			stream.writeUTF("IndexColorModel");
			stream.writeInt(indexColorModel.getPixelSize());
			stream.writeInt(indexColorModel.getMapSize());
			byte[] bytes = new byte[indexColorModel.getMapSize()];
			indexColorModel.getReds(bytes);
			stream.write(bytes, 0, bytes.length);
			indexColorModel.getGreens(bytes);
			stream.write(bytes, 0, bytes.length);
			indexColorModel.getBlues(bytes);
			stream.write(bytes, 0, bytes.length);
			indexColorModel.getAlphas(bytes);
			stream.write(bytes, 0, bytes.length);
		} else {
			throw new IOException("The color model [" + colorModel.getClass() + "] is not supported yet.");
		}
	}
}
