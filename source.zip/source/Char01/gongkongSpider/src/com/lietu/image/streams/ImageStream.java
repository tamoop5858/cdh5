package com.lietu.image.streams;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Hashtable;

import com.lietu.image.objects.RawImage;
import com.lietu.image.objects.BaseObject;

/**
 * ImageStream class
 * 
 *  @author    
 *  @created   2005/11/14
 *  @version   1.0.0
 *  @copyright 
 * 
 */
public abstract class ImageStream extends BaseObject {
	protected InputStream inStream;
	protected OutputStream outStream;
	protected RawImage imageObject;

	//
	private static Hashtable ImageKindTable;
	static {
		ImageKindTable = _InitializeImageKindTable();
	}

	/**
	 * Answer a Class of image stream.
	 * 
	 * @return java.lang.Class
	 * @param aFilename java.io.File
	 * @category Accessing
	 */
	public static Class ImageStreamClassForFileName_(File aFilename) {
		return ImageStreamClassForFileName_(aFilename.toString());
	}

	/**
	 * Answer a Class of image stream.
	 * 
	 * @return java.lang.Class
	 * @param aFilename java.lang.String
	 * @category Accessing
	 */
	public static Class ImageStreamClassForFileName_(String aFilename) {
		String aString = aFilename.substring(aFilename.lastIndexOf('.') + 1).toLowerCase();
		String aSymbol = (String) ImageKindTable.get(aString);
		if (aSymbol == null) {
			return null;
		}
		Class aClass = null;
		try {
			aClass = Class.forName(aSymbol);
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return aClass;
	}

	/**
	 * Constractor with input stream.
	 * 
	 * @return com.lietu.image.streams.ImageStream
	 * @param stream java.io.InputStream
	 * @exception java.io.IOException
	 * @category Instance creation
	 */
	public static ImageStream On_(InputStream stream) throws IOException {
		throw new IOException("subclassResponsibilitty");
	}

	/**
	 * Constractor with output stream.
	 * 
	 * @return com.lietu.image.streams.ImageStream
	 * @param stream java.io.OutputStream
	 * @exception java.io.IOException
	 * @category Instance creation
	 */
	public static ImageStream On_(OutputStream stream) throws IOException {
		throw new IOException("subclassResponsibilitty");
	}

	/**
	 * Initialize image kind table.
	 * 
	 * @return java.util.Hashtable
	 * @category Class initialization
	 */
	private static Hashtable _InitializeImageKindTable() {
		if (ImageKindTable == null) {
			Hashtable aDictionary = new Hashtable();
			aDictionary.put("bmp", "com.lietu.image.streams.BmpImageStream");
			aDictionary.put("jpg", "com.lietu.image.streams.JpegImageStream");
			aDictionary.put("jpeg", "com.lietu.image.streams.JpegImageStream");
			aDictionary.put("png", "com.lietu.image.streams.PngImageStream");
			aDictionary.put("gif", "com.lietu.image.streams.GifImageStream");
			aDictionary.put("giff", "com.lietu.image.streams.GifImageStream");
			ImageKindTable = aDictionary;
		}
		return ImageKindTable;
	}

	/**
	 * Constractor with image stream and input stream.
	 * 
	 * @return com.lietu.image.streams.ImageStream
	 * @param imageStream com.lietu.image.streams.ImageStream
	 * @param stream java.io.InputStream
	 * @exception java.io.IOException
	 * @category Instance creation
	 */
	protected static ImageStream On_(ImageStream imageStream, InputStream stream) throws IOException {
		if (imageStream == null) {
			throw new IOException("could not load image");
		}
		imageStream.on_(stream);
		return imageStream;
	}

	/**
	 * Constractor with image stream and output stream.
	 * 
	 * @return com.lietu.image.streams.ImageStream
	 * @param imageStream com.lietu.image.streams.ImageStream
	 * @param stream java.io.OutputStream
	 * @exception java.io.IOException
	 * @category Instance creation
	 */
	protected static ImageStream On_(ImageStream imageStream, OutputStream stream) throws IOException {
		if (imageStream == null) {
			throw new IOException("could not save image");
		}
		imageStream.on_(stream);
		return imageStream;
	}

	/**
	 * This image stream close.
	 * 
	 * @exception IOException java.io.IOException
	 * @category stream access
	 */
	public void close() throws IOException {
		if (inStream != null) {
			inStream.close();
			inStream = null;
		}
		if (outStream != null) {
			outStream.close();
			outStream = null;
		}
	}

	/**
	 * This image stream flush.
	 * 
	 * @exception java.io.IOException
	 * @category stream access
	 */
	public void flush() throws IOException {
		if (outStream != null) {
			outStream.flush();
		}
	}

	/**
	 * Read the image on input stream.
	 * 
	 * @return com.lietu.image.objects.RawImage
	 * @exception java.io.IOException
	 * @category accessing
	 */
	public abstract RawImage nextImage() throws IOException;

	/**
	 * Write the image on output stream.
	 * 
	 * @param newImage com.lietu.image.objects.RawImage
	 * @exception java.io.IOException
	 * @category accessing
	 */
	public abstract void nextPutImage_(RawImage newImage) throws IOException;

	/**
	 * Set the input stream.
	 * 
	 * @param stream java.io.InputStream
	 * @exception java.io.IOException
	 * @category initialize-release
	 */
	protected void on_(InputStream stream) throws IOException {
		inStream = stream;
	}

	/**
	 * Set the output stream.
	 * 
	 * @param stream java.io.OutputStream
	 * @exception java.io.IOException
	 * @category initialize-release
	 */
	protected void on_(OutputStream stream) throws IOException {
		outStream = stream;
	}
}
