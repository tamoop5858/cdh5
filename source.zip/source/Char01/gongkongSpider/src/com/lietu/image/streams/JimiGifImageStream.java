package com.lietu.image.streams;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import com.sun.jimi.core.Jimi;
import com.lietu.image.objects.RawImage;

/**
 * JimiGifImageStream class
 * 
 *  @author    
 *  @created   2005/11/14
 *  @version   1.0.0
 *  @copyright 
 * 
 */
public class JimiGifImageStream extends GifImageStream {
	/**
	 * Constractor with input stream.
	 *
	 * @return com.lietu.image.streams.ImageStream 
	 * @param stream java.io.InputStream
	 * @exception java.io.IOException
	 * @category Instance creation
	 */
	public static ImageStream On_(InputStream stream) throws IOException {
		return On_(new JimiGifImageStream(), stream);
	}

	/**
	 * Constractor with output stream.
	 *
	 * @return com.lietu.image.streams.ImageStream 
	 * @param stream java.io.OutputStream
	 * @exception java.io.IOException
	 * @category Instance creation
	 */
	public static ImageStream On_(OutputStream stream) throws IOException {
		throw new IOException("could not save image");
	}

	/**
	 * Write the image on write stream.
	 * (used JIMI Software Development Kit)
	 * 
	 * @return com.lietu.image.objects.RawImage
	 * @exception java.io.IOException
	 * @category accessing
	 */
	public RawImage nextImage() throws IOException {
		if (inStream != null) {
			imageObject = new RawImage(Jimi.getImage(inStream, "image/gif"));
		}
		return imageObject;
	}

	/**
	 * Read the image on input stream.
	 * (used JIMI Software Development Kit)
	 *
	 * @param newImage com.lietu.image.objects.RawImage
	 * @exception java.io.IOException
	 * @category accessing
	 */
	public void nextPutImage_(RawImage newImage) throws IOException {
		throw new IOException("could not save image");
	}

	/**
	 * Set the output stream.
	 * 
	 * @param stream java.io.OutputStream
	 * @exception java.io.IOException
	 * @category initialize-release
	 */
	protected void on_(OutputStream stream) throws IOException {
		throw new IOException("could not save image");
	}
}
