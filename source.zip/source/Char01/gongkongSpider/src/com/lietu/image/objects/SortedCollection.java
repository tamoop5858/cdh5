package com.lietu.image.objects;

import java.util.*;

/**
 * SortedCollection class
 * 
 *  @author    
 *  @created   2005/11/14
 *  @version   1.0.0
 *  @copyright 
 * 
 */
public class SortedCollection extends BaseObject {
	/** The block closure for comparing two elements. */
	protected BlockClosure sortBlock = null;

	/** The collection which holds the elements in order. */
	protected Vector _elements = new Vector();

	/**
	 * Create a new instance of SortedCollection with a sort block.
	 * 
	 * @param aBlock com.lietu.image.objects.BlockClosure
	 */
	public SortedCollection(BlockClosure aBlock) {
		super();
		this.sortBlock_(aBlock);
	}

	/**
	 * Create a new instance of SortedCollection with a sort block.
	 * 
	 * @param aBlock com.lietu.image.objects.BlockClosure
	 * @param anArray java.lang.Object[]
	 */
	public SortedCollection(BlockClosure aBlock, Object[] anArray) {
		this(aBlock);

		for (int i = 0; i < anArray.length; i++) {
			this.add_(anArray[i]);
		}
	}

	/**
	 * Create a new instance of SortedCollection with a sort block.
	 * 
	 * @param aBlock com.lietu.image.objects.BlockClosure
	 * @param aCollection DOCUMENT ME!
	 */
	public SortedCollection(BlockClosure aBlock, Vector aCollection) {
		this(aBlock);

		Object[] anArray = new Object[aCollection.size()];

		aCollection.copyInto(anArray);

		for (int i = 0; i < anArray.length; i++) {
			this.add_(anArray[i]);
		}
	}

	/**
	 * Need to specify the sort block.
	 */
	private SortedCollection() {
	}

	/**
	 * Answer the receiver's elements as array.
	 * 
	 * @return java.lang.Object[]
	 */
	public Object[] _asArray() {
		Object[] newArray = new Object[_elements.size()];

		_elements.copyInto(newArray);

		return newArray;
	}

	/**
	 * Answer the receiver's elements as a collection.
	 * 
	 * @return java.util.Collection
	 */
	public Collection _asCollection() {
		return new Vector(_elements);
	}

	/**
	 * Add the new object as one of the receiver's element.
	 * 
	 * @param newObject java.lang.Object
	 * 
	 * @return java.lang.Object
	 */
	public synchronized Object add_(Object newObject) {
		if (_elements.isEmpty()) {
			_elements.addElement(newObject);
		} else {
			int nextIndex = this.indexForInserting_(newObject);

			_elements.insertElementAt(newObject, nextIndex);
		}

		return newObject;
	}

	/**
	 * Answer the first element of the collection.
	 * 
	 * @return java.lang.Object
	 */
	public synchronized Object first() {
		return _elements.firstElement();
	}

	/**
	 * Answer the last element of the collection.
	 * 
	 * @return java.lang.Object
	 */
	public synchronized Object last() {
		return _elements.lastElement();
	}

	/**
	 * Answer my size.
	 * 
	 * @return int
	 */
	public int size() {
		return _elements.size();
	}

	/**
	 * Set the sort block of the receiver.
	 * 
	 * @param aBlock com.lietu.image.objects.BlockClosure
	 */
	public void sortBlock_(BlockClosure aBlock) {
		sortBlock = aBlock;
	}

	/**
	 * Compare the two elements.
	 * 
	 * @param e1 java.lang.Object
	 * @param e2 java.lang.Object
	 * 
	 * @return boolean
	 * 
	 * @throws SystemException DOCUMENT ME!
	 */
	private boolean compareElement_to_(Object e1, Object e2) {
		if (sortBlock == null) {
			throw new SystemException("No sort block.");
		}

		return ((Boolean) sortBlock.value_value_(e1, e2)).booleanValue();
	}

	/**
	 * Answer the index for inserting the new object.
	 * 
	 * @param newObject java.lang.Object
	 * 
	 * @return int
	 */
	private int indexForInserting_(Object newObject) {
		int low = 0;
		int high = _elements.size() - 1;
		int index = (high + low) / 2;

		while (low <= high) {
			if (this.compareElement_to_(_elements.elementAt(index), newObject)) {
				low = index + 1;
			} else {
				high = index - 1;
			}

			index = (high + low) / 2;
		}

		return low;
	}
}
