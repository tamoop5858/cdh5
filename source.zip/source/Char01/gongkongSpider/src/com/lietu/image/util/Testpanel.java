package com.lietu.image.util;

import java.awt.*;

import javax.swing.JPanel;

import java.awt.color.ColorSpace;
import java.awt.event.*;
import java.awt.image.*;
import java.awt.geom.*;
import javax.swing.*; 
import javax.swing.plaf.metal.MetalBorders.PaletteBorder;



import sun.awt.image.PixelConverter.Rgba;
class Testpanel extends JPanel {	
	public   RenderingHints   DefaultRenderingHints   =   new   RenderingHints(   
            RenderingHints.KEY_ALPHA_INTERPOLATION,   
            RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);   

	public BorderLayout borderLayout1=new BorderLayout();	
	BufferedImage bi,biSrc,biDest;	
	Graphics2D big;	
	Image im1;	
	public int w,h,flag;	
	float scaleFactor=1.0f;
	float offset=0.0f;
	
	public  Testpanel(){
	  try
	   {
	    jbInit();
	   }
	  catch(Exception ex)
	  {
	   ex.printStackTrace();
	  }
	}
	 void jbInit() throws Exception{
	  this.setLayout(borderLayout1);
	  Panel pdown;
	  pdown=new Panel();
	  Button sharpen=new Button("sharpen");
	  Button gray=new Button("gray");
	  Button edge=new Button("edge");
	  Button reset=new Button("reset");
	  pdown.setBackground(Color.lightGray);
	  pdown.setLayout(new GridLayout(2,0));
	  pdown.add(sharpen);
	  pdown.add(gray);
	  pdown.add(edge);
	  pdown.add(reset);
	  this.setLayout(new BorderLayout());
	  this.add(pdown,BorderLayout.SOUTH);
	  MediaTracker tracker=new MediaTracker(this);
	  im1=Toolkit.getDefaultToolkit().getImage("D:/lg/ocr/sample-images/yello.png");
	  tracker.addImage(im1,0);
	  try{
		  tracker.waitForID(0);
	  }
	  catch(Exception e)
	  {
		  e.printStackTrace();
	  }
	  w=im1.getWidth(this);
	  h=im1.getHeight(this);
	  biSrc=new BufferedImage(w,h,BufferedImage.TYPE_INT_RGB);
	  big=biSrc.createGraphics();
	  big.drawImage(im1 ,0,0,this);
	  biDest=new BufferedImage(w,h,BufferedImage.TYPE_INT_RGB);
	  bi=biSrc;
	    sharpen.addActionListener(new ActionListener(){
	
		  public void actionPerformed(ActionEvent e){
			  sharpen_actionPerformed(e);
			  repaint();
	      }
		  }
	  );
    	edge.addActionListener(new ActionListener(){
	     public void actionPerformed(ActionEvent e){
	     edge_actionPerformed(e);
	     repaint();}
	   }
	);
	    gray.addActionListener(new ActionListener(){
	     public void actionPerformed(ActionEvent e){
		  try {
			gray_actionPerformed(e);
		} catch (AWTException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		  repaint();
		  }
	  });
	   reset.addActionListener(new ActionListener(){
	     public void actionPerformed(ActionEvent e){
		  reset_actionPerformed(e);
		  repaint();
	  	}
	  }
	);
	}
	public void sharpen_actionPerformed(ActionEvent e){
		
    	float data[]={-1.0f,-1.0f,-1.0f,
    				   -1.0f,9.0f,-1.0f,
			          -1.0f,-1.0f,-1.0f}; 
    	Kernel kernel=new Kernel(3,3,data);
    	ConvolveOp convolve=new ConvolveOp(kernel,ConvolveOp.EDGE_NO_OP,null);
    	convolve.filter(biSrc,biDest);
    	bi=biDest;
	}
	public void edge_actionPerformed(ActionEvent e){
		float data[]={0.0f,-1.0f,0.0f,
			-1.0f,4.0f,-1.0f,
			0.0f,-1.0f,0.0f};
		Kernel kernel=new Kernel(3,3,data);
		ConvolveOp convolve=new ConvolveOp(kernel,ConvolveOp.EDGE_NO_OP,null);
		convolve.filter(biSrc,biDest);
		bi=biDest;
		}

	
	/*public Bitmap ConvertToGrayscale(Bitmap source)

	{

	  Bitmap bm = new Bitmap(source.Width,source.Height);

	  for(int y=0;y<bm.Height;y++)

	  {

	    for(int x=0;x<bm.Width;x++)

	    {

	      Color c=source.GetPixel(x,y);

	      int luma = (int)(c.R*0.3 + c.G*0.59+ c.B*0.11);

	      bm.SetPixel(x,y,Color.FromArgb(luma,luma,luma));

	    }*/

	public void gray_actionPerformed(ActionEvent e) throws AWTException{
		//ͼ��ĻҶȴ���
		ColorSpace cs = ColorSpace.getInstance(ColorSpace.CS_GRAY);
		ColorConvertOp cop = new ColorConvertOp(cs,DefaultRenderingHints);    // �����һ���ɫת����
		cop.filter(biSrc,biDest);
		bi=biDest; 	
		//�ڰ״���
		//int[] pix=new int[w*h];

//		��Ϊ�Ƕ�ֵͼ������ķ��������ض�ȡ������ͬʱ��ת��Ϊ0��1��ͼ�����顣
	
	/*	for(int i=0;i<h;i++)

		  {
		    for(int j=0;j<w;j++)

		    {
		    	 // pix[i*(w)+j]=biSrc.getRGB(j,i);
		    	int c=biSrc.getRGB(j,i);
		    	Color cc=(Color)c;
		    	 int luma = (cc.RED*0.3 + c*0.59+ c*0.11);
				 //  bi.setRGB(j,i,pix[i*(w)+j]);
		    	 bi.setRGB(j,i,luma);
		    }
		}*/
		//   bi.setRGB(0, 0, w, h, pix, 0, flag);
	}
	public void reset_actionPerformed(ActionEvent e){
		bi=biSrc;
		}
	public void paint(Graphics g){
		Graphics2D g2d=(Graphics2D)g;
		g2d.drawImage(bi,0,0,this);
		}

}
	


