package com.lietu.image.streams;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.lietu.image.objects.RawImage;
import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGImageDecoder;
import com.sun.image.codec.jpeg.JPEGImageEncoder;

/**
 * Java2JpegImageStream class
 * 
 *  @author    
 *  @created   2005/11/14
 *  @version   1.0.0
 *  @copyright 
 * 
 */
public class Java2JpegImageStream extends JpegImageStream {
	/**
	 * Constractor with input stream.
	 * 
	 * @return com.lietu.image.streams.ImageStream
	 * @param stream java.io.InputStream
	 * @exception java.io.IOException
	 * @category Instance creation
	 */
	public static ImageStream On_(InputStream stream) throws IOException {
		return On_(new Java2JpegImageStream(), stream);
	}

	/**
	 * Constractor with output stream.
	 * 
	 * @return com.lietu.image.streams.ImageStream
	 * @param stream java.io.OutputStream
	 * @exception java.io.IOException
	 * @category Instance creation
	 */
	public static ImageStream On_(OutputStream stream) throws IOException {
		return On_(new Java2JpegImageStream(), stream);
	}

	/**
	 * Read the image on input stream. (used Java2 core API)
	 * 
	 * @return com.lietu.image.objects.RawImage
	 * @exception java.io.IOException
	 * @category accessing
	 */
	public RawImage nextImage() throws IOException {
		if (inStream != null) {
			JPEGImageDecoder imageDecoder = JPEGCodec.createJPEGDecoder(inStream);
			BufferedImage anImage = imageDecoder.decodeAsBufferedImage();
			imageObject = new RawImage(anImage);
		}
		return imageObject;
	}

	/**
	 * Write the image on output stream. (used Java2 core API)
	 * 
	 * @param newImage com.lietu.image.objects.RawImage
	 * @exception java.io.IOException
	 * @category accessing
	 */
	public void nextPutImage_(RawImage newImage) throws IOException {
		if (outStream != null) {
			imageObject = newImage;

			int width = imageObject.width();
			int height = imageObject.height();
			BufferedImage anImage = new BufferedImage(width, height, BufferedImage.TYPE_3BYTE_BGR);
			anImage.setRGB(0, 0, width, height, imageObject.getPixels(), 0, width);
			JPEGImageEncoder imageEncoder = JPEGCodec.createJPEGEncoder(outStream);
			imageEncoder.encode(anImage);
		}
	}
}
