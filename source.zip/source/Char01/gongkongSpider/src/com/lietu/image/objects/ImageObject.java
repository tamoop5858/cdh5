package com.lietu.image.objects;

import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.MediaTracker;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.Vector;
import com.lietu.image.streams.ImageStream;
import com.lietu.image.streams.JpegImageStream;

/**
 * ImageObject class
 * 
 *  @author    
 *  @created   2005/11/14
 *  @version   1.0.0
 *  @copyright 
 * 
 */
public class ImageObject extends BaseObject implements Serializable {
	// Serialize version
	private static final long serialVersionUID = -1849240035520800010L;

	protected String fileName;
	protected long modifiedDate;
	public RawImage iconImage;
	protected Rectangle iconArea;
	protected Color[] nineColors;
	protected Color averageColor;
	protected Color typicalColor;
	protected java.awt.geom.Point2D.Double centerSpectra;
	protected RawImage xSpectrum;
	protected RawImage ySpectrum;
	protected RawImage renderingImage;

	/**
	 * Answer default icon size.
	 * 
	 * @return int
	 */
	public static int DefaultSize() {
		return 100;
	}

	/**
	 * Answer my file name.
	 * 
	 * @return java.io.File
	 */
	public File asFilename() {
		return new File(this.fileName());
	}

	/**
	 * Answer default icon size.
	 * 
	 * @return int
	 */
	public int defaultSize() {
		return ImageObject.DefaultSize();
	}

	/**
	 * Answer my file name.
	 * 
	 * @return java.lang.String
	 */
	public String fileName() {
		return fileName;
	}

	/**
	 * Answer my icon image.
	 * 
	 * @return com.lietu.image.objects.RawImage
	 */
	/*public RawImage iconImage() {
		if (iconImage == null) {
			Vector array = ImageProcessor.Icon3_size_(this.originalImage(), this.defaultSize());

			iconImage = (RawImage) array.firstElement();
			iconArea = (Rectangle) array.lastElement();
			int[] bits = new int[this.defaultSize() * this.defaultSize()];
			for (int i = 0; i < bits.length; i++) {
				bits[i] = 0x00FFFFFF;
			}
			RawImage shape = new RawImage(this.defaultSize(), this.defaultSize(), bits);
			ImageProcessor.Fill_rectangle_color_(shape, iconArea, Color.black);
			iconImage = ImageProcessor._MakeImage_Shape_(iconImage, shape);
		}
		return iconImage;
	}*/

	/**
	 * Answer my image file modified date.
	 * 
	 * @return long
	 */
	public long modifiedDate() {
		return modifiedDate;
	}

	/**
	 * Answer my image from file.
	 * 
	 * 
	 * @return com.lietu.image.objects.RawImage
	 */
	public RawImage originalImage() {
		RawImage anImage = null;
		String string = this.asFilename().getAbsolutePath();
		if (string.toLowerCase().endsWith(".jpg")) {
			ImageStream imageStream = null;
			File file = new File(string);
			try {
				imageStream = JpegImageStream.On_(new FileInputStream(file));
				anImage = imageStream.nextImage();
			} catch (Exception e) {
				// used via Java core API.
				Frame frame = new Frame();
				Toolkit toolKit = frame.getToolkit();
				Image image = toolKit.getImage(string);
				MediaTracker mt = new MediaTracker(frame);
				mt.addImage(image, 0);
				try {
					mt.waitForAll();
				} catch (InterruptedException exception) {
					System.err.println("image load interrupted.");
					return null;
				}
				int status = mt.statusAll(false);
				if (((status & MediaTracker.ABORTED) != 0) || ((status & MediaTracker.ERRORED) != 0)) {
					System.err.println("could not load image.");
					return null;
				}
				anImage = new RawImage(image);
				image = null;
			} finally {
				if (imageStream != null) {
					try {
						imageStream.close();
						imageStream = null;
					} catch (IOException e) {
					}
				}
			}
		} else {
			System.err.println("unknown image format");
			return null;
		}
		return anImage;
	}

	/**
	 * Cleanup my variables.
	 */
	protected void flushCaches() {
		iconImage = null;
		iconArea = null;
		nineColors = null;
		averageColor = null;
		typicalColor = null;
		centerSpectra = null;
		xSpectrum = null;
		ySpectrum = null;
		renderingImage = null;
	}

	/**
	 * Set filename and image folder.
	 * 
	 * @param aString java.lang.String
	 * @param anImageFolder com.lietu.image.objects.ImageFolder
	 * 
	 * @return com.lietu.image.objects.ImageObject
	 */
	protected ImageObject setFileName_imageFolder_(String aString) {
		fileName = aString;
		modifiedDate = this.asFilename().lastModified();
		return null;
	}

	/**
	 * Answer xSpectrum_height_
	 * 
	 * 
	 * @return com.lietu.image.objects.RawImage
	 * @param spectrum java.lang.Object[] (com.lietu.image.objects.Association[])
	 * @param height int
	 */
	protected RawImage xSpectrum_height_(Object[] spectrum, int height) {
		RawImage image = new RawImage(spectrum.length, height);
		Graphics gc = image.image().getGraphics();
		if (gc instanceof Graphics2D) {
			((Graphics2D) gc).setBackground(Color.white);
		}

		for (int i = 0; i < spectrum.length; i++) {
			Association assoc = (Association) spectrum[i];
			int x = ((Integer) assoc.key()).intValue();
			int value = Math.round((((Double) assoc.value()).floatValue()) * height);
			gc.setColor(Color.black);
			gc.fillRect(x, 0, 1, value);
		}
		return image;
	}

	/**
	 * Answer ySpectrum_width_
	 * 
	 * 
	 * @return com.lietu.image.objects.RawImage
	 * @param spectrum java.lang.Object[] (com.lietu.image.objects.Association[])
	 * @param width int
	 */
	protected RawImage ySpectrum_width_(Object[] spectrum, int width) {
		RawImage image = new RawImage(width, spectrum.length);
		Graphics gc = image.image().getGraphics();
		if (gc instanceof Graphics2D) {
			((Graphics2D) gc).setBackground(Color.white);
		}

		for (int i = 0; i < spectrum.length; i++) {
			Association assoc = (Association) spectrum[i];
			int y = ((Integer) assoc.key()).intValue();
			int value = Math.round((((Double) assoc.value()).floatValue()) * width);
			gc.setColor(Color.black);
			gc.fillRect(0, y, value, 1);
		}
		return image;
	}
}
