package com.lietu.image.objects;

import java.io.IOException;
import java.io.Writer;
import java.lang.IndexOutOfBoundsException;

/**
 * Interval class
 * 
 *  @author    
 *  @created   2005/11/14
 *  @version   1.0.0
 *  @copyright 
 * 
 */
public class Interval extends BaseObject {
	/** initial number in the progression. */
	private double start;

	/** last number in the progression. */
	private double stop;

	/** increment number for determining the next number in the progression. */
	private double step = 1.0;

	/**
	 * Creates a new Interval object.
	 */
	public Interval() {
		super();
	}

	/**
	 * Create a new Interval.
	 * 
	 * @param startNumber double
	 * @param stopNumber double
	 */
	public Interval(double startNumber, double stopNumber) {
		super();
		this.setFrom_to_by_(startNumber, stopNumber, 1);
	}

	/**
	 * Create a new Interval.
	 * 
	 * @param startNumber double
	 * @param stopNumber double
	 * @param stepNumber double
	 */
	public Interval(double startNumber, double stopNumber, double stepNumber) {
		super();
		this.setFrom_to_by_(startNumber, stopNumber, stepNumber);
	}

	/**
	 * Create a new Interval.
	 * 
	 * @param startNumber double
	 * @param stopNumber double
	 * 
	 * @return DOCUMENT ME!
	 */
	public static Interval From_to_(double startNumber, double stopNumber) {
		Interval interval = new Interval();

		interval.setFrom_to_by_(startNumber, stopNumber, 1);

		return interval;
	}

	/**
	 * Create a new Interval.
	 * 
	 * @param startNumber double
	 * @param stopNumber double
	 * @param stepNumber DOCUMENT ME!
	 * 
	 * @return DOCUMENT ME!
	 */
	public static Interval From_to_by_(double startNumber, double stopNumber, double stepNumber) {
		Interval interval = new Interval();

		interval.setFrom_to_by_(startNumber, stopNumber, stepNumber);

		return interval;
	}

	/**
	 * Computes the number of the index of this progression.
	 * 
	 * @param index
	 * 
	 * @return double
	 * 
	 * @throws IndexOutOfBoundsException DOCUMENT ME!
	 */
	public double at_(int index) {
		if ((index >= 1) && (index <= this.size())) {
			return start + (step * (index - 1));
		}

		throw new IndexOutOfBoundsException("size: " + this.size() + " index: " + index);
	}

	/**
	 * Enumerate all elements of the receiver and evaluate the BlockClosure.
	 * 
	 * @param aBlock
	 * 
	 * @return double[]
	 */
	public double[] collect_(BlockClosure aBlock) {
		double[] result = new double[this.size()];
		double nextValue = start;

		for (int i = 0; i < result.length; i++) {
			result[i] = ((Double) (aBlock.value_(new Double(nextValue)))).doubleValue();
			nextValue += step;
		}

		return result;
	}

	/**
	 * Enumerate all elements of the receiver and evaluate the BlockClosure.
	 * 
	 * @param aBlock
	 */
	public void do_(BlockClosure aBlock) {
		double value = start;

		if (step < 0) {
			while (stop <= value) {
				aBlock.value_(new Double(value));
				value += step;
			}
		} else {
			while (stop >= value) {
				aBlock.value_(new Double(value));
				value += step;
			}
		}
	}

	/**
	 * Answer true if the Object is equal to the receiver, otherwise false.
	 * 
	 * @param other java.lang.Object
	 * 
	 * @return boolean
	 * 
	 * @see java.util.Hashtable
	 */
	public boolean equals(Object other) {
		if (other.getClass() == this.getClass()) {
			Interval aInterval = (Interval) other;

			return ((this.start == (aInterval.start)) && (this.step == (aInterval.increment())) && (this.size() == aInterval.size()));
		}

		return false;
	}

	/**
	 * initinal number of this progression.
	 * 
	 * @return double
	 */
	public double first() {
		return start;
	}

	// Hash Function

	/**
	 * Computes a hash code for this object.
	 * 
	 * @return int
	 * 
	 * @see java.util.Hashtable
	 */
	public int hashCode() {
		long bitsStart = Double.doubleToLongBits(start);
		int startHash = (int) (bitsStart ^ (bitsStart >> 32));
		long bitsStop = Double.doubleToLongBits(stop);
		int stopHash = (int) (bitsStop ^ (bitsStop >> 32));

		return (((startHash >> 2) | stopHash) >> 1 | this.size());
	}

	/**
	 * increment number of this progression.
	 * 
	 * @return double
	 */
	public double increment() {
		return step;
	}

	/**
	 * Computes the last number of this progression.
	 * 
	 * @return double
	 */
	public double last() {
		return stop - ((stop - start) % step);
	}

	/**
	 * Print my string representation on aWriter.
	 * 
	 * @param aWriter java.io.Writer
	 * 
	 * @throws IOException DOCUMENT ME!
	 */
	public void printOn_(Writer aWriter) throws IOException {
		aWriter.write("(" + start + " to: " + stop);

		if (step != 1) {
			aWriter.write(" by: " + step);
		}

		aWriter.write(")");
	}

	/**
	 * Enumerate all elements of the receiver and evaluate the BlockClosure.
	 * 
	 * @param aBlock
	 */
	public void reverseDo_(BlockClosure aBlock) {
		double value = stop;

		if (step < 0) {
			while (start >= value) {
				aBlock.value_(new Double(value));
				value -= step;
			}
		} else {
			while (start <= value) {
				aBlock.value_(new Double(value));
				value -= step;
			}
		}
	}

	/**
	 * Computes the size of this progression.
	 * 
	 * @return int
	 */
	public int size() {
		int size = 0;

		if (step < 0) {
			if (!(start < stop)) {
				size = (int) ((stop - start) / step) + 1;
			}
		} else {
			if (!(stop < start)) {
				size = (int) ((stop - start) / step) + 1;
			}
		}

		return size;
	}

	/**
	 * get initial number in the progression.
	 * 
	 * @return double
	 */
	public double start() {
		return this.start;
	}

	/**
	 * set initial number in the progression.
	 * 
	 * @param startValue
	 * 
	 * @return double
	 */
	public double start_(double startValue) {
		return this.start = startValue;
	}

	/**
	 * get increment number for determining the next number in the progression.
	 * 
	 * @return double
	 */
	public double step() {
		return this.step;
	}

	/**
	 * set increment number for determining  the next number in the
	 * progression.
	 * 
	 * @param stepValue
	 * 
	 * @return double
	 */
	public double step_(double stepValue) {
		return this.step = stepValue;
	}

	/**
	 * get last number in the progression.
	 * 
	 * @return double
	 */
	public double stop() {
		return this.stop;
	}

	/**
	 * set last number in the progression.
	 * 
	 * @param stopValue
	 * 
	 * @return double
	 */
	public double stop_(double stopValue) {
		return this.stop = stopValue;
	}

	/**
	 * Store my string representation on the writer.
	 * 
	 * @param aWriter java.io.Writer
	 * 
	 * @throws IOException DOCUMENT ME!
	 */
	public void storeOn_(Writer aWriter) throws IOException {
		this.printOn_(aWriter);
	}

	/**
	 * private
	 * 
	 * @param startNumber
	 * @param stopNumber
	 * @param stepNumber
	 * 
	 * @return com.lietu.image.objects.Interval
	 */
	private Interval setFrom_to_by_(double startNumber, double stopNumber, double stepNumber) {
		this.start = startNumber;
		this.stop = stopNumber;
		this.step = stepNumber;

		return this;
	}
}
