package com.lietu.image.objects;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Hashtable;
import com.lietu.image.streams.ImageStream;

/**
 * ImageFileInfo class
 * 
 *  @author    
 *  @created   2005/11/14
 *  @version   1.0.0
 *  @copyright 
 * 
 */
public class ImageFileInfo {
	protected String name = null;
	protected String filename = null;
	protected String keywords = null;	//keywords for query expansion
	protected String description = null;	//description for this image
	protected String urls = null;		//URLs linking to this image
	protected String parent_urls = null;	//URLs contains this image
	protected String contentType = null;
	protected byte[] bytes = null;

	protected static Hashtable ImageContentTypeTable;
	static {
		ImageContentTypeTable = InitializeImageContentTypeTable();
	}

	/**
	 * The default constructor.
	 */
	public ImageFileInfo() {
	}

	/**
	 * The default constructor with content-type and image.
	 * 
	 * @param contentType java.lang.String
	 * @param image byte[]
	 */
	public ImageFileInfo(String contentType, byte[] image) {
		this(null, null, contentType, image);
	}

	/**
	 * The default constructor with filename, content-type and image.
	 * 
	 * @param filename java.lang.String
	 * @param contentType java.lang.String
	 * @param image byte[]
	 */
	public ImageFileInfo(String filename, String contentType, byte[] image) {
		this(null, filename, contentType, image);
	}

	/**
	 * The default constructor with name, filename, content-type and image.
	 * 
	 * @param name java.lang.String
	 * @param filename java.lang.String
	 * @param contentType java.lang.String
	 * @param bytes byte[]
	 */
	public ImageFileInfo(String name, String filename, String contentType, byte[] bytes) {
		this();
		this.setName(name);
		this.setFilename(filename);
		this.setContentType(contentType);
		this.setBytes(bytes);
	}

	/**
	 * The default constructor with name, filename, content-type and image.
	 * 
	 * @param filename java.lang.String
	 * @param keywords java.lang.String
	 * @param description java.lang.String
	 * @param urls java.lang.String
	 * @param parent_urls java.lang.String
	 * @param contentType java.lang.String
	 * @param bytes byte[]
	 */
	public ImageFileInfo(String filename, String keywords, String description, String urls, String parent_urls, String contentType, byte[] bytes) {
		this(null, filename, keywords, description, urls, parent_urls, contentType, bytes);
	}

	/**
	 * The default constructor with name, filename, content-type and image.
	 * 
	 * @param name java.lang.String
	 * @param filename java.lang.String
	 * @param keywords java.lang.String
	 * @param description java.lang.String
	 * @param urls java.lang.String
	 * @param parent_urls java.lang.String
	 * @param contentType java.lang.String
	 * @param bytes byte[]
	 */
	public ImageFileInfo(String name, String filename, String keywords, String description, String urls, String parent_urls, String contentType, byte[] bytes) {
		this();
		this.setName(name);
		this.setFilename(filename);
		this.setKeywords(keywords);
		this.setDescription(description);
		this.setUrls(urls);
		this.setParent_urls(parent_urls);		
		this.setContentType(contentType);
		this.setBytes(bytes);
	}
		
	/**
	 * Initialize image content type table.
	 * 
	 * @return java.util.Hashtable
	 */
	private static Hashtable InitializeImageContentTypeTable() {
		if (ImageContentTypeTable == null) {
			Hashtable table = new Hashtable();
			table.put("image/bmp", "com.lietu.image.streams.BmpImageStream");
			table.put("image/x-bmp", "com.lietu.image.streams.BmpImageStream");
			table.put("image/gif", "com.lietu.image.streams.GifImageStream");
			table.put("image/jpeg", "com.lietu.image.streams.JpegImageStream");
			table.put("image/pjpeg", "com.lietu.image.streams.JpegImageStream");
			table.put("image/png", "com.lietu.image.streams.PngImageStream");
			table.put("image/x-png", "com.lietu.image.streams.PngImageStream");
			ImageContentTypeTable = table;
		}
		return ImageContentTypeTable;
	}

	/**
	 * Answer the image object from this image.
	 * 
	 * @return com.lietu.image.objects.ImageObject
	 * @exception IOException java.io.IOException
	 */
	public ImageAuxiliary asImageObject() throws IOException {
		String className = this.imageStreamClass(this.getContentType());
		if (className == null) {
			throw new IOException("The content type '" + this.getContentType() + "' is not supported.");
		}
		ImageAuxiliary imageObject = null;
		ImageStream imageStream = null;
		try {
			imageStream = (ImageStream) BaseObject._PerformWith(Class.forName(className), "On_", new ByteArrayInputStream(this.getBytes()));
			imageObject = ImageAuxiliary.OriginalImage_(imageStream.nextImage());
		} catch (ClassNotFoundException e) {
			throw new IOException("The class of '" + className + "' is not found.");
		} catch (NoSuchMethodException e) {
			throw new IOException("The method of 'On_' is not such at '" + className + "'.");
		} finally {
			if (imageStream != null) {
				imageStream.close();
				imageStream = null;
			}
		}

		// imageObject.xSpectrum();
		// imageObject.ySpectrum();
		// imageObject.renderingImage();
		return imageObject;
	}

	/**
	 * Get the bytes of this image
	 * 
	 * @return byte[]
	 */
	public byte[] getBytes() {
		return bytes;
	}

	/**
	 * Get the content type of this image.
	 * 
	 * @return java.lang.String
	 */
	public String getContentType() {
		return contentType;
	}

	/**
	 * Get the filename of this image.
	 * 
	 * @return java.lang.String
	 */
	public String getFilename() {
		return filename;
	}

	/**
	 * Get the keywords of this image.
	 * 
	 * @return java.lang.String
	 */
	public String getKeywords() {
		return keywords;
	}

	/**
	 * Get the description of this image.
	 * 
	 * @return java.lang.String
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Get the urls of this image.
	 * 
	 * @return java.lang.String
	 */
	public String getUrls() {
		return urls;
	}

	/**
	 * Get the parent_urls of this image.
	 * 
	 * @return java.lang.String
	 */
	public String getParent_urls() {
		return parent_urls;
	}
				
	/**
	 * Get the name of this image.
	 * 
	 * @return java.lang.String
	 */
	public String getName() {
		return name;
	}

	/**
	 * Set the bytes of this image.
	 * 
	 * @param newBytes byte[]
	 */
	public void setBytes(byte[] newBytes) {
		bytes = newBytes;
	}

	/**
	 * Set content type of this image.
	 * 
	 * @param newContentType java.lang.String
	 */
	public void setContentType(String newContentType) {
		contentType = newContentType;
	}

	/**
	 * Set filename this image.
	 * 
	 * @param newFilename java.lang.String
	 */
	public void setFilename(String newFilename) {
		filename = newFilename;
	}

	/**
	 * Set keywords this image.
	 * 
	 * @param newKeywords java.lang.String
	 */
	public void setKeywords(String newKeywords) {
		keywords = newKeywords;
	}

	/**
	 * Set description this image.
	 * 
	 * @param newDescription java.lang.String
	 */
	public void setDescription(String newDescription) {
		description = newDescription;
	}

	/**
	 * Set urls this image.
	 * 
	 * @param newUrls java.lang.String
	 */
	public void setUrls(String newUrls) {
		urls = newUrls;
	}

	/**
	 * Set parent_urls this image.
	 * 
	 * @param newParent_urls java.lang.String
	 */
	public void setParent_urls(String newParent_urls) {
		parent_urls = newParent_urls;
	}
	
	/**
	 * Set name this image.
	 * 
	 * @param newName java.lang.String
	 */
	public void setName(String newName) {
		name = newName;
	}

	/**
	 * Answer the class name of image stream.
	 * 
	 * @return java.lang.String
	 * @param contentType java.lang.String
	 */
	protected String imageStreamClass(String contentType) {
		return (String) ImageContentTypeTable.get(contentType);
	}
}
