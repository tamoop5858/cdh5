package com.lietu.image.streams;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * BmpImageStream class
 * 
 *  @author    
 *  @created   2005/11/14
 *  @version   1.0.0
 *  @copyright 
 * 
 */
public abstract class BmpImageStream extends ImageStream {
	/**
	 * Constractor with input stream.
	 * 
	 * @return com.lietu.image.streams.ImageStream
	 * @param stream java.io.InputStream
	 * @exception java.io.IOException
	 * @category Instance creation
	 */
	public static ImageStream On_(InputStream stream) throws IOException {
		return On_(_CreateImageStream(), stream);
	}

	/**
	 * Constractor with output stream.
	 * 
	 * @return com.lietu.image.streams.ImageStream
	 * @param stream java.io.InputStream
	 * @exception java.io.IOException
	 * @category Instance creation
	 */
	public static ImageStream On_(OutputStream stream) throws IOException {
		return On_(_CreateImageStream(), stream);
	}

	/**
	 * Answer an instance of bmp image stream.
	 * 
	 * @return com.lietu.image.streams.ImageStream
	 * @category Instance creation
	 */
	protected static ImageStream _CreateImageStream() {
		ImageStream imageStream = null;
		try {
			Class.forName("com.sun.jimi.core.Jimi");
			imageStream = (ImageStream) Class.forName("com.lietu.image.streams.JimiBmpImageStream").newInstance();
		} catch (Throwable ex) {
			try {
				imageStream = new DefaultBmpImageStream();
			} catch (Throwable exception) {
			}
		}
		return imageStream;
	}
}
