package com.lietu.image.objects;

/**
 * ImageAuxiliary class
 * 
 *  @author    
 *  @created   2005/11/14
 *  @version   1.0.0
 *  @copyright 
 * 
 */
public class ImageAuxiliary extends ImageObject {
	protected RawImage originalImage;

	/**
	 * Create new instance with origina image.
	 * 
	 * @return com.lietu.image.objects.ImageAuxiliary
	 * @param anImage com.lietu.image.objects.RawImage
	 */
	public static ImageAuxiliary OriginalImage_(RawImage anImage) {
		ImageAuxiliary self = new ImageAuxiliary();
		self.originalImage_(anImage);
		return self;
	}

	/**
	 * Answer my original image.
	 * 
	 * @return com.lietu.image.objects.RawImage
	 */
	public RawImage originalImage() {
		return originalImage;
	}

	/**
	 * Set original image.
	 * 
	 * @param anImage com.lietu.image.objects.RawImage
	 */
	public void originalImage_(RawImage anImage) {
		originalImage = anImage;
	}
}
