package com.lietu.image.objects;

/**
 * SystemException class
 * 
 *  @author    
 *  @created   2005/11/14
 *  @version   1.0.0
 *  @copyright 
 * 
 */
public class SystemException extends RuntimeException {

	/**
	 * Constructs a <code>SystemException</code> with no detail message.
	 */
	public SystemException() {
		super();
		this.printStackTrace();
	}

	/**
	 * Constructs a <code>SystemException</code> with the specified detail
	 * message.
	 * 
	 * @param e java.lang.String
	 */
	public SystemException(Exception e) {
		super();
		e.printStackTrace();
	}

	/**
	 * Constructs a <code>SystemException</code> with the specified detail
	 * message.
	 * 
	 * @param s java.lang.String
	 */
	public SystemException(String s) {
		super(s);
		this.printStackTrace();
	}

	/**
	 * Constructs a <code>SystemException</code> for Error.
	 * 
	 * @param aString DOCUMENT ME!
	 * 
	 * @return com.lietu.image.objects.SystemException
	 */
	public static SystemException Error(String aString) {
		return new SystemException("Error: " + aString);
	}

	/**
	 * Constructs a <code>SystemException</code> for Halt.
	 * 
	 * @param aString DOCUMENT ME!
	 * 
	 * @return com.lietu.image.objects.SystemException
	 */
	public static SystemException Halt(String aString) {
		return new SystemException("Halt: " + aString);
	}

	/**
	 * Constructs a <code>SystemException</code> for MessageNotUnderstood.
	 * 
	 * @param info DOCUMENT ME!
	 * 
	 * @return com.lietu.image.objects.SystemException
	 */
	public static SystemException MessageNotUnderstood(String info) {
		return new SystemException("message not understood - " + info);
	}

	/**
	 * Constructs a <code>SystemException</code> for ShouldNotImplement.
	 * 
	 * @return com.lietu.image.objects.SystemException
	 */
	public static SystemException ShouldNotImplement() {
		return Error("This message is not appropriate for this object");
	}

	/**
	 * Constructs a <code>SystemException</code> for SubclassResponsibility.
	 * 
	 * @return com.lietu.image.objects.SystemException
	 */
	public static SystemException SubclassResponsibility() {
		return new SystemException("subclass responsibility");
	}

	/**
	 * Constructs a <code>SystemException</code> for SubclassResponsibility.
	 * 
	 * @param info DOCUMENT ME!
	 * 
	 * @return com.lietu.image.objects.SystemException
	 */
	public static SystemException SubclassResponsibility(String info) {
		return new SystemException("subclass responsibility - " + info);
	}
}
