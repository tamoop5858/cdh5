package com.lietu.urlValid;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Properties;

import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexReader;
import org.apache.solr.client.solrj.impl.CommonsHttpSolrServer;
import org.apache.solr.client.solrj.impl.CoreResponseParser;
import org.apache.solr.client.solrj.request.CoreRequest;
import org.apache.solr.client.solrj.response.CoreResponse;
import org.apache.solr.client.solrj.util.ClientUtils;
import org.htmlparser.Node;
import org.htmlparser.lexer.Lexer;
import org.htmlparser.lexer.Page;
import org.htmlparser.util.ParserException;

import com.bitmechanic.spindle.HttpTimeoutHandler;

public class UrlValidator {
	public static void main(String[] args) throws Exception
	{
		/*long sleepTime = 50000L;
		for(;;)
		{
			validBlog();
			validBBS();
			System.out.println("sleep..."+sleepTime);
			Thread.sleep(sleepTime);
		}*/
		//String url = "http://www.txwdj.com";
			//"http://www.timegroup.com.cn/prod-y.htm";
			//"http://www.rayli.com.cn/region/wenzi.html";
		//"http://jianneng.gongkong.com/tech/userdetail.asp?username=elpeng";
		//	"http://www.electric.cn/co/co1/production.asp?id=50019&cpid=15649";
		//System.out.println(isValid(url));
		
		validURL();
	}
	
	//http://58.68.128.229/
	public static int validURL() throws Exception{
	    //String url = "http://59.151.1.71/gongkong/";
    	Properties p = new Properties();
    	InputStream is=p.getClass().getResourceAsStream("/spider.properties");
    	p.load(is);
		is.close();
		String solrURL = p.getProperty("solrmain");
		System.out.println("solr url:"+solrURL);
	    CommonsHttpSolrServer server = new CommonsHttpSolrServer( solrURL );
	    server.setProcessor(new CoreResponseParser());
	    CoreResponse response = new CoreRequest().process( server );
	    System.out.println(response.getIndexDirectory());
	    
		String indexDir = response.getIndexDirectory();
		IndexReader ir = IndexReader.open(indexDir);
		int maxDoc = ir.maxDoc();
		int count=0;
		//&& count<10
		for(int iNum = 0; iNum<maxDoc  ;++iNum)
		{
	      if (!ir.isDeleted(iNum)) {
	    	  Document doc = ir.document(iNum);
	    	  String url = doc.getField("url").stringValue();
	          
	    	  if(!isValid(url))
	    	  {
	    		  System.out.println("\n"+url);
	    		  String q = "url:\""+ClientUtils.escapeQueryChars(url)+"\"";
	    		  try
	    		  {
	    			  server.deleteByQuery( q );// delete everything!
	    		  }
	    		  catch(Exception e)
	    		  {
	    			  System.out.println("error delete url:"+url);
	    		  }
	    		  //UpdateResponse res = 
	    		  //System.out.println(res.getStatus());
	    		  ++count;
	    	  }
	    	  else
	    	  {
	    		  //System.out.println("url is valid:"+url);
	    		  System.out.print(".");
	    	  }
	      }
		}
		server.commit( true, true );
		return count;
	}
	
	public static boolean isValid(String htmlPage)
	{
		HttpTimeoutHandler xHTH = new HttpTimeoutHandler(600000);
		URL theURL;
		try {
			theURL = new URL((URL)null, htmlPage, xHTH);
			URLConnection uc = (HttpURLConnection)theURL.openConnection();
		    
			String ct = uc.getContentType();
			Lexer lexer = new Lexer (new Page(uc.getInputStream(), getCharset(ct) ));

			//StringBuilder body = new StringBuilder();
			Node n = lexer.nextNode();
			/*while (n!=null)
			{
				if(n instanceof org.htmlparser.lexer.nodes.StringNode)
				{
					//System.out.println("node:"+n);
					//System.out.println("node:"+n.getClass());
					body.append(((org.htmlparser.lexer.nodes.StringNode)n).getText());
				}
				n = lexer.nextNode();
			}*/
			/*String curContent = body.toString();
			//System.out.println(curContent);
			if(curContent.indexOf("�������ѱ�ɾ����")>=0)
			{
				return false;
			}
			if(curContent.indexOf("�����ⲻ����")>=0)
			{
				return false;
			}
			if(curContent.indexOf("��ƪ���������ػ�ɾ��!")>=0)
			{
				return false;
			}*/
			
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			//System.out.println("file not found");
			return false;
		} catch (IOException e) {
			//e.printStackTrace();
			if(e.getMessage().startsWith("Server returned HTTP response code: 403 for URL:"))
			{
				return false;
			}
			else if(e instanceof java.net.UnknownHostException)
			{
				return false;
			}
		} catch (ParserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}

    public static String getCharset (String content)
    {
        final String CHARSET_STRING = "charset";
        int index;
        String ret = "GBK";
        if (null != content)
        {
            index = content.indexOf (CHARSET_STRING);

            if (index != -1)
            {
                content = content.substring (index + CHARSET_STRING.length ()).trim ();
                if (content.startsWith ("="))
                {
                    content = content.substring (1).trim ();
                    index = content.indexOf (";");
                    if (index != -1)
                        content = content.substring (0, index);

                    //remove any double quotes from around charset string
                    if (content.startsWith ("\"") && content.endsWith ("\"") && (1 < content.length ()))
                        content = content.substring (1, content.length () - 1);

                    //remove any single quote from around charset string
                    if (content.startsWith ("'") && content.endsWith ("'") && (1 < content.length ()))
                        content = content.substring (1, content.length () - 1);

                    ret = findCharset (content, ret);
                }
            }
        }

        return (ret);
    }

    /**
     * Lookup a character set name.
     * <em>Vacuous for JVM's without <code>java.nio.charset</code>.</em>
     * This uses reflection so the code will still run under prior JDK's but
     * in that case the default is always returned.
     * @param name The name to look up. One of the aliases for a character set.
     * @param _default The name to return if the lookup fails.
     */
    public static String findCharset (String name, String _default)
    {
        String ret;

        try
        {
            Class cls;
            Method method;
            Object object;

            cls = Class.forName ("java.nio.charset.Charset");
            method = cls.getMethod ("forName", new Class[] { String.class });
            object = method.invoke (null, new Object[] { name });
            method = cls.getMethod ("name", new Class[] { });
            object = method.invoke (object, new Object[] { });
            ret = (String)object;
        }
        catch (ClassNotFoundException cnfe)
        {
            // for reflection exceptions, assume the name is correct
            ret = name;
        }
        catch (NoSuchMethodException nsme)
        {
            // for reflection exceptions, assume the name is correct
            ret = name;
        }
        catch (IllegalAccessException ia)
        {
            // for reflection exceptions, assume the name is correct
            ret = name;
        }
        catch (InvocationTargetException ita)
        {
            // java.nio.charset.IllegalCharsetNameException
            // and java.nio.charset.UnsupportedCharsetException
            // return the default
            ret = _default;
            System.out.println (
                "unable to determine cannonical charset name for "
                + name
                + " - using "
                + _default);
        }

        return (ret);
    }

}
