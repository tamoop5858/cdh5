package com.lietu.links;

// HOST TABLE -> INDEX TABLE(A,B) -> Page TABLE

import java.io.*;
import java.util.*;

import com.sleepycat.je.DatabaseException;
import com.sleepycat.je.Environment;
import com.sleepycat.je.EnvironmentConfig;
import com.sleepycat.persist.EntityCursor;
import com.sleepycat.persist.EntityIndex;
import com.sleepycat.persist.EntityStore;
import com.sleepycat.persist.PrimaryIndex;
import com.sleepycat.persist.SecondaryIndex;
import com.sleepycat.persist.StoreConfig;

/**
 * This class implements a memory Data Structure for storing graphs.</p><p>
 * 
 * A large amount of research has recently focused on the graph structure (or link structure)
 * of the World Wide Web, which has proven to be extremely useful for improving the
 * performance of search engines and other tools for navigating the web.
 * For example, the Pagerank algorithm of Brin and Page, used in the Google search
 * engine, and the HITS algorithm of Kleinberg both rank pages according to the 
 * number and importance of other pages that link to them.</p><p>
 * 
 * This class provides the methods needed to efficiently compute with graphs and to
 * experiment with such algorithms, using main memory for storage.
 *
 * @author Bruno Martins
 */
public class WebGraph {
	
	private PrimaryIndex<String,Link> outLinkIndex;
	private SecondaryIndex<String,String,Link> inLinkIndex;

	private EntityStore store;
	/**
	 * Constructor for WebGraph
	 * @throws DatabaseException 
     *
	 */
	public WebGraph (String dbDir) throws DatabaseException {
		File envDir = new File(dbDir);
		EnvironmentConfig envConfig = new EnvironmentConfig();
        envConfig.setTransactional(false); 
        envConfig.setAllowCreate(true); 
        Environment env = new Environment(envDir, envConfig);
        
		StoreConfig storeConfig = new StoreConfig();
		storeConfig.setAllowCreate(true);
		storeConfig.setTransactional(false);
        
        store = new EntityStore(env, "classDb", storeConfig);
        outLinkIndex = store.getPrimaryIndex(String.class, Link.class);
        inLinkIndex = store.getSecondaryIndex(outLinkIndex, String.class, "toURL");
	}

	/**
	 * Constructor for WebGraph, reading data from a text file. Each line of the file
	 * contains an association in the form: 
	 *
	 *    http://url1.com -> http://url2.com 1.0
	 * 
	 * Stating that "http://url1.com" contains an outlink to "http://url2.com", with 
	 * an associated connection strength of 1.0
	 *
	 * the association strengths are determined using a TF.IDF weighting scheme
	 * @param aux The name of the file
	 * @throws IOException An error occured while reading the file
	 * @throws FileNotFoundException An error occured while reading the file
	 * @throws DatabaseException 
	 */
	public void load (File file) throws IOException, FileNotFoundException, DatabaseException {
		BufferedReader reader = new BufferedReader(new FileReader(file));
		String line;
		while((line=reader.readLine())!=null) {
			int index1 = line.indexOf("->");
			if(index1==-1)
			{
				continue;
			}
			else {
				String url1 = line.substring(0,index1).trim();
				String url2 = line.substring(index1+2).trim();
				//Double strength = new Double(1.0);
				index1 = url2.indexOf(" ");
				if(index1!=-1) try {
					//strength = new Double(url2.substring(index1+1).trim());
					url2 = url2.substring(0,index1).trim(); 
				} catch ( Exception e ) {}
				addLink (url1,url2);
			}
		}
	}
	
	/**
	 * Adds an association between two given nodes in the graph. If the 
	 * corresponding nodes do not exists, this method creates them. If the
	 * connection already exists, the strength value is updated.
	 * 
	 * @param fromLink The URL for the source node in the graph 
	 * @param fromLink The URL for the target node in the graph
	 * @param fromLink The strength to associate with the connection
	 * @return The strength associated with the connection
	 * @throws DatabaseException 
	 */
	public void addLink (String fromLink, String toLink) throws DatabaseException {
		Link outLinks = new Link();
		outLinks.fromURL = fromLink;
		outLinks.toURL = new HashSet<String>();
		outLinks.toURL.add(toLink);
		//outLinkIndex.put(outLinks);
		boolean inserted = outLinkIndex.putNoOverwrite(outLinks);
		
		if(!inserted)
		{
			outLinks = outLinkIndex.get(fromLink);
			outLinks.toURL.add(toLink);
			//System.out.println("outLinks : "+ outLinks.fromURL + " outLinks.toURL:"+outLinks.toURL.size());
			//System.out.println(fromLink+" : "+ toLink);
			outLinkIndex.put(outLinks);
		}
	}

	public String[] inLinks ( String URL ) throws DatabaseException {
		EntityIndex<String,Link> subIndex = inLinkIndex.subIndex(URL);
		//System.out.println(subIndex.count());
		String[] linkList = new String[(int)subIndex.count()];
		int i=0;
		EntityCursor<Link> cursor = subIndex.entities();
		 try {
		     for (Link entity : cursor) {
		    	 linkList[i++] = entity.fromURL;
		    	 //System.out.println(entity.fromURL);
		     }
		} finally {
			cursor.close();
		}
		return linkList;
	}
	
	/*public static void main(String[] args) throws FileNotFoundException, IOException, DatabaseException {
		String dbDir = null; 
        String linkFile = null;
        if (args.length == 2)
        {
        	dbDir = args[0];
        	linkFile = args[1];
        }
        else
        {
        	System.out.println(args.length);
            usage();
            System.exit(1);
        }
		WebGraph webGraph = new WebGraph(dbDir);
		
		if(linkFile.startsWith("http"))
		{
			String[] links = webGraph.inLinks(linkFile);
			for(int i=0;i<links.length;++i)
			{
				System.out.println(links[i]);
			}
		}
		else
		{
			webGraph.load(new File(linkFile));
		}
		
	}*/

    private static void usage()
    {
        System.out.println("\n\n" +
            "java com.lietu.link.WebGraph <dbdir> <urltext>\n\n");
    }
}
