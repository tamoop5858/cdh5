package com.lietu.ie;

/*
 * Copyright (c) 2003: The Trustees of Columbia University in the City of New York. All Rights Reserved.
 *  
 */


import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;

import org.htmlparser.lexer.Page;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Element;
import org.w3c.dom.DOMException;
import org.w3c.dom.bootstrap.DOMImplementationRegistry;
import org.w3c.dom.ls.DOMImplementationLS;
import org.w3c.dom.ls.LSException;
import org.w3c.dom.ls.LSOutput;
import org.w3c.dom.ls.LSSerializer;
import org.xml.sax.InputSource;

/**
 * This class uses a settings file to determine portions of a web site to remove, thus extracting the true content of a site based on the user's preferences.
 * 
 * @author David Neistadt, Peter Grimm ( pmg23@psl.cs.columbia.edu )
 */
public class ContentExtractor {
	public InputStream mIn; //the inputstream to filter
	public Document mTree; //the DOM tree for HTML


	
	//the cumulative length of text in a table
	public Node mBodyNode; //the BODY tag node for the link enqueuer
	private ArrayList<NodeDesc> nodeInfList = new ArrayList<NodeDesc>(10);
	public String charSet = null;
	public boolean changeCharSet = false;

	/**
	 * Creates a new instance without any input stream and the default settings file.
	 */
	public ContentExtractor() {
		this(null);
	}

	/**
	 * Creates a new instance of ContentExtractor with the default settings file
	 * 
	 * @param iIn
	 *            the input stream of the HTML file
	 */
	public ContentExtractor(final InputStream iIn) {
		/*java.util.Calendar now = java.util.Calendar.getInstance();
		if (now.get(java.util.Calendar.YEAR) >2009 ||
				(now.get(java.util.Calendar.MONTH) >1 &&
				 now.get(java.util.Calendar.YEAR) ==2008) )
		{
			System.err.print("�Բ����������ѵ�");
			System.exit(-1);
		}*/
		
		mIn = iIn;
	}

	/**
	 * Extracts the content of the html page based on the settings
	 */
	public void extractContent(URL url,String title) {
		org.cyberneko.html.parsers.DOMParser parser = new org.cyberneko.html.parsers.DOMParser();
		
		try {
			//Create the input source using the ISO-8859-1 character set
			InputStreamReader reader = new InputStreamReader(mIn, adjustCharSet(charSet) );
			parser.parse(new InputSource(reader));
			mTree = parser.getDocument();
			//String oldCharSet = charSet;
			extract(mTree);
			
			if(changeCharSet)
			{
				//System.out.println("charset changed:"+charSet);
				HttpURLConnection con = (HttpURLConnection) url.openConnection();
		        
		        con.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows; U; Windows NT 5.2; zh-CN; rv:1.8.1.10) Gecko/20071115 Firefox/2.0.0.10");
		        con.setRequestProperty("Host", url.getHost());
		        con.setRequestProperty("Accept-Language", "zh-cn");
		        con.setRequestProperty("Accept-Charset", "gb2312,utf-8;q=0.7,*;q=0.7n");
		        //String ct = con.getContentType();
		        //this.charSet = Page.getCharset(ct);
		        //System.out.println("charset:"+charSet);
		        InputStream inputs = con.getInputStream();
				reader = new InputStreamReader(inputs, adjustCharSet(charSet));
				parser.parse(new InputSource(reader));
				mTree = parser.getDocument();
				//String oldCharSet = charSet;
				extract(mTree);
			}

			int contentLength = count(mTree,0);
			
			mBodyNode = getBodyNode(contentLength,title,url.toString());
			
			//if(mBodyNode == null)
			//{
			//	System.out.println("mBodyNode3 is null");
			//}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * A recursive algorithm that checks through a node's children and filters out what it wants
	 * 
	 * @param iNode
	 *            the node to start checking
	 */
	public void extract(final Node iNode) {
		Node next = iNode.getFirstChild();
		while (next != null) {
			Node current = next;
			next = current.getNextSibling();
			filterNode(current);
		}
	}
	
	/**
	 * 
	 * @param iNode
	 * return content Length
	 */
	private int count(final Node iNode,int contentLength) {
		NodeList children = iNode.getChildNodes();
		if (children != null) {
			int len = children.getLength();
			for (int i = 0; i < len; i++) {
				contentLength = countNode(children.item(i),contentLength);
			}
		}
		return contentLength;
	}
	
	private Node getBodyNode(int contentLength,String title,String urlString) throws MalformedURLException {
		//String title = "��������ʡ������ʮһ�塱�滮���ڳ�̨";
		//"���ϣ���ͨ���������ΰ������»���ȷ�����ݺ�Ͽ�ۿ����䰲ȫ";
		//System.out.println("get body Node begin");
		Node candiateNode = null;
		double maxContentRatio = 0;
		int candiateLen=0;
		double maxScore=0.0;
		//double maxWordsDensity = 0;
		
		//get rid of tail
		//TODO
		if(nodeInfList.size()>5)
			nodeInfList.remove(nodeInfList.size()-1);
		
		
		//merge similar node
		ArrayList<IntRange> similarNodes = new ArrayList<IntRange>();
		for(int i =0 ; i<(nodeInfList.size() -1) ; ++i)
		{
			NodeDesc curNode = nodeInfList.get(i);
			NodeDesc nextNode = nodeInfList.get(i+1);
			if(curNode.node.getParentNode() == nextNode.node.getParentNode()
					 && curNode.node.getNodeName().equals("P")
					 && nextNode.node.getNodeName().equals("P") )
			{
				IntRange intRange = new IntRange();
				intRange.begin = i;
				i ++;
				intRange.end = i;
				//System.out.println("are identical");
				
				if(i<(nodeInfList.size() -1))
				{
					nextNode = nodeInfList.get(i+1);
					while( curNode.node.getParentNode() == nextNode.node.getParentNode() 
							&& nextNode.node.getNodeName().equals("P") )
					{
						intRange.end ++;
						i ++;
						if((i>=(nodeInfList.size() -1)))
						{
							break;
						}
						nextNode = nodeInfList.get(i+1);
					}
				}
				
				similarNodes.add(intRange);
			}
			//System.out.println("out for");
		}
		
		//merge similar node
		for(IntRange e : similarNodes)
		{
			//NodeInf nodeInf = e.getValue();
			//System.out.println(" begin :"+e.begin + " end:"+e.end);
			Element nDiv = mTree.createElement("DIV");
			Node parentNode = nodeInfList.get(e.begin).node.getParentNode();
			for(int k =e.begin;k<=e.end;++k  )
			{
				parentNode.removeChild(nodeInfList.get(k).node);
			}
			parentNode.appendChild(nDiv);
			NodeDesc nDDiv = new NodeDesc();
			nDDiv.node = nDiv;
			//((Node)n1).setNodeValue("Element A1");
			for(int k =e.begin;k<=e.end;++k  )
			{
				//System.out.println(nodeInfList.get(k).node.getNodeName());
				nDiv.appendChild(nodeInfList.get(k).node);
				nDDiv.subNodes += nodeInfList.get(k).subNodes;
				nDDiv.words += nodeInfList.get(k).words;
				nodeInfList.set(k, null);
			}
			nodeInfList.set(e.begin, nDDiv);
		}
		
		for(NodeDesc e : nodeInfList)
		{
			if(e != null)
			{
			//NodeInf nodeInf = e.getValue();
			e.contentRatio = (double)e.words/(double)contentLength;
			e.wordsDensity = (double)e.words/(double)e.subNodes;
			}
		}
		
		ArrayList<NodeDesc> nodes = new ArrayList<NodeDesc>();
		for(NodeDesc e : nodeInfList)
		{
			if(e == null)
				continue;
				
			if(e.wordsDensity==0)
				continue;
			NodeDesc nodeDesc = new NodeDesc();
			nodeDesc.node = e.node;
			nodeDesc.wordsDensity = e.wordsDensity;
			nodeDesc.contentRatio = e.contentRatio;
			nodeDesc.words = e.words;
			nodes.add(nodeDesc);
			//nodeInf.contentRatio = (double)nodeInf.words/(double)contentLength;
			//nodeInf.wordsDensity = (double)nodeInf.words/(double)nodeInf.nodes;
		}
		
		Collections.sort(nodes);
		//int limit = (int)((double)nodes.size()/(double)3);
		int limit = (int)((double)nodes.size()/(double)2.5);
		for(int i=0;i<limit;++i)
		{
			//System.out.println("node.wordsDensity:"+nodes.get(i).wordsDensity+
				//	"  :"+nodes.get(i).contentRatio+
				//	"  words:"+nodes.get(i).words+
				//	" name:"+nodes.get(i).node.getNodeName());
			//maxContentRatio
			if(nodes.get(i).contentRatio> maxContentRatio)
			{
				maxContentRatio = nodes.get(i).contentRatio;
				candiateLen = nodes.get(i).words;
				candiateNode = nodes.get(i).node;
			}
		}
	/*	for(NodeDesc e : nodeInfList)
		{
			if(e != null)
			{
				System.out.println("78"+e.node.getTextContent());
			}
		}*/
		//System.out.println("78"+candiateNode);
		/*
		 * 
			if(nodeInf.wordsDensity> maxWordsDensity)
			{
				maxWordsDensity = nodeInf.wordsDensity;
				candiateLen=nodeInf.words;
				//candiateNode = e.getKey();
			}
			
			//0.31
			//0.4
			if(nodeInf.contentRatio>=0.4 &&
					nodeInf.wordsDensity> maxWordsDensity/5 &&
					//nodeInf.contentRatio>candiateRatio) //
					nodeInf.contentRatio<candiateRatio)
			//if(nodeInf.wordsDensity> maxWordsDensity)
			{
				candiateNode = e.getKey();
				candiateRatio = nodeInf.contentRatio;
				candiateLen=nodeInf.words;
			}

			System.out.println("nodeInf.contentRatio:"+nodeInf.contentRatio +
					" nodeInf.words:"+nodeInf.words + " contentLength:"+contentLength +
					" candiateNode "+e.getKey().getNodeName() + " nodeInf.nodes:"+nodeInf.nodes+ "wordsDensity:"+nodeInf.wordsDensity );
			
					//+
					//" candiateNode "+candiateNode.getTextContent());
					 * */

		/*String body = IndexExtractor.getWords(e.getKey());
		double score = TitleSimilarity.getSimiarity(title, body);
		if (nodeInf.contentRatio>=0.11 && nodeInf.contentRatio<candiateRatio)
		{
			if(body.indexOf(title)>=0 && candiateNode == null)
			{
				continue;
			}
			
			if(score>maxScore ||
				(score==maxScore && nodeInf.words < candiateLen) )
			{
				candiateNode = e.getKey();
				maxScore = score;
				
				candiateNode = e.getKey();
				candiateRatio = nodeInf.contentRatio;
				candiateLen=nodeInf.words;
			}
		}*/
		//System.out.println("candiateLen :"+candiateLen);
		//System.out.println("title:"+title);
		if(candiateLen<150 && title!=null)
		{
			//System.out.println("candiateLen<150:"+candiateLen);
			//double maxScore=0.0;
			for(NodeDesc e : nodes)
			{
				//NodeInf nodeInf = e.getValue();
				//System.out.println("nodeInf.contentRatio:"+nodeInf.contentRatio +
				//		" nodeInf.words:"+nodeInf.words + " contentLength:"+contentLength +
				//		" candiateNode "+e.getKey().getNodeName());
				
				String body = com.lietu.ie.IndexExtractor.getWords(e.node);
				if(body.indexOf(title)>=0)
				{
					continue;
				}
				double score = com.lietu.ie.TitleSimilarity.getSimiarity(title, body);
				if(score>maxScore ||
						(score==maxScore && e.words < candiateLen))
				{
					candiateNode = e.node;
					maxScore = score;
				}
			}
		}
		
		
            //	add image node
		Element mynDiv = mTree.createElement("DIV");
		for(NodeDesc e : nodeInfList)
		{
			if(e == null)
				continue;
				
			if(e.wordsDensity==0)
				continue;
			//nodes.add(nodeDesc);
			//add image node
			if (e.node.getNodeName().equals("IMG"))
			{	
				   // System.out.println("456"+compareNode(e.node,candiateNode));
					if (compareNode(e.node,candiateNode)) continue;
	                 String str1=e.node.getAttributes().getNamedItem("src").getNodeValue();
	                  //  System.out.println("456"+str1);
	                   // if (str!=null&&str1!=null&& str.toString().contains("content"))
				   if (str1!=null)
				   {
					  // System.out.println("456");
					   Element img=mTree.createElement("IMG");
					   URL  url=new URL(urlString);
				       String     imgurl2=url.toString();//�õ�url
				       String    imgurl=url.getProtocol()+"://"+url.getHost().toString();//�õ�url������
				         
					   if (!str1.contains("http")&& !str1.contains("/")){
						  // System.out.println("456");
						   img.setAttribute("src", imgurl2.substring(0,imgurl2.lastIndexOf("/"))+"/"+str1);
						   mynDiv.appendChild(img);
					   }//imgurl2Ϊԭ��ַ��imgurlΪ����վ������
					   else if (!str1.contains("http")&& !str1.contains("../") && str1.indexOf("/")==0) {img.setAttribute("src", imgurl+str1);
					   mynDiv.appendChild(img);
					   }
					   else if (!str1.contains("http") && str1.contains("../") ) {
							   URL u = new URL(new URL(imgurl2), str1);
							   img.setAttribute("src", u.toString());
							   mynDiv.appendChild(img);
						  
					   } 
					   else if (!str1.contains("http") && !str1.contains("../")&& str1.indexOf("/")>0) {
						   URL u = new URL(new URL(imgurl2), str1);
						   img.setAttribute("src", u.toString()); 
					   }
					   else if (str1.contains("http")&& str1.contains("/")) {//aa="yes";//
						   img.setAttribute("src", str1);	   
					       mynDiv.appendChild(img);
					   }	 
				   }//System.out.println(imgNode.getAttributes().getNamedItem("id"));
			
			}
			
			//nodeInf.contentRatio = (double)nodeInf.words/(double)contentLength;
			//nodeInf.wordsDensity = (double)nodeInf.words/(double)nodeInf.nodes;
		}
		//������ѡ�ڵ㱾�����ڵ��ڲ���ͼ�����޸�����src����
		Nodeself(candiateNode,urlString);
	
		if (mynDiv!=null&& mynDiv.hasChildNodes())
		candiateNode.insertBefore(mynDiv,candiateNode.getFirstChild());
		//System.out.println("candiateRatio:"+candiateRatio+ "candiateNode:"+candiateNode.getNodeName()+" maxWordsDensity:"+maxWordsDensity);
		return candiateNode;
	}

	/**
	 * Examines a node and determines if it should be included in the extracted DOM tree
	 * 
	 * @param iNode
	 *            the node to filter
	 */
	private void filterNode(final Node iNode) {

		//Put the node through the sequence of filters
		boolean mCheckChildren = passThroughFilters(iNode);
	
		if (mCheckChildren)
		{   
			

			if (iNode.hasChildNodes()){
				Node next = iNode.getFirstChild();
				while (next != null) {
					boolean neededimage=false;
					Node current = next;
					next = current.getNextSibling();
						if (current.hasChildNodes()&& current.getFirstChild().getNodeName().equals("IMG"))
						{
							//System.out.println("ratio78:"+iNode.getNodeName());
							//System.out.println("ratio788:"+passThroughFilters(iNode));
							//System.out.println("ratio456:"+current.getFirstChild().getAttributes().getNamedItem("src"));
							Node heightNode = current.getFirstChild().getAttributes().getNamedItem("height");
							Node widthNode = current.getFirstChild().getAttributes().getNamedItem("width");
							   if (heightNode != null && widthNode!=null)
							   {					
								   if (Integer.parseInt(heightNode.getNodeValue())>150 && Integer.parseInt(widthNode.getNodeValue())>100){
									   neededimage=true; 
								   }
							   }
							   else if (heightNode != null && widthNode==null) {
								   if (Integer.parseInt(heightNode.getNodeValue())>150){
									   neededimage=true; 
								   }
							   }
							   else {
								   if (current.getFirstChild().getAttributes().getNamedItem("src").getNodeValue().contains(".jpg")&& !(isImageLink(current))) {
									   neededimage=true;  
								   }
							   }
							if (neededimage) {
								NodeDesc nodeDesc = new NodeDesc();
								nodeDesc.subNodes = 0;
								nodeDesc.words = 0;
								nodeDesc.node = current.getFirstChild();
								// System.out.println("filterNode "+compare(nodeDesc,nodeInfList));
								if (!compare(nodeDesc,nodeInfList))	
								  { 
									nodeInfList.add(nodeDesc);
							       // System.out.println("filterNode "+nodeDesc.node.getAttributes().getNamedItem("src")+"zhang123");
								  }
							}
						 }
				  }
		      }
			
			
			
			
			
			if (iNode.getNodeName().equals("IMG"))
			{	
				boolean neededimage=false;
				Node heightNode = iNode.getAttributes().getNamedItem("height");
				Node widthNode = iNode.getAttributes().getNamedItem("width");
				   if (heightNode != null && widthNode!=null)
				   {					
					   if (Integer.parseInt(heightNode.getNodeValue())>150 && Integer.parseInt(widthNode.getNodeValue())>100){
						   neededimage=true; 
					   }

				   }
				   else if (heightNode != null && widthNode==null) {
					   if (Integer.parseInt(heightNode.getNodeValue())>150){
						   neededimage=true; 
					   }		   
				   }
				   else {
					   if (iNode.getAttributes().getNamedItem("src").getNodeValue().contains(".jpg")) {
						   neededimage=true;  
					   }
				   }
				if (neededimage) {
				NodeDesc nodeDesc = new NodeDesc();
				nodeDesc.subNodes = 0;
				nodeDesc.words = 0;
				nodeDesc.node = iNode;
				// System.out.println("filterNode "+compare(nodeDesc,nodeInfList));
				if (!compare(nodeDesc,nodeInfList))	
				  { 
					nodeInfList.add(nodeDesc);
			       // System.out.println("filterNode "+nodeDesc.node.getAttributes().getNamedItem("src")+"zhang123");
				  }
				}
			}
			filterChildren(iNode);
		}
	} //filterNode

	/**
	 * Filter child nodes
	 * 
	 * @param iNode
	 *            the node to filter the children
	 */
	private void filterChildren(final Node iNode) {
		if (iNode.hasChildNodes()) {
			Node next = iNode.getFirstChild();
			while (next != null) {
				Node current = next;
				next = current.getNextSibling();
				filterNode(current);
			}
		}
	} //filterChildren


    /**
     * Lookup a character set name.
     * <em>Vacuous for JVM's without <code>java.nio.charset</code>.</em>
     * This uses reflection so the code will still run under prior JDK's but
     * in that case the default is always returned.
     * @param name The name to look up. One of the aliases for a character set.
     * @param _default The name to return if the lookup fails.
     */
    public static String findCharset (String name, String _default)
    {
        String ret;

        try
        {
            Class cls;
            Method method;
            Object object;

            cls = Class.forName ("java.nio.charset.Charset");
            method = cls.getMethod ("forName", new Class[] { String.class });
            object = method.invoke (null, new Object[] { name });
            method = cls.getMethod ("name", new Class[] { });
            object = method.invoke (object, new Object[] { });
            ret = (String)object;
        }
        catch (ClassNotFoundException cnfe)
        {
            // for reflection exceptions, assume the name is correct
            ret = name;
        }
        catch (NoSuchMethodException nsme)
        {
            // for reflection exceptions, assume the name is correct
            ret = name;
        }
        catch (IllegalAccessException ia)
        {
            // for reflection exceptions, assume the name is correct
            ret = name;
        }
        catch (InvocationTargetException ita)
        {
            // java.nio.charset.IllegalCharsetNameException
            // and java.nio.charset.UnsupportedCharsetException
            // return the default
            ret = _default;
            System.out.println (
                "unable to determine cannonical charset name for "
                + name
                + " - using "
                + _default);
        }

        return (ret);
    }

    public static String getCharset (String content)
    {
        final String CHARSET_STRING = "charset";
        int index;
        String ret;

        ret = null;
        if (null != content)
        {
            index = content.indexOf (CHARSET_STRING);

            if (index != -1)
            {
                content = content.substring (index + CHARSET_STRING.length ()).trim ();
                if (content.startsWith ("="))
                {
                    content = content.substring (1).trim ();
                    index = content.indexOf (";");
                    if (index != -1)
                        content = content.substring (0, index);

                    //remove any double quotes from around charset string
                    if (content.startsWith ("\"") && content.endsWith ("\"") && (1 < content.length ()))
                        content = content.substring (1, content.length () - 1);

                    //remove any single quote from around charset string
                    if (content.startsWith ("'") && content.endsWith ("'") && (1 < content.length ()))
                        content = content.substring (1, content.length () - 1);

                    ret = findCharset (content, ret);
                }
            }
        }

        return (ret);
    }
    
    public static String adjustCharSet(String inCharSet)
    {
    	if(inCharSet!= null && inCharSet.toLowerCase().equals("gb2312"))
    	{
    		return "GBK";
    	}
    	return inCharSet;
    }
    
	/**
	 * Passes a node through a set of filters
	 * 
	 * @param iNode
	 *            the node to filter
	 */
	private boolean passThroughFilters(final Node iNode) {
		if(iNode == null)
			return false;
		
		boolean mCheckChildren = true;
		
		//Check to see if the node is a Text node or an element node and
		//act accordingly
		int type = iNode.getNodeType();

		Node parent = iNode.getParentNode();

		//Element node
		if (type == Node.ELEMENT_NODE) {
			
			String name = iNode.getNodeName();

			//System.out.print("name:"+name+" ");
			//================================================================
			// Set of conditions that edit the nodes but don't delete them
			//================================================================

			if(name.equals("META") )
			{
				//iNode.getAttributes().getNamedItem(name)
				Node attr = iNode.getAttributes().getNamedItem("content");
				String metaCharSet = ContentExtractor.getCharset (attr.getNodeValue());
				if(metaCharSet!=null && !metaCharSet.equals(charSet) )
				{
					//System.out.println(":"+attr.getNodeValue());
					//System.out.println("metaCharSet"+metaCharSet);
					this.charSet = metaCharSet;
					changeCharSet =true;
				}
			}
			
			//<TD|TABLE width=*> removes widths
			else if ( (name.equals("TD") || name.equals("TABLE")) ) {
				if (hasAttribute(iNode, "width"))
					removeAttribute(iNode, "width");
			} //if

			//<DIV style=*> removes style
			else if ( name.equals("DIV") ) {
				if (hasAttribute(iNode, "style"))
					removeAttribute(iNode, "style");
			} //if

			//<TD> with Link/Text Ratio higher than threshold
			if ( name.equals("TD") || name.equals("DIV") ) {
				
				testRemoveCell(iNode);
				//TODO:
				removeEmptyTables(iNode);
			}

			//<A HREF> with no Images
			else if ( isTextLink(iNode) ) {
				//System.out.println("enter ignoreTextLinks");
				Node temp = iNode.getFirstChild();
				if(temp == null)
				{
					parent.removeChild(iNode);
				}
				else
				{
					String value = temp.getNodeValue();
					if(value!= null && value.length()<6)
					{
						if(value.equals("��"))
						{
							parent.removeChild(iNode);
						}
						else if(value.equals("��"))
						{
							parent.removeChild(iNode);
						}
						else if(value.equals("С"))
						{
							parent.removeChild(iNode);
						}
						else if(value.equals("��ӡ"))
						{
							parent.removeChild(iNode);
						}
						else if(value.equals("����"))
						{
							parent.removeChild(iNode);
						}
						else
						{
							//System.out.println("value:"+value);
							//temp = temp.getNextSibling();
							//temp = temp.getNextSibling();
							parent.replaceChild(temp, iNode);
						}
					}
					else
					{
						parent.removeChild(iNode);
					}
				}
				mCheckChildren = false;
			}

			//<A HREF> with Images
			else if ( isImageLink(iNode) ) {
			//else if ( name.equals("IMG") && !iNode.getAttributes().getNamedItem("src").getNodeValue().contains("jpg")) {
				parent.removeChild(iNode);
				mCheckChildren = false;
			}

			//<IMG*>
			else if ( name.equals("IMG") && isImageLink(iNode)) {
				parent.removeChild(iNode);
				mCheckChildren = false;
			}

			//<SCRIPT>
			else if ( name.equals("SCRIPT") ) {
				//System.out.println("SCRIPT");
				parent.removeChild(iNode);
				mCheckChildren = false;
			}

			//<NOSCRIPT>
			else if ( name.equals("NOSCRIPT") ) {
				parent.removeChild(iNode);
				mCheckChildren = false;
			}

			//<NOSCRIPT> removal and save children
			else if ( name.equals("NOSCRIPT") ) {
				if (iNode.hasChildNodes()) {
					Node current = iNode.getFirstChild();
					while (current != null) {
						Node next = current.getNextSibling();
						//reinsert child before NOSCRIPT node
						parent.insertBefore(current, iNode);
						current = next;
					} //while
				} //if
				parent.removeChild(iNode);
			} //else if

			//<STYLE>
			else if ( name.equals("STYLE") ) {
				parent.removeChild(iNode);
				mCheckChildren = false;
			}

			//<META>
			else if ( name.equals("META") ) {
				parent.removeChild(iNode);
				mCheckChildren = false;
			}

			//<FORM>
			else if ( name.equals("FORM") ) {
				int contentLength = count(parent,0);
				if(contentLength<=10)
				{
					parent.removeChild(iNode);
					mCheckChildren = false;
				}
			}

			//<INPUT>
			else if ( name.equals("INPUT") ) {
				//System.out.println("input");
				parent.removeChild(iNode);
				mCheckChildren = false;
			}

			//<BUTTON>
			else if ( name.equals("BUTTON") ) {
				parent.removeChild(iNode);
				mCheckChildren = false;
			}

			//<SELECT>
			else if ( name.equals("SELECT") ) {
				parent.removeChild(iNode);
				mCheckChildren = false;
			}

			//<IFRAME>
			else if ( name.equals("IFRAME") ) {
				parent.removeChild(iNode);
				mCheckChildren = false;
			}

			//<TABLE>
			else if ( name.equals("TABLE") ) {
				//System.out.println("remove table");
				//settings.removeEmptyTables &&
				//Call method that removes empty tables
				
				//TODO:
				removeEmptyTables(iNode);
				
				//mCheckChildren = false;
			} //else if

			//<EMBED>
			else if ( name.equals("EMBED") ) {
				parent.removeChild(iNode);
				mCheckChildren = false;
			} //else if

			//<BODY>
			else if (name.equals("BODY"))
				mBodyNode = iNode;

		}
		else if( type == Node.COMMENT_NODE)
		{
			parent.removeChild(iNode);
			mCheckChildren = false;
		}
		
		return mCheckChildren;
	}
	
	/**
	 * Examines a node and determines if it should be included in the extracted DOM tree
	 * 
	 * @param iNode
	 *            the node to filter
	 */
	private int countNode(final Node iNode,int contentLength) {
		//System.out.println("enter count node");
		//Put the node through the sequence of filters
		contentLength = countFilters(iNode,contentLength);
		contentLength = countChildren(iNode,contentLength);
		
		return contentLength;
	} //filterNode

	/**
	 * Filter child nodes
	 * 
	 * @param iNode
	 *            the node to filter the children
	 */
	private int countChildren(final Node iNode,int contentLength) {

		//System.out.println("enter count Children");
		if (iNode==null) return 0;//zhangjihong
		if (iNode.hasChildNodes()) {
			Node next = iNode.getFirstChild();
			while (next != null) {
				Node current = next;
				next = current.getNextSibling();
				contentLength = countNode(current,contentLength);
			}
		}
		
		return contentLength;
	} //filterChildren

	private int countFilters(final Node iNode,int contentLength) {
		//Check to see if the node is a Text node or an element node and
		//act accordingly
		if (iNode==null) return 0;//zhangjihong
		int type = iNode.getNodeType();
		
		//Element node
		if (type == Node.ELEMENT_NODE) {

			String name = iNode.getNodeName();

			//<TD> with Link/Text Ratio higher than threshold
			if (name.equals("TD") ) {
				countCell(iNode);
			}
			else if(name.equals("DIV"))
			{
				///System.out.println("count div");
				int words = countCell(iNode);
				if(words==0)
				{
					removeEmptyTables(iNode);
				}
			}
			else if ( name.equals("P"))
			{
				//System.out.println("count p ");
				countCell(iNode);
			}

		} //if (type == Node.ELEMENT_NODE)
		
		//Text node
		else if (type == Node.TEXT_NODE) {

			String value = iNode.getNodeValue();

			contentLength += getHTMLLen(value);
			//System.out.println("text value:"+value);
			//================================================================
			//Set of conditions determining what text to ignore
			//================================================================

		} //else if
		return contentLength;
	}
	
	public static int getHTMLLen(String text)
	{
		//System.out.println("text:"+text);
		int len = 0;
		for(int i=0;i<text.length();++i)
		{
			char c = text.charAt(i);
			if(c==' ')
			{
				
			}
			else if(c=='	')
			{
				
			}
			else if(c=='��')
			{
				
			}
			else if(c=='&')
			{
				i+=5;
			}
			else if(c=='[')
			{
			}
			else if(c==']')
			{
			}
			else if(c=='|')
			{
				return 0;
			}
			else
			{
				++len;
			}
		}
		if( len<10) 
			len = 0;
		return len;
	}

	/**
	 * Removes empty tables
	 * 
	 * @param iNode
	 *            the table node to examine
	 */
	private void removeEmptyTables(final Node iNode) {
		//First filter the children but check for
		//undeleted nodes
		if (iNode.hasChildNodes()) {
			Node next = iNode.getFirstChild();

			while (next != null) {
				Node current = next;
				next = current.getNextSibling();
				if (current.hasChildNodes()&&current.getFirstChild().getNodeName().equals("IMG"))		
				{
              //	System.out.println("ratio:"+current.getFirstChild().getAttributes().getNamedItem("src"));
				}
				else
					filterNode(current);
			} //while
		} //if

		//Check to see if the table is actually empty
		//but reset length recognizer
		com.lietu.ie.IndexExtractor.IntValue lengthForTableRemover = new com.lietu.ie.IndexExtractor.IntValue();//0;
		boolean empty = processEmptyTable(iNode,lengthForTableRemover);

		if (empty)
		{
			//System.out.println("remove it");
			if (iNode.getParentNode()!=null) //zhangjihong
			iNode.getParentNode().removeChild(iNode);
		}

	} //removeEmptyTables

	/**
	 * Recursively check children nodes to see if the table is empty
	 * 
	 * @param iNode
	 *            the node to recursively check.
	 * @return true if the nodes are empty, false if they are not
	 */
	private boolean processEmptyTable(final Node iNode,
						com.lietu.ie.IndexExtractor.IntValue lengthForTableRemover) {
		//The variable that determines if the table is empty
		boolean empty = true;

		//Determine the type of the node
		int type = iNode.getNodeType();
		
		//If it is an element
		if (type == Node.TEXT_NODE) {
			if(iNode.getNodeValue().trim().indexOf("|")>=0)
			{
				empty = true;
			}
			else if(iNode.getNodeValue().trim().indexOf("����վ��ת�ػ�ժ������ӵ������Ȩ����Ʒ")>=0)
			{
					empty = true;
			}
			/*else if(iNode.getNodeValue().trim().indexOf("Copyright")>=0)
			{
					empty = true;
			}*/
			else if(iNode.getNodeValue().trim().indexOf("��Ȩ����")>=0)
			{
					empty = true;
			}
			else if(iNode.getNodeValue().trim().indexOf("��վ����ͼ������ȡ�Ի�����")>=0)
			{
				//System.out.println("is empty");
				empty = true;
			}
			else
			{
				//System.out.println(iNode.getTextContent());
				//Trim the text and make sure there is no more substance
				lengthForTableRemover.value += iNode.getNodeValue().trim().length();
				if (lengthForTableRemover.value >= 12)
					empty = false;
			}
		} //else if

		//Process the children
		if (iNode.hasChildNodes()) {
			Node next = iNode.getFirstChild();

			while (next != null && empty) {
				Node current = next;
				next = current.getNextSibling();
				empty = processEmptyTable(current,lengthForTableRemover);
			} //while
		} //if
		
		//System.out.println("empty?"+empty);
		return empty;

	} //processEmptyTable

	/**
	 * Removes an attribute if the attrbiute exists from an Element node
	 * 
	 * @param iNode
	 *            the node
	 * @param iAttr
	 *            the name of the attribute
	 */
	private void removeAttribute(final Node iNode, final String iAttr) {
		iNode.getAttributes().removeNamedItem(iAttr);
	} //removeAttribute

	/**
	 * Checks to see if an attribute exists in an Element node
	 * 
	 * @param iNode
	 *            the node
	 * @param iAttr
	 *            the name of the attribute to check for
	 * @return true if the attribute exists, false if it doesn't
	 */
	public static boolean hasAttribute(final Node iNode, final String iAttr) {
		Node attr = iNode.getAttributes().getNamedItem(iAttr);
		if (attr == null)
			return false;
		else
			return true;
	} //hasAttribute

	/**
	 * Removes a table cell if the link ratio is appropriate
	 * 
	 * @param iNode
	 *            the table cell node
	 */
	public void testRemoveCell(final Node iNode) {
		//Ignore if the cell has no children
		if (!iNode.hasChildNodes())
			return;

		int links;
		int words;
		
		//Count up links and words
		links = getNumLinks(iNode);
		com.lietu.ie.IndexExtractor.IntValue maxSegLen = new com.lietu.ie.IndexExtractor.IntValue();
		
		words = getWordsAndMaxSegLen(iNode,maxSegLen);

		//Compute the ratio and check for divide by 0
		double ratio = 0;
		if (words == 0)
			ratio = 0.25 + 1;
		else
			ratio = (double)links / (double)words;

		//System.out.println("ratio:"+ratio +" maxSegLen:"+maxSegLen.value);
		if (ratio > 0.25 && maxSegLen.value<100) {
			Node next = iNode.getFirstChild();
			while (next != null) {
				Node current = next;
				next = current.getNextSibling();
				
				removeAll(current);
			}
		}
	} //testRemoveCell

	public int countCell(final Node iNode)
	{
		if (!iNode.hasChildNodes())
			return 0;
		
		//int links;
		//int words;
		
		//Count up links and words
		//links = getNumLinks(iNode, type);
		int words = getNumWords(iNode);
		int nodeNum = getNumNodes(iNode);
		//System.out.println("put words:"+words + " node:" +iNode.getNodeName());
		NodeDesc nodeDesc = new NodeDesc();
		nodeDesc.subNodes = nodeNum;
		nodeDesc.words = words;
		nodeDesc.node = iNode;
		
		//iNode, new NodeInf(words,nodeNum)
		//if (!isReapted(nodeDesc.node,nodeInfList))//�������ظ���nodeDesc
		nodeInfList.add(nodeDesc);
		
		return words;
	}
	
	/**
	 * Recursive function that removes everything
	 * 
	 * @param iNode
	 *            the node to start removing children from
	 */
	private void removeAll(final Node iNode) {
		if (isLink(iNode)){

			if (iNode.hasChildNodes()){
				NodeList children = iNode.getChildNodes();
				    int neededimage=0;
					int len = children.getLength();
					for (int ii = 0; ii < len; ii++) {			
						if (children.item(ii)!=null&&children.item(ii).getNodeName().equals("IMG"))
						{	
							  Node heightNode = children.item(ii).getAttributes().getNamedItem("height");
							   if (heightNode != null )
							   {					
								   if (Integer.parseInt(heightNode.getNodeValue())<150)
								   { 
								   // System.out.println("removeAll"+children.item(ii).getAttributes().getNamedItem("src")+"zhang12345");
								   //iNode.getParentNode().removeChild(iNode);
									 iNode.removeChild(children.item(ii));  
									 neededimage++;
								   }
							   }
							   else if (!children.item(ii).getAttributes().getNamedItem("src").getNodeValue().contains("jpg")) {				  
								//   System.out.println("removeAll456"+children.item(ii).getAttributes().getNamedItem("src")+"zhang12345");   
								   iNode.getParentNode().removeChild(iNode);
								}
						}
						
					}	
					if (neededimage==len) iNode.getParentNode().removeChild(iNode);
			}
			else {
				 iNode.getParentNode().removeChild(iNode);
			}
		}
		else if (iNode.getNodeType() == Node.TEXT_NODE) {
			iNode.getParentNode().removeChild(iNode);
		} 
		else {
			Node next = iNode.getFirstChild();
			while (next != null) {
				Node current = next;
				next = current.getNextSibling();
				removeAll(current);
			} //while
		}
	} //removeChild
	
	/**
	 * Determines if a given node contains a given attribute
	 * 
	 * @param iNode
	 *            the node to check for the attribute
	 * @param attribute
	 *            the attribute the check for in the node
	 * @return true if the node contains the attribute
	 */
	private static boolean nodeContainsAttribute(final Node iNode, final String attribute) {
		if (iNode == null)
			return false;

		NamedNodeMap map = iNode.getAttributes();
		
		if (map == null)
			return false;

		int length = map.getLength();
		for (int i = 0; i < length; i++) {
			if (attribute.equalsIgnoreCase(map.item(i).getNodeName()))
				return true;
		}
		return false;
	}

	/**
	 * Counts the number of links from one node downward
	 * 
	 * @param iNode
	 *            the node to start counting from
	 * @param iType
	 *            the type of links to count.
	 * @return the number of links
	 */
	public static int getNumLinks(final Node iNode) {
		int links = 0;

		if (iNode.hasChildNodes()) {
			Node next = iNode.getFirstChild();

			while (next != null) {
				Node current = next;
				next = current.getNextSibling();
				links += getNumLinks(current);
			}
		}

		if (isLink(iNode))
			links++;		

		return links;
	} //getNumLinks

	/**
	 * Checks to see if a node is a link
	 * 
	 * @param iNode
	 *            the node to check
	 * @return true if the node is a link, false if it is not
	 */
	public static boolean isLink(final Node iNode) {
		//Check to see if the node is a Text node or an element node
		int type = iNode.getNodeType();

		//Element node
		if (type == Node.ELEMENT_NODE) {
			String name = iNode.getNodeName();

			//Check to see if it is a link
			if ( name.equals("A") )
				return ((Element)iNode).hasAttribute("href");
			
		} //if

		return false;
	}

	/**
	 * Checks to see if a node is a link with an image as the link or if the node is an image, it checks if it is a link
	 * 
	 * @param iNode
	 *            the node to check
	 * @return true if the node is a link with an image, false if it is not
	 */
	public static boolean isImageLink(final Node iNode) {
		boolean imageLink = false;

		//Check to see if the node is a link
		if (isLink(iNode)) {

			//Check to see if the children have an image in it
			if (iNode.hasChildNodes()) {
				Node next = iNode.getFirstChild();

				while (next != null && !imageLink) {
					Node current = next;
					next = current.getNextSibling();
					if (isImage(current))
						//imageLink = true;
						return true;

				} //while
			} //if
		} //if
		//If the node is an image, check if its parent is a link
		else if (isImage(iNode)) {
			if (isLink(iNode.getParentNode()))
				//imageLink = true;
				return true;
			else {
				// check for image maps
				if (nodeContainsAttribute(iNode, "usemap"))
					//imageLink = true;
					return true;
			}

		} //else if

		return imageLink;
	} //isImageLink

	/**
	 * Checks to see if a node is an image
	 * 
	 * @param iNode
	 *            the node to check
	 * @return true if the node is an image, false if it is not
	 */
	private static boolean isImage(final Node iNode) {
		boolean image = false;

		//Check to see if the node is an image
		int type = iNode.getNodeType();
		if (type == Node.ELEMENT_NODE) {
			if (iNode.getNodeName().equals("IMG"))
				image = true;
		} //if

		return image;
	}

	/**
	 * Determines if a link is a text link
	 * 
	 * @param iNode
	 *            the node to analyze
	 * @return true if the node is a text link and false if it is not.
	 */
	public static boolean isTextLink(final Node iNode) {
		return !isImageLink(iNode) && isLink(iNode);
	} //isTextLink

	/**
	 * Counts the number of links from one node downward
	 * 
	 * @param iNode
	 *            the node to start counting from
	 * @return the number of links
	 */
	private int getNumWords(final Node iNode) {
		int words = 0;

		if (iNode.hasChildNodes()) {
			Node next = iNode.getFirstChild();

			while (next != null) {
				Node current = next;
				next = current.getNextSibling();

				//If it is a link, don't go any deeper into it
				if (!isLink(current))
					words += getNumWords(current);
			}
		}

		//Check to see if the node is a Text node or an element node
		int type = iNode.getNodeType();

		//Text node
		if (type == Node.TEXT_NODE) {
			String content = iNode.getNodeValue();
			words += getHTMLLen(content);
			//((double) content.length()) / LETTERS_PER_WORD;
		} //if

		return words;
	} //getNumWords

	private int getNumNodes(final Node iNode) {
		int count = 0;

		if (iNode.hasChildNodes()) {
			Node next = iNode.getFirstChild();

			while (next != null) {
				Node current = next;
				next = current.getNextSibling();

				//If it is a link, don't go any deeper into it
				//if (!isLink(current))
				count += getNumNodes(current);
			}
		}

		//Check to see if the node is a Text node or an element node
		//int type = iNode.getNodeType();

		//Text node
		//if (type == Node.TEXT_NODE) {
		//	String content = iNode.getNodeValue();
		count ++;
			//((double) content.length()) / LETTERS_PER_WORD;
		//} //if

		return count;
	} //getNumWords


	private int getWordsAndMaxSegLen(final Node iNode,
			com.lietu.ie.IndexExtractor.IntValue maxSegLen) {
		int words = 0;

		if (iNode.hasChildNodes()) {
			Node next = iNode.getFirstChild();

			while (next != null) {
				Node current = next;
				next = current.getNextSibling();

				//If it is a link, don't go any deeper into it
				if (!isLink(current))
					words += getWordsAndMaxSegLen(current,maxSegLen);
			}
		}

		//Check to see if the node is a Text node or an element node
		int type = iNode.getNodeType();

		//Text node
		if (type == Node.TEXT_NODE) {
			String content = iNode.getNodeValue();
			if(content.length()>maxSegLen.value)
			{
				maxSegLen.value = content.length();
			}
			//if(content.indexOf("��Ȩ����")>=0)
			//{
			//	return words;
			//}
			words += getHTMLLen(content);
			//((double) content.length()) / LETTERS_PER_WORD;
		} //if

		return words;
	} //getNumWords
	
	/**
	 * Returns the Document object
	 * 
	 * @return the Document object of the DOM tree representing the HTML file
	 */
	public Document getTree() {
		return mTree;
	}

	/**
	 * Pretty prints the HTML to an OutputStream
	 * 
	 * @param iNode
	 *            the Document to start printing from
	 * @param iOut
	 *            the output stream to print to.
	 */
	public StringBuffer prettyPrint(final Node iNode) {
		if(iNode == null)
			return null;
		StringBuffer body = new StringBuffer();
		DOMImplementationRegistry registry;
		try {
			registry = DOMImplementationRegistry.newInstance();

			DOMImplementationLS impl = 
			    (DOMImplementationLS)registry.getDOMImplementation("LS");
			LSSerializer writer = impl.createLSSerializer();
			
			writer.getDomConfig().setParameter("xml-declaration", false);
			
			NodeList children = iNode.getChildNodes();
			if (children != null) {
				int len = children.getLength();
				for (int i = 0; i < len; i++) {
					try {
						LSOutput output = impl.createLSOutput();
						ByteArrayOutputStream fileOut = new ByteArrayOutputStream();
						output.setByteStream(fileOut);
						//output.setCharacterStream(characterStream);
						output.setEncoding("GBK");		
						Node current = children.item(i);
						writer.write(current,output);
						
						body.append(fileOut.toString());
						//System.out.println(fileOut.toString());

						//output.setByteStream(iOut);
						//output.setEncoding("GBK");
						//writer.write(children.item(i),output);
						
						//System.out.println("NodeValue:"+children.item(i).getNodeValue());
						
							//new String( writer.writeToString(children.item(i)).getBytes("GBK"),"UTF-8");
						//System.out.println("content:"+content);
					} catch (DOMException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (LSException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					//writer.write(children.item(i), output);
				}
			}
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return body;
	} //prettyPrint
	
	/*public static void main(String[] args) throws Exception {
		if (args.length != 1) {
			System.out.println("Usage: java ContentExtractor [input file]");
			return;
		}
        //URL u = new URL(origURL,newURL);
		String title = //"���ʳｨ����Э��";
			//"���ϣ���ͨ���������ΰ������»���ȷ�����ݺ�Ͽ�ۿ����䰲ȫ";
		//"һ������ȫ��������������ͬ������11.3%";
			null;
			//"��������԰";
		String urlString =//"http://dcmax.diytrade.com/sdp/239545/2/pd-1059054/824531-530956.html";
			//"http://www.56.com.cn/zx_center/ShowInfo.aspx?id=114825";
			//"http://www.56.com.cn/education/ShowInfo.aspx?id=101543";
			//"http://news.sina.com.cn/c/2007-12-04/211014449400.shtml";
			//"http://eye.eyeworld.cn/articles/article21088.html";
			//"http://www.chinanews.com.cn/gj/kong/news/2008/02-25/1172674.shtml";
		//	"http://www.ujj.com.cn/zhoubian/zb162.asp";
			//"http://www.week9.com/article/6/2006-04/20060428142023.html";
		//"http://www.week9.com/article/6/2006-04/20060428141506.html";
			//"http://www.tuniu.com/places/3468/show_desc";
			//"http://www.lookgo.cn/html/beijing/2007-6-6/BeiJingDongWuWan-sipo3147.html";
		//"http://news.southcn.com/china/zgkx/content/2007-12/08/content_4287909.htm";
		//"http://comm.ccidnet.com/art/1569/20071228/1324949_1.html";
			//"http://comm.ccidnet.com/art/9247/20071205/1298357_1.html";
			//"http://view.news.qq.com/a/20071224/000018.htm";
			//...............
		//"http://news.driverchina.com/Html/news/tele/tele/115127760.html";
       "http://www.che168.com/article/html/200802/20080225/20080225_192350_1.html";		
	// "http://news.163.com/08/0226/15/45KU32B000011229.html";
	//	"http://www.chinanews.com.cn/tp/shfq/news/2008/02-21/1169776.shtml";
     //    "http://www.qingdaonews.com/gb/content/2008-03/02/content_7818269.htm";
			FileInputStream streamIn;
		try {
			//InputStream file = new FileInputStream(new File(args[0]));
			//InputStreamReader reader = new InputStreamReader(file,"GBK");
			//streamIn = new BufferedReader(reader);
			streamIn = new FileInputStream(args[0]);
		} catch (FileNotFoundException e) {
			System.out.println("ContentExtractor: Input File Not Found");
			return;
		} catch (SecurityException e) {
			System.out.println("ContentExtractor: Read access denied to Input File");
			return;
		}



		if(urlString.startsWith("http"))
		{
			ContentExtractor ce = new ContentExtractor();
			StringBuffer body = ce.processURL(urlString,title);
			System.out.println(body);
		}
		else
		{
			ContentExtractor ce = new ContentExtractor();
			StringBuffer body = ce.processFile(urlString);
			System.out.println(body);
		}
        
        //InputStreamReader isr=new InputStreamReader(inputs,"GBK");
        //InputSource source=new InputSource(isr);
        //parser.parse(source,fragment);

	}*/
	
	public StringBuffer processURL(String urlString,String title) throws IOException {
		URL url = new URL(urlString);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        
        con.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows; U; Windows NT 5.2; zh-CN; rv:1.8.1.10) Gecko/20071115 Firefox/2.0.0.10");
        con.setRequestProperty("Host", url.getHost());
        con.setRequestProperty("Accept-Language", "zh-cn");
        con.setRequestProperty("Accept-Charset", "gb2312,utf-8;q=0.7,*;q=0.7n");
        String ct = con.getContentType();
        this.charSet = Page.getCharset(ct);
        //System.out.println("ct:"+ct);
        InputStream inputs = con.getInputStream();
        return getContent(url,inputs,title);
	}
	
	public StringBuffer processFile(String fileName)
	{
		FileInputStream streamIn;
		try {
			//InputStream file = new FileInputStream(new File(fileName));
			//InputStreamReader reader = new InputStreamReader(file,"GBK");
			//streamIn = new BufferedReader(reader);
			streamIn = new FileInputStream(fileName);
			this.charSet = "GBK";
			return getContent(null,streamIn,null);
		} catch (FileNotFoundException e) {
			System.out.println("ContentExtractor: Input File Not Found");
			return null;
		} catch (SecurityException e) {
			System.out.println("ContentExtractor: Read access denied to Input File");
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
	

	/**
	 * Examines a node and determines if it should be included in the extracted DOM tree
	 * 
	 * @param iNode
	 *            the node to filter
	 */
	private String addressNode(final Node iNode) {
		//System.out.println("enter count node");
		//Put the node through the sequence of filters

		//System.out.println("enter count Children");
		if (iNode.hasChildNodes()) {
			Node next = iNode.getFirstChild();
			while (next != null) {
				Node current = next;
				next = current.getNextSibling();
				String ret = addressNode(current);
				if(ret != null)
				{
					return ret;
				}
			}
		}
		
		if (iNode.getNodeType() == Node.TEXT_NODE) {
			String value = iNode.getNodeValue().trim();
			double sim = com.lietu.ie.AddressSimilarity.getSimiarity(value);
			//System.out.println("sim:"+sim+" text value:"+value);
			if(sim >=0.9)
			{
				return value;
			}
			//================================================================
			//Set of conditions determining what text to ignore
			//================================================================
		} //else if
		
		return null;
	} //filterNode

	public String getAddress(Node iNode)
	{
		if(iNode == null)
			return null;
		return addressNode(iNode);
	}

	/**
	 * This method processes a url and returns content
	 * 
	 * @param in
	 *            the file to process
	 * @param out
	 *            the output file
	 */
	public StringBuffer getContent(URL url,
											final InputStream streamIn,
											String title) throws IOException {
		mIn = streamIn;
		extractContent(url,title);
		streamIn.close();
		
		if(mBodyNode == null)
		{
			System.out.println("mBodyNode is null");
		}
		//System.out.println(nodeInfMap.get(mBodyNode).contentRatio);
		return 	prettyPrint(mBodyNode);
	}
	
	public com.lietu.ie.SightInf getStructContent(URL url,
											final InputStream streamIn,
											String title) throws IOException {
		mIn = streamIn;
		extractContent(url,title);
		streamIn.close();
		
		if(mBodyNode == null)
		{
			System.out.println("mBodyNode is null");
		}
		//System.out.println(nodeInfMap.get(mBodyNode).contentRatio);
		//return 	prettyPrint(mBodyNode);
		com.lietu.ie.SightInf sightInf = new com.lietu.ie.SightInf();
		
		sightInf.address = getAddress(mBodyNode);
		sightInf.desc = prettyPrint(mBodyNode).toString();
		
		//System.out.println(sightInf.address);
		return sightInf;
	}
	
	public static class NodeDesc implements Comparable<NodeDesc>
	{
		Node node;
		double contentRatio; //words/total words
		double wordsDensity ; //word/node
		int words;
		int subNodes;
		
		public int compareTo(NodeDesc o) {
			if(o.wordsDensity> this.wordsDensity)
				return 1;
			if(o.wordsDensity< this.wordsDensity)
				return -1;
			return 0;
		}
	}
	
	
	public static boolean compare(NodeDesc iNode,ArrayList<NodeDesc> nodeInfList ){
		boolean aa=false;
		//String bb=iNode.node.getAttributes().getNamedItem("src").toString();
		
		for (int i =0;i<nodeInfList.size();i++)
		{   if (nodeInfList.get(i)==null) continue;
		    // System.out.println(i+":"+aa);
			 aa=compareNode(iNode.node,nodeInfList.get(i).node);
			// System.out.println(i+":"+aa);
		    if (aa) {return aa ;}
			//System.out.println(nodeInfList.get(i).node.getAttributes().getNamedItem("src").toString().equals(bb));
		}
		return aa;
		
	}
	public static boolean compareNode(Node newNode1, Node oldNode){
		Node bb=newNode1.getAttributes().getNamedItem("src");
		Node cc=null;
		Node newNode=newNode1;
		boolean aa=false;
		if (oldNode==null) return false;
		if (!oldNode.hasChildNodes())
		//	System.out.println(nodeInfList.get(i).node.hasAttributes());
			{//	System.out.println(oldNode.getNodeName());
				if (oldNode.hasAttributes())	
				{
					cc=oldNode.getAttributes().getNamedItem("src");
			 	    if (bb!=null && cc!=null && bb.getNodeValue().equals(cc.getNodeValue()))
			 	    {	
			 		 return true;
			 	    }
			 	  
			 	}
			   // else  if (!cc.hasAttributes()) {};
			}
		if (oldNode.hasChildNodes()){
				NodeList children = oldNode.getChildNodes();
					int len = children.getLength();
					for (int ii = 0; ii < len; ii++) {
						aa= compareNode(newNode,children.item(ii));
						if (aa) return aa;
					}
				
			}

			return aa;
		//System.out.println(nodeInfList.get(i).node.getAttributes().getNamedItem("src").toString().equals(bb));		
	}
	
	//�����ڵ������ĺ���
	public boolean Nodeself(Node oldNode,String urlString) throws MalformedURLException{
	//	Node bb=newNode1.getAttributes().getNamedItem("src");
		Node cc=null;
		boolean aa=false;
		
		if (oldNode==null) return true;
		if (!oldNode.hasChildNodes())
		//	System.out.println(nodeInfList.get(i).node.hasAttributes());
			{//	System.out.println(oldNode.getNodeName());
				if (oldNode.hasAttributes())	
				{
					cc=oldNode.getAttributes().getNamedItem("src");
			 	    if (cc!=null)
			 	    {	
			 	    	if (oldNode.getParentNode()!=null) {
			 	    	    Node parent=oldNode.getParentNode();
			 	    	    String str1=cc.getNodeValue();
			             //  System.out.println("456"+str1);
			               // if (str!=null&&str1!=null&& str.toString().contains("content"))
						   if (str1!=null&& str1.toString().contains(".jpg"))
						   {
							  // System.out.println("456");
							   Element img=mTree.createElement("IMG");
							   URL  url=new URL(urlString);
						       String  imgurl2=url.toString();//�õ�url
						       String  imgurl=url.getProtocol()+"://"+url.getHost().toString();//�õ�url������
						         
							   if (!str1.contains("http")&& !str1.contains("../")&& !str1.contains("/")){
								  // System.out.println("456");
								   img.setAttribute("src", imgurl2.substring(0,imgurl2.lastIndexOf("/"))+"/"+str1);
							   }
							   else if (!str1.contains("http")&& !str1.contains("../")&& str1.indexOf("/")==0) {img.setAttribute("src", imgurl+str1);}
							   else if (!str1.contains("http")&& str1.contains("../")) {
								   URL u = new URL(new URL(imgurl2),str1);
								   img.setAttribute("src", u.toString());
							   }
							   else if (!str1.contains("http")&& !str1.contains("../") && str1.indexOf("/")>0 ) {
								 //  URL u = new URL(new URL(imgurl2),str1);
								 //  img.setAttribute("src", u.toString());
							   }
							   else if (str1.contains("http")&&str1.contains("/")) img.setAttribute("src", str1);			 
			                   //parent.r				
							   parent.replaceChild(img,oldNode);
							  // imgNode=e.node;
						   }
			 	    	}//System.out.println(imgNode.getAttributes().getNamedItem("id"));
			 		 return true;
			 	    }
			 	  
			 	}
			   // else  if (!cc.hasAttributes()) {};
			}
		if (oldNode.hasChildNodes()){
				NodeList children = oldNode.getChildNodes();
					int len = children.getLength();
					for (int ii = 0; ii < len; ii++) {
						aa= Nodeself(children.item(ii),urlString);
					//	if (aa) return aa;
					}
				
			}

			return aa;
		//System.out.println(nodeInfList.get(i).node.getAttributes().getNamedItem("src").toString().equals(bb));		
	}
   
	
	public static class IntRange
	{
		public int begin;
		public int end;
	}
} //ContentExtractor
