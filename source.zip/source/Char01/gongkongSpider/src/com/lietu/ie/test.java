package com.lietu.ie;


import java.awt.Image;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.lietu.image.util.LoadImage;


//import javax.print.DocFlavor.URL;

//import com.sun.org.apache.xerces.internal.util.URI;
//import com.sun.org.apache.xerces.internal.util.URI.MalformedURIException;

public class test {

	/*public static void main(String[] args) throws MalformedURLException{
		
		String aa="�� �� �� ��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;��������";
	String  bb=TextHtml.html2text(aa);
	
	String regEx="^abc$";
	String str="/02-25/1172674.shtml";

	Pattern p=Pattern.compile("\\.shtml$",Pattern.DOTALL);

	Matcher m=p.matcher(str);

	    URL u = new URL(new URL("http://www.56.com.cn/zx_center/ShowInfo.aspx?id=30787"), "images/zx_d_02.jpg");
	    //,"../../../images/attachement/jpg/site1/20080302/001422c4a7f609349ebf10.jpg"
	    int i="images/zx_d_02.jpg".indexOf("/");
	   // System.out.println(i);
	    
	    
	    LoadImage li = new LoadImage();
        URL url=new URL("http://www.tjuth.com/4.0/product/Images/Product_search.jpg");
		Image entry = null;
		try {
			entry = li.loadImageFromURL(url);
			float heigh=entry.getHeight(null);
			float width=entry.getWidth(null);
			System.out.print(width+": "+heigh+" :"+heigh/width);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	    
	}*/
}
