package com.lietu.ie;

public class TitleSimilarity {
	
	public static double getSimiarity(String title,String body)
	{
		int matchNum = 0;
		
		for(int i=0;i<title.length();++i)
		{
			if(body.indexOf(title.charAt(i))>=0)
			{
				++matchNum;
			}
		}
		double score = (double)matchNum/( (double)title.length() );
		//System.out.println("body score:"+body+" : "+score);
		return score;
	}
}
