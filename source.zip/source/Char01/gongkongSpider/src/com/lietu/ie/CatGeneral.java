/*
 * Created on 2005-2-5
 *
 */
package com.lietu.ie;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;

import org.htmlparser.Parser;
import org.htmlparser.lexer.Page;
import com.bitmechanic.spindle.URLSummary;

/**
 * @author luogang
 *
 */
public class CatGeneral extends URLSummary{
	public void parseHTML(InputStream streamIn,String charSet,String include,String urlDesc, boolean expand ) throws Exception
	{
		//System.out.println("will expand?"+expand);
		if(expand)
		{
			IndexExtractor ce;
			ce = new IndexExtractor();

			ce.processNoOverwrite(streamIn,charSet);
			ArrayList<String> indexLinks = new ArrayList<String>();
			ArrayList<LinkDesc> detailLinks = new ArrayList<LinkDesc>();
			//ArrayList<LinkDesc> detailLinksDesc = new ArrayList<LinkDesc>();
			ce.getDetailLinks(ce.mBodyNode, detailLinks);
			ce.getPageLinks(ce.mPageNode, indexLinks);
			//if(indexURLs == null)
			//{
			//	System.out.println();
			//}
			for(String link:indexLinks)
			{
				//System.out.println("index link:"+link);
	//new chanage			addIndexLink(url,include,link,null);
			}
			for(LinkDesc link:detailLinks)
			{
				//System.out.println("detail link:"+link);
				//new chanage			addDetailLink(url,include,link.link,link.desc);
			}
		}
		else
		{
			ContentExtractor ce;
			ce = new ContentExtractor();
			ce.charSet = charSet;
			this.body = new StringBuffer( ce.getContent(this.url,streamIn,urlDesc) );
		}
	}

	/*public static void main(String[] args) throws Exception {
		Parser parser;
        String url = //"http://www.ad.siemens.com.cn/Training/education/course_intro.asp?id=E1004**";
        //"http://www.singamas.com/PageChn/Depot/CDepotMainSLQC.shtm";
        	//"http://www.singamas.com/index.html";
        	//"http://www.yokogawa.com/cn/";
        	//"http://www.abb.com.cn/Product/seitp321/ee3e53565b91bf2ac1256f16004aea71.aspx?productLanguage=zh&country=CN";
        //"http://www.freescale.com.cn/Applications/automotive_mc33493.asp";
        	//"http://www.cwx168.com/ProductInfo.asp?ID=323&ParentID=97";
        	//"http://www.adtechcn.com/comnewslist.php?newsid=99";
        	//"http://www.autonics.com/inc.php?inc=autonics_history";
        	"http://www.56.com.cn/zx_center/List_Child.Aspx?ClassId=33";
        URLSummary urlBody = new CatGeneral();
		urlBody.url = new URL(url);
		urlBody.accessDate = new Date();
		
		parser = new Parser (url);
		HttpURLConnection uc = (HttpURLConnection) urlBody.url.openConnection();
		uc.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows; U; Windows NT 5.2; zh-CN; rv:1.8.1.10) Gecko/20071115 Firefox/2.0.0.10");
	  	uc.setRequestProperty("Host", urlBody.url.getHost());
	  	uc.setRequestProperty("Accept-Language", "zh-cn");
	  	uc.setRequestProperty("Accept-Charset", "gb2312,utf-8;q=0.7,*;q=0.7n");
    
		String ct = uc.getContentType();
		System.out.println("ct:"+ct);
		
		//urlBody.parseHTML(uc.getInputStream(),Page.getCharset (ct),"",null, true);
		//"UTF-8"
		//"GBK"
		//Lexer lexer = new Lexer (new Page(uc.getInputStream(), Page.getCharset (ct)));
		//URL theURL = new URL(urlBody.url.replaceAll(" ","%20"));
		//
		//lexer = new Lexer (new Page(uc.getInputStream(), Page.getCharset (ct)));
		
		//urlBody.parseHTML( parser.getLexer(),null,true);
		//urlBody.parseHTML( lexer,null,true);
		System.out.println(urlBody.toString());
	}*/
}
