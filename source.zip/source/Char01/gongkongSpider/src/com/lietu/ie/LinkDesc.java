package com.lietu.ie;

public class LinkDesc {
	String link;
	String desc;
	
	public LinkDesc(String l,String d)
	{
		link = l;
		desc = d;
	}
	
	public String toString()
	{
		return link+"@"+desc;
	}
}
