package com.lietu.ie;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.DOMException;
import org.w3c.dom.bootstrap.DOMImplementationRegistry;
import org.w3c.dom.ls.DOMImplementationLS;
import org.w3c.dom.ls.LSException;
import org.w3c.dom.ls.LSOutput;
import org.w3c.dom.ls.LSSerializer;
import org.xml.sax.InputSource;

public class IndexExtractor {

	private InputStream mIn; //the inputstream to filter
	private Document mTree; //the DOM tree for HTML
	
	//the cumulative length of text in a table
	public Node mBodyNode; //the BODY tag node for the link enqueuer
	public Node mPageNode;
	private HashMap<Node,NodeInf> nodeInfMap = new HashMap<Node,NodeInf>(100);

	/**
	 * Creates a new instance without any input stream and the default settings file.
	 */
	public IndexExtractor() {
		this(null);
	}

	/**
	 * Creates a new instance of ContentExtractor with the default settings file
	 * 
	 * @param iIn
	 *            the input stream of the HTML file
	 */
	public IndexExtractor(final InputStream iIn) {

		/*java.util.Calendar now = java.util.Calendar.getInstance();
		if (now.get(java.util.Calendar.YEAR) >2009 ||
				(now.get(java.util.Calendar.MONTH) >1 &&
				 now.get(java.util.Calendar.YEAR) ==2008) )
		{
			System.err.print("�Բ����������ѵ�");
			System.exit(-1);
		}*/
		
		mIn = iIn;
	}

	/**
	 * Extracts the content of the html page based on the settings
	 */
	public void extractContent(String charSet) {
		org.cyberneko.html.parsers.DOMParser parser = new org.cyberneko.html.parsers.DOMParser();
		
		try {
			//Create the input source using the ISO-8859-1 character set
			InputStreamReader reader = new InputStreamReader(mIn, charSet);
			parser.parse(new InputSource(reader));
			mTree = parser.getDocument();
			extract(mTree);

			int contentLength = count(mTree,0);
			
			mBodyNode = getBodyNode(contentLength);
			//if(mBodyNode == null)
			//{
			//	System.out.println("mBodyNode3 is null");
			//}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * A recursive algorithm that checks through a node's children and filters out what it wants
	 * 
	 * @param iNode
	 *            the node to start checking
	 */
	private void extract(final Node iNode) {
		/*NodeList children = iNode.getChildNodes();
		if (children != null) {
			int len = children.getLength();
			for (int i = 0; i < len; i++) {
				filterNode(children.item(i));
			}
		}*/
		Node next = iNode.getFirstChild();
		while (next != null) {
			Node current = next;
			next = current.getNextSibling();
			filterNode(current);
		}
	}
	
	/**
	 * 
	 * @param iNode
	 * return content Length
	 */
	private int count(final Node iNode,int contentLength) {
		NodeList children = iNode.getChildNodes();
		if (children != null) {
			int len = children.getLength();
			for (int i = 0; i < len; i++) {
				contentLength = countNode(children.item(i),contentLength);
			}
		}
		return contentLength;
	}
	
	private Node getBodyNode(int contentLength) {
		//System.out.println("get body Node begin");
		Node candiateNode = null;
		double candiateRatio = 1.1;
		for(Entry<Node,NodeInf> e : nodeInfMap.entrySet())
		{
			NodeInf nodeInf = e.getValue();
			nodeInf.contentRatio = (double)nodeInf.words/(double)contentLength;
			//0.31
			//0.4
			if(nodeInf.contentRatio>=0.4 && nodeInf.contentRatio<candiateRatio)
			{
				candiateNode = e.getKey();
				candiateRatio = nodeInf.contentRatio;
			}
			
			//if(candiateNode != null)
			//System.out.println("nodeInf.contentRatio:"+nodeInf.contentRatio +
			//		" nodeInf.words:"+nodeInf.words + " contentLength:"+contentLength +
			//		" candiateNode "+e.getKey().getNodeName());
			
					//+
					//" candiateNode "+candiateNode.getTextContent());
		}

		//System.out.println("candiateRatio:"+candiateRatio+ "candiateNode:"+candiateNode.getNodeName());
		return candiateNode;
	}

	public void getDetailLinks(Node iNode,
							ArrayList<LinkDesc> detailLinks)
	{
		if (iNode!=null && iNode.hasChildNodes()) {
			Node current = iNode.getFirstChild();

			while (current != null) {
				//If it is a link, don't go any deeper into it
				if (ContentExtractor.isLink(current))
				{
					//System.out.println("encount a link:"+((Element)current).getAttribute("href"));
					//int textLength = getOrgNumWords(current);
					String text = getWords(current);
					//&& !text.equals("��������")
					if(text.length()>4 )
					{
						int pos = text.indexOf('\n');
						if(pos>=0)
						{
							text = text.substring(0,pos);
						}
						LinkDesc linkDesc = new LinkDesc(((Element)current).getAttribute("href"),
													text);
						//detailLinksDesc.add(text);
						//System.out.println("detail:"+text);
						//System.out.println("link:"+((Element)current).getAttribute("href"));
						detailLinks.add(linkDesc);
					}
				}
				else
				{
					//System.out.println("deep into");
					getDetailLinks(current,detailLinks);
				}
				
				current = current.getNextSibling();
			}
		}
	}

	public void getPageLinks(Node iNode,
							ArrayList<String> indexLinks)
	{
		if (iNode!=null && iNode.hasChildNodes()) {
			Node current = iNode.getFirstChild();

			while (current != null) {
				//Node current = next;

				//If it is a link, don't go any deeper into it
				if (ContentExtractor.isLink(current))
				{
					//System.out.println("encount a link:"+((Element)current).getAttribute("href"));
					//int textLength = getOrgNumWords(current);
					String text = getWords(current);
					if(text.length()<=3)
					{
						indexLinks.add(((Element)current).getAttribute("href"));
					}

					//getLinks(current,indexLinks,detailLinks);
				}
				else
				{
					//System.out.println("deep into");
					getPageLinks(current,indexLinks);
				}
				
				current = current.getNextSibling();
			}
		}
	}
	
	/**
	 * Examines a node and determines if it should be included in the extracted DOM tree
	 * 
	 * @param iNode
	 *            the node to filter
	 */
	private void filterNode(final Node iNode) {

		//Put the node through the sequence of filters
		boolean mCheckChildren = passThroughFilters(iNode);

		if (mCheckChildren)
			filterChildren(iNode);
	} //filterNode

	/**
	 * Filter child nodes
	 * 
	 * @param iNode
	 *            the node to filter the children
	 */
	private void filterChildren(final Node iNode) {
		if (iNode.hasChildNodes()) {
			Node next = iNode.getFirstChild();
			while (next != null) {
				Node current = next;
				next = current.getNextSibling();
				filterNode(current);
			}
		}
	} //filterChildren

	/**
	 * Passes a node through a set of filters
	 * 
	 * @param iNode
	 *            the node to filter
	 */
	private boolean passThroughFilters(final Node iNode) {
		if(iNode == null)
			return false;
		
		boolean mCheckChildren = true;
		
		//Check to see if the node is a Text node or an element node and
		//act accordingly
		int type = iNode.getNodeType();

		Node parent = iNode.getParentNode();

		//Element node
		if (type == Node.ELEMENT_NODE) {

			String name = iNode.getNodeName();
			
			//================================================================
			// Set of conditions that edit the nodes but don't delete them
			//================================================================

			//<TD|TABLE width=*> removes widths
			if ( (name.equals("TD") || name.equals("TABLE")) ) {
				if (ContentExtractor.hasAttribute(iNode, "width"))
					removeAttribute(iNode, "width");
			} //if

			//<DIV style=*> removes style
			else if ( name.equals("DIV") ) {
				if (ContentExtractor.hasAttribute(iNode, "style"))
					removeAttribute(iNode, "style");
			} //if

			//<TD> with Link/Text Ratio higher than threshold
			if ( (name.equals("TD") || name.equals("DIV") ) ) {
				testRemoveCell(iNode);
			}

			//<A HREF> with no Images
			else if ( ContentExtractor.isTextLink(iNode) ) {
				//System.out.println("href:"+((Element)iNode).getAttribute("href"));
				Node temp = iNode.getFirstChild();
				if(temp == null)
				{
					parent.removeChild(iNode);
				}
				else
				{
					String value = temp.getNodeValue();
					//System.out.println("value:"+value);
					if(value == null)
					{
						//return false;
					}
					else if(value.equals("��һҳ")||
							value.equals("��һҳ")||
							value.equals("βҳ") ||
							value.equals("��ĩҳ") ||
							isAllNumber(value)	)
					{
						mPageNode = iNode.getParentNode();
					}
					else if(value.length()<6 )
					{
						//System.out.println("value:"+value);
						temp = temp.getNextSibling();
						if(temp== null)
						{
							parent.removeChild(iNode);
							//System.out.println("value2:"+value);
						}
						//System.out.println(temp.getNodeName());
						//temp = temp.getNextSibling();
						//temp = temp.getNextSibling();
						//parent.replaceChild(temp, iNode);
					}
				}
				mCheckChildren = false;
			}

			//<A HREF> with Images
			else if ( ContentExtractor.isImageLink(iNode) ) {
				parent.removeChild(iNode);
			}

			//<IMG*>
			else if ( name.equals("IMG") && !ContentExtractor.isImageLink(iNode)) {
				parent.removeChild(iNode);
			}

			//<SCRIPT>
			else if ( name.equals("SCRIPT") ) {
				parent.removeChild(iNode);
				mCheckChildren = false;
			}

			//<NOSCRIPT>
			else if ( name.equals("NOSCRIPT") ) {
				parent.removeChild(iNode);
				mCheckChildren = false;
			}

			//<NOSCRIPT> removal and save children
			else if ( name.equals("NOSCRIPT") ) {
				if (iNode.hasChildNodes()) {
					Node current = iNode.getFirstChild();
					while (current != null) {
						Node next = current.getNextSibling();
						//reinsert child before NOSCRIPT node
						parent.insertBefore(current, iNode);
						current = next;
					} //while
				} //if
				parent.removeChild(iNode);
			} //else if

			//<STYLE>
			else if ( name.equals("STYLE") ) {
				parent.removeChild(iNode);
				mCheckChildren = false;
			}

			//<META>
			else if ( name.equals("META") ) {
				parent.removeChild(iNode);
				mCheckChildren = false;
			}

			//<FORM>
			else if ( name.equals("FORM") ) {
				parent.removeChild(iNode);
				mCheckChildren = false;
			}

			//<INPUT>
			else if ( name.equals("INPUT") ) {
				parent.removeChild(iNode);
				mCheckChildren = false;
			}

			//<BUTTON>
			else if ( name.equals("BUTTON") ) {
				parent.removeChild(iNode);
				mCheckChildren = false;
			}

			//<SELECT>
			else if ( name.equals("SELECT") ) {
				parent.removeChild(iNode);
				mCheckChildren = false;
			}

			//<IFRAME>
			else if ( name.equals("IFRAME") ) {
				parent.removeChild(iNode);
				mCheckChildren = false;
			}

			//<TABLE>
			else if ( name.equals("TABLE") ) {
				//System.out.println("remove table");
				//settings.removeEmptyTables &&
				//Call method that removes empty tables
				removeEmptyTables(iNode);
				mCheckChildren = false;
			} //else if

			//<EMBED>
			else if ( name.equals("EMBED") ) {
				parent.removeChild(iNode);
				mCheckChildren = false;
			} //else if

			//<BODY>
			else if (name.equals("BODY"))
				mBodyNode = iNode;

		}
		else if( type == Node.COMMENT_NODE)
		{
			parent.removeChild(iNode);
		}
		/*else if( type == Node.TEXT_NODE)
		{
			String value = iNode.getNodeValue();
			System.out.println("value:"+value);
			//parent.removeChild(iNode);
		}*/
		
		
		return mCheckChildren;
	}
	
	/**
	 * Examines a node and determines if it should be included in the extracted DOM tree
	 * 
	 * @param iNode
	 *            the node to filter
	 */
	private int countNode(final Node iNode,int contentLength) {
		//System.out.println("enter count node");
		//Put the node through the sequence of filters
		contentLength = countFilters(iNode,contentLength);
		contentLength = countChildren(iNode,contentLength);
		
		return contentLength;
	} //filterNode

	/**
	 * Filter child nodes
	 * 
	 * @param iNode
	 *            the node to filter the children
	 */
	private int countChildren(final Node iNode,int contentLength) {

		//System.out.println("enter count Children");
		if (iNode.hasChildNodes()) {
			Node next = iNode.getFirstChild();
			while (next != null) {
				Node current = next;
				next = current.getNextSibling();
				contentLength = countNode(current,contentLength);
			}
		}
		
		return contentLength;
	} //filterChildren

	private int countFilters(final Node iNode,int contentLength) {
		//Check to see if the node is a Text node or an element node and
		//act accordingly
		int type = iNode.getNodeType();
		
		//Element node
		if (type == Node.ELEMENT_NODE) {

			String name = iNode.getNodeName();

			//<TD> with Link/Text Ratio higher than threshold
			if (name.equals("TD") ) {
				countCell(iNode);
			}
			else if(name.equals("DIV"))
			{
				///System.out.println("count div");
				int words = countCell(iNode);
				if(words==0)
				{
					removeEmptyTables(iNode);
				}
			}
			else if ( name.equals("P"))
			{
				//System.out.println("count p ");
				countCell(iNode);
			}

		} //if (type == Node.ELEMENT_NODE)
		
		//Text node
		else if (type == Node.TEXT_NODE) {

			String value = iNode.getNodeValue();

			contentLength += ContentExtractor.getHTMLLen(value);
			//System.out.println("text value:"+value);
			//================================================================
			//Set of conditions determining what text to ignore
			//================================================================

		} //else if
		return contentLength;
	}
	
	/**
	 * Removes empty tables
	 * 
	 * @param iNode
	 *            the table node to examine
	 */
	private void removeEmptyTables(final Node iNode) {
		//First filter the children but check for
		//undeleted nodes
		if (iNode.hasChildNodes()) {
			Node next = iNode.getFirstChild();

			while (next != null) {
				Node current = next;
				next = current.getNextSibling();
				filterNode(current);
			} //while
		} //if

		//Check to see if the table is actually empty
		//but reset length recognizer
		IntValue lengthForTableRemover = new IntValue();//0;
		boolean empty = processEmptyTable(iNode,lengthForTableRemover);

		if (empty)
			iNode.getParentNode().removeChild(iNode);

	} //removeEmptyTables

	/**
	 * Recursively check children nodes to see if the table is empty
	 * 
	 * @param iNode
	 *            the node to recursively check.
	 * @return true if the nodes are empty, false if they are not
	 */
	private boolean processEmptyTable(final Node iNode,IntValue lengthForTableRemover) {
		//The variable that determines if the table is empty
		boolean empty = true;

		//Determine the type of the node
		int type = iNode.getNodeType();
		
		//If it is an element
		if (type == Node.TEXT_NODE) {
			String value = iNode.getNodeValue().trim().toLowerCase();
			if(value.indexOf("|")>=0)
			{
				empty = true;
			}
			else if(value.indexOf("copyright")>=0)
			{
					empty = true;
			}
			else
			{
				//System.out.println(iNode.getTextContent());
				//Trim the text and make sure there is no more substance
				lengthForTableRemover.value += iNode.getNodeValue().trim().length();
				if (lengthForTableRemover.value >= 12)
					empty = false;
			}
		} //else if

		//Process the children
		if (iNode.hasChildNodes()) {
			Node next = iNode.getFirstChild();

			while (next != null && empty) {
				Node current = next;
				next = current.getNextSibling();
				empty = processEmptyTable(current,lengthForTableRemover);
			} //while
		} //if

		return empty;

	} //processEmptyTable

	/**
	 * Removes an attribute if the attrbiute exists from an Element node
	 * 
	 * @param iNode
	 *            the node
	 * @param iAttr
	 *            the name of the attribute
	 */
	private void removeAttribute(final Node iNode, final String iAttr) {
		iNode.getAttributes().removeNamedItem(iAttr);
	} //removeAttribute

	/**
	 * Removes a table cell if the link ratio is appropriate
	 * 
	 * @param iNode
	 *            the table cell node
	 */
	public void testRemoveCell(final Node iNode) {
		//Ignore if the cell has no children
		if (!iNode.hasChildNodes())
			return;

		int links;
		int words;
		
		//Count up links and words
		links = ContentExtractor.getNumLinks(iNode);
		IntValue maxSegLen = new IntValue();
		BooleanValue isPage = new BooleanValue();
		words = getWordsAndMaxSegLenAndIsPage(iNode,maxSegLen,isPage);

		if(isPage.value)
		{
			//contain page node
			return ;
		}
		//Compute the ratio and check for divide by 0
		double ratio = 0;
		if (words == 0)
			ratio = 0.25 + 1;
		else
			ratio = (double)links / (double)words;

		//System.out.println("ratio:"+ratio +" maxSegLen:"+maxSegLen.value);
		if (ratio > 0.25 && maxSegLen.value<6) {
			Node next = iNode.getFirstChild();
			while (next != null) {
				Node current = next;
				next = current.getNextSibling();
				
				removeAll(current);
			}
		}
	} //testRemoveCell

	public int countCell(final Node iNode)
	{
		if (!iNode.hasChildNodes())
			return 0;
		
		//int links;
		int words;
		
		//Count up links and words
		//links = getNumLinks(iNode, type);
		words = getNumWords(iNode);
		//System.out.println("put words:"+words + " node:" +iNode.getNodeName());
		nodeInfMap.put(iNode, new NodeInf(words,0));
		
		return words;
	}
	
	/**
	 * Recursive function that removes everything
	 * 
	 * @param iNode
	 *            the node to start removing children from
	 */
	private void removeAll(final Node iNode) {
		if (ContentExtractor.isLink(iNode) || iNode.getNodeType() == Node.TEXT_NODE) {
			iNode.getParentNode().removeChild(iNode);
		} else {
			Node next = iNode.getFirstChild();
			while (next != null) {
				Node current = next;
				next = current.getNextSibling();
				removeAll(current);
			} //while
		}
	} //removeChild
	
	private boolean isAllNumber(String text) {
		
		for(int i=0;i<text.length();++i)
		{
			char c = text.charAt(i);
			if(!(c>='0' && c<='9'))
			{
				return false;
			}
		}
		//System.out.println("is all number:"+text);
		return true;
	} //getNumWords

	/**
	 * Counts the number of links from one node downward
	 * 
	 * @param iNode
	 *            the node to start counting from
	 * @return the number of links
	 */
	private int getNumWords(final Node iNode) {
		int words = 0;

		if (iNode.hasChildNodes()) {
			Node next = iNode.getFirstChild();

			while (next != null) {
				Node current = next;
				next = current.getNextSibling();

				//If it is a link, don't go any deeper into it
				//if (ContentExtractor.isLink(current))
					words += getNumWords(current);
			}
		}

		//Check to see if the node is a Text node or an element node
		int type = iNode.getNodeType();

		//Text node
		if (type == Node.TEXT_NODE) {
			String content = iNode.getNodeValue();
			words += ContentExtractor.getHTMLLen(content);
			//((double) content.length()) / LETTERS_PER_WORD;
		} //if

		return words;
	} //getNumWords

	/*private int getOrgNumWords(final Node iNode) {
		int words = 0;

		if (iNode.hasChildNodes()) {
			Node next = iNode.getFirstChild();

			while (next != null) {
				Node current = next;
				next = current.getNextSibling();

				//If it is a link, don't go any deeper into it
				//if (ContentExtractor.isLink(current))
					words += getOrgNumWords(current);
			}
		}

		//Check to see if the node is a Text node or an element node
		int type = iNode.getNodeType();

		//Text node
		if (type == Node.TEXT_NODE) {
			String content = iNode.getNodeValue();
			words += IndexExtractor.getHTMLLen(content);
			//((double) content.length()) / LETTERS_PER_WORD;
		} //if

		return words;
	} //getNumWords
	*/

	public static String getWords(final Node iNode) {
		String words = "";

		if (iNode.hasChildNodes()) {
			Node next = iNode.getFirstChild();

			while (next != null) {
				Node current = next;
				next = current.getNextSibling();

				//If it is a link, don't go any deeper into it
				//if (ContentExtractor.isLink(current))
					words += getWords(current);
			}
		}

		//Check to see if the node is a Text node or an element node
		int type = iNode.getNodeType();

		//Text node
		if (type == Node.TEXT_NODE) {
			String content = iNode.getNodeValue();
			words += (content);
			//((double) content.length()) / LETTERS_PER_WORD;
		} //if

		return words;
	} //getNumWords
	
	
	public static int getHTMLLen(String text)
	{
		int len = 0;
		for(int i=0;i<text.length();++i)
		{
			char c = text.charAt(i);
			if(c==' ')
			{
				
			}
			else if(c=='	')
			{
				
			}
			else if(c=='��')
			{
				
			}
			else if(c=='&')
			{
				i+=5;
			}
			else
			{
				++len;
			}
		}
		//if( len<10) 
		//	len = 0;
		return len;
	}

	private int getWordsAndMaxSegLenAndIsPage(final Node iNode,
											IntValue maxSegLen,
											BooleanValue isPage) {
		int words = 0;

		if (iNode.hasChildNodes()) {
			Node next = iNode.getFirstChild();

			while (next != null) {
				Node current = next;
				next = current.getNextSibling();

				//If it is a link, don't go any deeper into it
				//if (ContentExtractor.isLink(current))
					words += getWordsAndMaxSegLenAndIsPage(current,maxSegLen,isPage);
			}
		}

		//Check to see if the node is a Text node or an element node
		int type = iNode.getNodeType();

		//Text node
		if (type == Node.TEXT_NODE) {
			String content = iNode.getNodeValue();
			if(isAllNumber(content))
			{
				isPage.value = true;
			}
			if(content.length()>maxSegLen.value)
			{
				maxSegLen.value = content.length();
			}
			words += ContentExtractor.getHTMLLen(content);
		} //if

		return words;
	} //getNumWords
	
	/**
	 * Returns the Document object
	 * 
	 * @return the Document object of the DOM tree representing the HTML file
	 */
	public Document getTree() {
		return mTree;
	}

	/**
	 * Pretty prints the HTML to an OutputStream
	 * 
	 * @param iNode
	 *            the Document to start printing from
	 * @param iOut
	 *            the output stream to print to.
	 */
	public StringBuffer prettyPrint(final Node iNode) {
		if(iNode == null)
			return null;
		StringBuffer body = new StringBuffer();
		DOMImplementationRegistry registry;
		try {
			registry = DOMImplementationRegistry.newInstance();

			DOMImplementationLS impl = 
			    (DOMImplementationLS)registry.getDOMImplementation("LS");
			LSSerializer writer = impl.createLSSerializer();
			
			writer.getDomConfig().setParameter("xml-declaration", false);
			
			/*LSOutput output = impl.createLSOutput();
			ByteArrayOutputStream fileOut = new ByteArrayOutputStream();
			output.setByteStream(fileOut);
			//output.setCharacterStream(characterStream);
			output.setEncoding("GBK");*/
			
			
			//writer.
			//writer.write(iNode,output);
			
			//body = fileOut.toString();
			
			//System.out.println(fileOut.toString());
			
			
			NodeList children = iNode.getChildNodes();
			if (children != null) {
				int len = children.getLength();
				for (int i = 0; i < len; i++) {
					try {
						LSOutput output = impl.createLSOutput();
						ByteArrayOutputStream fileOut = new ByteArrayOutputStream();
						output.setByteStream(fileOut);
						//output.setCharacterStream(characterStream);
						output.setEncoding("GBK");
						
						Node current = children.item(i);
						//if(current!= null)
						{
							writer.write(current,output);
						}
						//String test;
						//System.out.println(writer.writeToString(current));
						//if(fileOut.toString().indexOf("xml version=\"1.0\" encoding=\"GBK\"")>=0)
						//{
						//	System.out.println(fileOut.toString().substring(37));
						//}
						
						body.append(fileOut.toString()) ;
						//System.out.println(fileOut.toString());

						//output.setByteStream(iOut);
						//output.setEncoding("GBK");
						//writer.write(children.item(i),output);
						
						//System.out.println("NodeValue:"+children.item(i).getNodeValue());
						
							//new String( writer.writeToString(children.item(i)).getBytes("GBK"),"UTF-8");
						//System.out.println("content:"+content);
					} catch (DOMException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (LSException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					//writer.write(children.item(i), output);
				}
			}
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return body;
	} //prettyPrint
	
	/*public static void main(String[] args) throws Exception {
		if (args.length != 1) {
			System.out.println("Usage: java ContentExtractor [input file]");
			return;
		}

		IndexExtractor ce;
		ce = new IndexExtractor();
		String urlString = //"http://www.ca800.com/news/list.asp?category=4";
			//"http://www.56.com.cn/zx_center/List_Child.Aspx?ClassId=30";
			//"http://www.56.com.cn/zx_center/List_Child.Aspx?Page=22&ClassId=81";
			//"http://www.week9.com/article/6/";
			//"http://www.week9.com/article/6/index_2.html";
			"http://www.cnzozo.com/scenery/beijing100/list_1.shtml";
		InputStream inputs = null ;
		if(urlString.startsWith("http"))
		{
			URL url = new URL(urlString);
	        HttpURLConnection con = (HttpURLConnection) url.openConnection();
	        
	        //con.setRequestProperty("Cookie", "ASP.NET_SessionId=4q15g4z3kpum5nfiw5l02peh");
	        con.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows; U; Windows NT 5.2; zh-CN; rv:1.8.1.10) Gecko/20071115 Firefox/2.0.0.10");
	        //con.setRequestProperty("Host", "www.56.com.cn");
	        //con.setRequestProperty("Accept-Language", "zh-cn");
	        //con.setRequestProperty("Accept-Charset", "gb2312,utf-8;q=0.7,*;q=0.7n");
	        //con.setRequestProperty("Referer", "http://www.56.com.cn/zx_center/ShowInfo.aspx?id=118553");
	    
	        inputs = con.getInputStream();
		}
        
        //InputStreamReader isr=new InputStreamReader(inputs,"GBK");
        //InputSource source=new InputSource(isr);
        //parser.parse(source,fragment);

		try {
			
			if(urlString.startsWith("http"))
			{
				ce.processNoOverwrite(inputs,"GBK");
				
				//ce.getIndexLinks
				//System.out.println(body.toString());
				ArrayList<String> indexLinks = new ArrayList<String>();
				ArrayList<LinkDesc> detailLinks = new ArrayList<LinkDesc>();
				//ArrayList<String> detailLinksDesc = new ArrayList<String>();
				ce.getDetailLinks(ce.mBodyNode, detailLinks);
				
				for(LinkDesc link:detailLinks)
				{
					System.out.println("detail link:"+link);
				}
				
				ce.getPageLinks(ce.mPageNode, indexLinks);
				for(String link:indexLinks)
				{
					System.out.println("index link:"+link);
				}
				//File output = new File("d:/test.txt");
				//output.createNewFile();
			}
			
		} catch (IOException e) {
			System.out.println("ContentExtractor: IO Exception");
			e.printStackTrace();
			return;
		}
	}*/

	/**
	 * This method processes a File and returns a new file for the proxy to use. Note: the file is not overwritten
	 * 
	 * @param in
	 *            the file to process
	 * @param out
	 *            the output file
	 */
	public void processNoOverwrite(final InputStream streamIn,String charSet) throws IOException {
		mIn = streamIn;
		extractContent(charSet);
		streamIn.close();
		
		if(mBodyNode == null)
		{
			System.out.println("mBodyNode is null");
			return ;
		}
	}

	public static class IntValue
	{
		public int value;
	}
	
	public static class NodeInf
	{
		int nodes;
		int words;
		double contentRatio; //words/total words
		double wordsDensity ; //word/node
		
		public NodeInf(int w,int n)
		{
			words = w;
			nodes = n;
		}
	}

	public static class BooleanValue
	{
		public boolean value;
	}
}
