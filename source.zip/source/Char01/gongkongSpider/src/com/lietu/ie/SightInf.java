package com.lietu.ie;

public class SightInf {
	public String name;
	public String desc;
	public String address;
}
