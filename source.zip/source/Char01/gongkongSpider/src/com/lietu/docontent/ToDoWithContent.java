package com.lietu.docontent;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Date;

import org.htmlparser.Node;
//import org.htmlparser.Parser;
import org.htmlparser.PrototypicalNodeFactory;
import org.htmlparser.lexer.Lexer;
import org.htmlparser.lexer.Page;
import org.htmlparser.lexer.nodes.NodeFactory;
import org.htmlparser.lexer.nodes.StringNode;
import org.htmlparser.lexer.nodes.TagNode;
import org.htmlparser.util.ParserException;

import com.bitmechanic.spindle.TextHtml;
import com.bitmechanic.spindle.URLSummary;
//import com.lietu.chinamet.CatGeneral;

public class ToDoWithContent extends URLSummary{
	public static NodeFactory typicalFactory =  new PrototypicalNodeFactory ();
	
	public void parseHTML(Lexer lexer ,String include, boolean expand ) throws ParserException
	{
		Node node;
		String stringText;
		
		lexer.setNodeFactory(typicalFactory);
		while (null != (node = lexer.nextNode ()))
		{
			//omit script tag
			if (node instanceof org.htmlparser.tags.ScriptTag)
			{
				while (null != (node = lexer.nextNode ()))
				{
					if (node instanceof org.htmlparser.tags.Tag)
					{
						org.htmlparser.tags.Tag tag  = (org.htmlparser.tags.Tag)node;
						if( tag.isEndTag() && "SCRIPT".equals(tag.getTagName())  )
						{
							//System.out.println("tagname:"+tag.getTagName());
							break;
						}
					}
				}
				if(null == node)
					break;
			}
			//omit script tag
			else if (node instanceof org.htmlparser.tags.StyleTag)
			{
				while (null != (node = lexer.nextNode ()))
				{
					if (node instanceof org.htmlparser.tags.Tag)
					{
						org.htmlparser.tags.Tag tag  = (org.htmlparser.tags.Tag)node;
						if( tag.isEndTag())
							break;
					}
				}
				if(null == node)
					break;
			}
			else if (node instanceof StringNode)
			{
				stringText = node.toPlainTextString();
				if("".equals(title) )
					continue;
				stringText = stringText.replaceAll("[ \t\n\f\r��]+"," ");
				stringText = TextHtml.html2text(stringText.trim());
				if (! "".equals(stringText))
				{
					//System.out.println("stringText.len:"+stringText.length());
					this.body.append(stringText);					
					this.body.append(" ");
//					System.out.println(this.body);
				}
			}
			else if (node instanceof TagNode)
			{
				TagNode tagNode = (TagNode)node;
				String name = ((TagNode)node).getTagName();
				if(name.equals("OPTION"))
				{
					//omit option
					lexer.nextNode ();
					lexer.nextNode ();
					//System.out.println("tag name:"+name);
				}
				else if (name.equals("A") && !tagNode.isEndTag() && expand)
				{
					String href = tagNode.getAttribute("HREF");
					
					String urlDesc = null;
					node = lexer.nextNode ();
					if(node instanceof StringNode)
					{
						StringNode sNode = (StringNode)node;
						String title = sNode.getText().trim();
						
						if(title.length()>=4)
						{
							urlDesc= title;
							//System.out.println("next node:"+title);
						}
					}

					addLink(this.url,include,href,urlDesc);
				}
				else if (name.equals("FRAME") &&
						!tagNode.isEndTag() && expand)
				{
					// FRAME SRC=
					addLink(url,include,tagNode.getAttribute("SRC"),null);
					// handle internal frame (iframes) as well
				}
				else if (name.equals("TITLE") &&
						!tagNode.isEndTag() )
				{
					node = lexer.nextNode ();
					stringText = node.toPlainTextString();
					this.title=stringText;
				}
			}
		}
	}
/**
 * liuyefei
 * @param url
 * @return urlBody.body.toString();
 * @throws Exception
 */
	public String doWithURL(String url) throws Exception {
		 
        URLSummary urlBody = new ToDoWithContent();
		urlBody.url = new URL(url);
		urlBody.accessDate = new Date();
		
//		Parser parser = new Parser (url);
		HttpURLConnection uc = (HttpURLConnection) urlBody.url.openConnection();
		String ct = uc.getContentType();
		//System.out.println("ct:" + ct);
		//TODO:iso-8859-1 or UTF-8 or GB2312 or ecode
		Lexer lexer = new Lexer (new Page(uc.getInputStream(),Page.getCharset (ct)));
		//URL theURL = new URL(urlBody.url.replaceAll(" ","%20"));
		//
		//lexer = new Lexer (new Page(uc.getInputStream(), Page.getCharset (ct)));
		
		//urlBody.parseHTML( parser.getLexer(),null,true);
		//urlBody.parseHTML( lexer,null,true);
		return urlBody.body.toString();
//		System.out.println(urlBody.toString());
	}
	
	public String[] ContentCompare(String url1, String url2) throws Exception {
		LCString lcs = new LCString();
		String comp = null;
		String comp1 = null;
		String comp2 = null;
		String[] temp = new String[2];
		if ((url1 == null) || (url1 == null)) {
			return null;
		}
		comp1 = this.doWithURL(url1);
		// System.out.println("do comp1:"+comp1);
		comp2 = this.doWithURL(url2);

		// System.out.println("do comp2:"+comp2);
		comp = lcs.getLCString(comp1, comp2);
		// System.out.println("comp 1:"+comp);
		temp[0] = comp;
		comp1 = comp1.replace(comp, "");
		// System.out.println("done comp1:"+temp1);
		comp2 = comp2.replace(comp, "");
		// System.out.println("done comp2:"+temp2);
		comp = lcs.getLCString(comp1, comp2);
		// System.out.println("comp 2:"+comp);
		temp[1] = comp;
		return temp;
		// return comp;
	}
	
	/*public static void main(String[] args) throws Exception {
		ToDoWithContent todo = new ToDoWithContent();
		String[] temp = new String[2];
//		String temp = null;
		temp = todo.ContentCompare("http://www.fengguang.com/",
				"http://www.fengguang.com/xwzx/fgkx051.htm");
		for (int i = 0; i < temp.length; i++) {
			System.out.println(temp[i]);
		}
//		System.out.println(temp);
	}*/
}


