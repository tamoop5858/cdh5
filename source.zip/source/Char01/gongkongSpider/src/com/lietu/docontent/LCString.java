package com.lietu.docontent;

import java.util.ArrayList;

/**
 * parse public substring
 * @author Administrator
 *
 */
public class LCString {
	
	public static String getLCString(String str1, String str2) {
		StringBuffer str = new StringBuffer() ;
		int i, j;
		int len1, len2;
		len1 = str1.length();
		len2 = str2.length();
		int maxLen = len1 > len2 ? len1 : len2;
		int[] max = new int[maxLen];
		int[] maxIndex = new int[maxLen];
		int[] c = new int[maxLen];

		for (i = 0; i < len2; i++) {
			for (j = len1 - 1; j >= 0; j--) {
				if (str2.charAt(i) == str1.charAt(j)) {
					if ((i == 0) || (j == 0))
						c[j] = 1;
					else
						c[j] = c[j - 1] + 1;
				} else {
					c[j] = 0;
				}

				if (c[j] > max[0]) {
					max[0] = c[j];
					maxIndex[0] = j;

					for (int k = 1; k < maxLen; k++) {
						max[k] = 0;
						maxIndex[k] = 0;
					}
				} else if (c[j] == max[0]) {
					for (int k = 1; k < maxLen; k++) {
						if (max[k] == 0) {
							max[k] = c[j];
							maxIndex[k] = j;
							break;
						}
					}
				}
			}
		}

		for (j = 0; j < maxLen; j++) {
			if (max[j] > 0) {
				str.append(str1.substring(maxIndex[j] - max[j] + 1,maxIndex[j]+1));
			}
		}
		return str.toString().trim();
	}

	public static ArrayList<String> removeContent(String str1,String str2){
		ArrayList<String> com = new ArrayList<String>(5);
		for(int i = 0;i<5;i++){
			String commonStr = LCString.getLCString(str1, str2);
			if(commonStr.length()<20){
				break;
			}
			com.add(commonStr);
			str2 = str2.replace(commonStr, "");
		}
		return com;
	}
}
