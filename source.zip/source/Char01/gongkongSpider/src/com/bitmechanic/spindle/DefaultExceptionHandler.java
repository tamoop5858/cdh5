package com.bitmechanic.spindle;

import java.io.InputStream;
import java.lang.Thread.*;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Properties;

public class DefaultExceptionHandler implements UncaughtExceptionHandler {
  public void uncaughtException(Thread t, Throwable e) {
    if(e instanceof java.net.UnknownHostException)
    {
    	try
    	{
			Properties properties = new Properties();
			InputStream is = this.getClass().getResourceAsStream("/"+SpiderSolr.configFile);
			properties.load(is);
			is.close();
			String driver = properties.getProperty("driver");
			//System.out.println(driver);
			String dburl = properties.getProperty("dburl");
			//System.out.println(dburl);
			String user = properties.getProperty("user");
			//System.out.println(user);
			String password = properties.getProperty("password");
			//System.out.println(password);
			Driver drv = (Driver)Class.forName(driver).newInstance();
			DriverManager.registerDriver(drv);
			Connection con = DriverManager.getConnection(dburl,user,password);
			String sql = "update spider set valid=0 where url like '%"+e.getCause().getMessage()+"%'";
			System.out.println(sql);
			Statement stmt = con.createStatement();
			stmt.executeUpdate(sql);
			con.close();
	    }catch(Exception e2)
    	{
    		
    	}
    }
    else
    {
    	System.out.println("not java.net.UnknownHostException");
    }
    e.printStackTrace(System.out);
  }
}

