/*
 * Created on 2004-6-10
 *
 */

package com.bitmechanic.spindle;

import com.sleepycat.je.Environment;
import com.sleepycat.je.EnvironmentConfig;
import java.io.File;

/**
 * Database manager
 * @author Administrator
 *
 */
public class EDBManager {
	
	private static Environment exampleEnv = null;
	private static ToDoTaskList todoTaskList = null;
	private static VisitedTaskList visitedTaskList = null;
	public static BadLinkList badLink = null;
	
	/*public static void main(String argv[]) throws Exception {
		String dbDir = null; 
        String blackURL = null;
        if (argv.length == 2)
        {
        	dbDir = argv[0];
        	blackURL = argv[1];
        }
        else
        {
            usage();
            System.exit(1);
        }

        System.out.println("database dir:"+dbDir);
        System.out.println("black website:"+blackURL);
        //"/home/spider/db/task"
	    EDBManager taskManager= new EDBManager(dbDir,true);

		ToDoTaskList todo = taskManager.getTodoTask();
		todo.removePrefix(blackURL);
	
	    EDBManager.close();
	}*/
	
	/**
	 * ����ʵ��
	 */
	public EDBManager(String dir,boolean incremental) throws Exception {

        EDBManager.close();
        if (!incremental) {
        	File dbHome = new File(dir);
        	if (!dbHome.exists())
        	{
        		dbHome.mkdir();
        		System.out.println("make dir:"+dir);
        	}
        	
            File[] files = dbHome.listFiles();

            for (int i = 0; i < files.length; i++)
                files[i].delete();
            //dbHome.delete();
        }

		File envDir = new File(dir);
        EnvironmentConfig envConfig = new EnvironmentConfig();
        envConfig.setTransactional(false); 
        envConfig.setAllowCreate(true); 
        exampleEnv = new Environment(envDir, envConfig);	        
		
		todoTaskList = new ToDoTaskList(exampleEnv);
		visitedTaskList = new VisitedTaskList(exampleEnv);
		badLink = new BadLinkList(exampleEnv);
	}

	public BadLinkList getBadLink(){
		return badLink; 
    }

	public ToDoTaskList getTodoTask(){
		return todoTaskList; 
    }

	public VisitedTaskList getVisitedTaskList(){
		return visitedTaskList; 
    }
	
	public void updateDb() throws Exception{
		exampleEnv.sync(); //For non-transactional only
	}
	
	public static void close() throws Exception{

		if (todoTaskList != null){
			todoTaskList.close();
			todoTaskList = null;
		}

		if (visitedTaskList != null){
			visitedTaskList.close();
			visitedTaskList = null;
		}

		if (badLink != null){
			badLink.close();
			badLink = null;
		}
		
		if (exampleEnv != null){
			exampleEnv.sync(); //For non-transactional only
			exampleEnv.close();
			exampleEnv = null;
		}

	}

	/**
	 *
	 */
    private static void usage()
    {
        System.out.println("\n\n" +
            "java com.bitmechanic.spindle.EDBManager <dir> <url>\n\n");
    }
}
