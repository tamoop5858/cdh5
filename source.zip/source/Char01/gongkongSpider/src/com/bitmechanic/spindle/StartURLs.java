/*
 * Created on 2004-4-30
 * 
 */
package com.bitmechanic.spindle;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;
import java.util.TreeMap;

import java.io.InputStream;

import java.net.URL;

/**
 * @author lg 
 * 
 * special word: %Y %m %d
 */
public class StartURLs {
	private XmlElement[] startURLs = null;
	
	int count =0;
	public String year;
	public String month;
	public String day;
	
	public StartURLs(String configFile) {
		startURLs = getXml(configFile);
		for(int i=0;i<startURLs.length;++i)
		{
			System.out.println(startURLs.toString());
		}
		Date now = new Date();
	
		//-MM-dd HH:mm:ss
		year = new SimpleDateFormat("yyyy").format(now);
		month = new SimpleDateFormat("MM").format(now);
		day = new SimpleDateFormat("dd").format(now);
		
	}
	
	public TreeMap getCatMap()
	{
		TreeMap catMap= new TreeMap();
	
		for(int i=0;i<startURLs.length;i++)
		{
			catMap.put(startURLs[i].getTypes(),startURLs[i].getClasses());
		}
		
		return catMap;
	}

	public String[] getCatName() {
		if (startURLs == null)
			return null;
		
		ArrayList  al = new ArrayList();
		
		for(int i=0;i<startURLs.length;i++)
		{
			al.add(startURLs[i].getTypes());
		}
		
		return (String[]) al.toArray(new String[al.size()]);
	}

	/**
	 * ������Ǵ����ݿ��а�spider.xml���ݶ�������spider.xml�������Ѿ����ȴ�����ݿ�
	 * @author liuyefei
	 */
	public XmlElement[] getXml(String configFile)
	{
		ArrayList  al = new ArrayList();
		try{
			Properties properties = new Properties();
			InputStream is = this.getClass().getResourceAsStream("/"+configFile);
			properties.load(is);
			is.close();
			String driver = properties.getProperty("driver");
			System.out.println(driver);
			String dburl = properties.getProperty("dburl");
			System.out.println(dburl);
			String user = properties.getProperty("user");
			System.out.println(user);
			String password = properties.getProperty("password");
			System.out.println(password);
			Driver drv = (Driver)Class.forName(driver).newInstance();
			DriverManager.registerDriver(drv);
			Connection con = DriverManager.getConnection(dburl,user,password);
			String sql = "select url,type,class,rank from spider where valid=1 ";
			PreparedStatement pstmt = con.prepareStatement(sql);
			ResultSet result = pstmt.executeQuery();
			while (result.next()) {
					String url = result.getString(1);
					String type = result.getString(2);
					String classs = result.getString(3);
					int rank = result.getInt(4);
					//System.out.println("\nurl:"+url+"\ntype:"+type+"\nrank:"+rank);	
					XmlElement xel = new XmlElement(url,type,classs,rank);
					al.add(xel);
			}
			result.close();
			pstmt.close();
			if (con != null) {
				con.close();
				System.out.println("Close Success!");
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return  (XmlElement[]) al.toArray(new XmlElement[al.size()]);	
	}
	
	public String getCat(int cat) {
		if (cat < 0) return null;
		
		return startURLs[cat].getTypes();
	}

	public NewsSource getNextURL() throws Exception
	{
		if (count<startURLs.length)
		{
			String URL = startURLs[count++].getUrl();
			if (URL.indexOf("%")>0 )
			{
				StringBuffer sb = new StringBuffer();
				int iIndex;
				
				iIndex = URL.indexOf("%Y");
	
				if (iIndex>=0)
				{
					sb.append(URL.substring(0,iIndex));
					sb.append(year);
					URL = URL.substring(iIndex + 2);
				}
	
				iIndex = URL.indexOf("%m");
	
				if (iIndex>=0)
				{
					sb.append(URL.substring(0,iIndex));
					sb.append(month);
					URL = URL.substring(iIndex + 2);
				}
	
				iIndex = URL.indexOf("%d");
	
				if (iIndex>=0)
				{
					sb.append(URL.substring(0,iIndex));
					sb.append(day);
					URL = URL.substring(iIndex + 2);
				}
				sb.append(URL);
				
				String include = getInclude(sb.toString());
				return new NewsSource(sb.toString(),
						startURLs[count - 1].getTypes(),
						include,
						startURLs[count - 1].getRank());
			}
			
			String include = getInclude(URL);
			
			return new NewsSource(URL,
					startURLs[count - 1].getTypes(),
					include,
					startURLs[count - 1].getRank());
			//return URL;
		}
		return null;
	}
	
	public static String getInclude(String URL)
	{
		String include = null;
		
		try{
			include = new URL(URL).getPath();
			if ("".equals(include)) include = null;
			if (! include.endsWith("/"))
			{
				include = include.substring(0,include.lastIndexOf('/')+1);
			}
		}
		catch(Exception e)
		{}
		
		return include;
	}
}

