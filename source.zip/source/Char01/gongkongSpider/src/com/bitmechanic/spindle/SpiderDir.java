package com.bitmechanic.spindle;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.util.Properties;

import com.lietu.filter.PDFBox;
import com.lietu.filter.WordReader;

public class SpiderDir {
    private String sSourceDir;
    private boolean verbose;

	/*public static void main(String[] args) throws Exception  {
		SpiderDir s = new SpiderDir(args);
        s.go();
	}*/
	
    public SpiderDir(String argv[]) throws Exception  {
        verbose = false;
        
        for (int i = 0; i < argv.length; i++) {
            if (argv[i].equals("-s"))
            	sSourceDir = argv[++i];
            else if(argv[i].equals("-v"))
                verbose = true;
        }
        
        if (sSourceDir == null)
            throw new IllegalArgumentException("Missing required argument: -s [SourceDir dir]");
    }

    public void go() throws Exception  {
		long start = System.currentTimeMillis();		

    	Properties p = new Properties();
    	InputStream is=this.getClass().getResourceAsStream("/spider.properties");
    	p.load(is);
		is.close();
		String solr = p.getProperty("solr");
    	solrUrl = new URL(solr);
    	
        File dir = new File(sSourceDir);
        
        indexDir(dir);
        
        if(verbose)
        	System.out.println("index complete in :"+(System.currentTimeMillis() - start)/1000);
    }
    
    private void indexDir(File dir)
    {
        File[] files = dir.listFiles();

        for (int i = 0; i < files.length; i++) {
          File f = files[i];
          if (f.isDirectory()) {
            indexDir(f);  // recurse
          } else {
            indexFile(f);
          }
        }
    }

    private void indexFile(File item) {
        if (verbose) System.out.println("Adding FILE: " + item);
        
        News news = loadFile(item);

        if ( news!= null && news.body != null) {

            try{
            	StringBuilder xmlContent = new StringBuilder();
    			xmlContent.append("<add>");
    			xmlContent.append("<doc>");
    			XML.writeXML(xmlContent, "field", news.id, "name",
    					"id");
    			XML.writeXML(xmlContent, "field", news.URL, "name",
    					"url");
    			XML.writeXML(xmlContent, "field", news.title,
    					"name", "title");
    			XML.writeXML(xmlContent, "field", news.body.toString(), "name",
    					"body");
    			xmlContent.append("</doc>");
    			xmlContent.append("</add>");
    			StringWriter sw = new StringWriter();
    			postData(new StringReader(xmlContent.toString()),
    					sw);
            }
            catch(Exception e)
			{
            	e.printStackTrace();
            	System.exit(-1);
            }
        }
    }
    
    /**
     * Pipes everything from the reader to the writer via a buffer
     */
    private static void pipe(Reader reader, Writer writer) throws IOException {
      char[] buf = new char[1024];
      int read = 0;
      while ( (read = reader.read(buf) ) >= 0) {
        writer.write(buf, 0, read);
      }
      writer.flush();
    }
    
    static URL solrUrl = null;
    public static final String POST_ENCODING = "UTF-8";
    /**
     * Reads data from the data reader and posts it to solr,
     * writes to the response to output
     * @throws Exception 
     */
    public void postData(Reader data, Writer output) throws Exception {
      HttpURLConnection urlc = null;
      try {
    	  System.out.println("solrUrl:"+solrUrl);
        urlc = (HttpURLConnection) solrUrl.openConnection();
        try {
          urlc.setRequestMethod("POST");
        } catch (ProtocolException e) {
          throw new Exception("Shouldn't happen: HttpURLConnection doesn't support POST??", e);
        }
        urlc.setDoOutput(true);
        urlc.setDoInput(true);
        urlc.setUseCaches(false);
        urlc.setAllowUserInteraction(false);
        urlc.setRequestProperty("Content-type", "text/xml; charset=" + POST_ENCODING);
        
        OutputStream out = urlc.getOutputStream();
        
        try {
          Writer writer = new OutputStreamWriter(out, POST_ENCODING);
          pipe(data, writer);
          writer.close();
        } catch (IOException e) {
          throw new Exception("IOException while posting data", e);
        } finally {
          if(out!=null) out.close();
        }
        
        InputStream in = urlc.getInputStream();
        try {
          Reader reader = new InputStreamReader(in);
          pipe(reader, output);
          reader.close();
        } catch (IOException e) {
          throw new Exception("IOException while reading response", e);
        } finally {
          if(in!=null) in.close();
        }
        
      } catch (IOException e) {
    	  throw new Exception("Connection error (is Solr running at " + solrUrl + " ?): " + e);
      } finally {
        if(urlc!=null) urlc.disconnect();
      }
    }
    
    private static News loadFile(File sSourceFile){
    	String fileName = sSourceFile.getName().toLowerCase();
    	String text = null;
    	String title = null;

    	News news = new News();
    	
		try
		{
	    	if (fileName.endsWith(".doc"))
	    	{
	    		//word document
	    		InputStream is = new FileInputStream(sSourceFile);
				text = WordReader.readDoc(is);
				title = WordReader.getTitle(text);
	    	}
	    	else if( fileName.endsWith(".pdf") )
	    	{
	    		//pdf document
	    		InputStream is = new FileInputStream(sSourceFile);
				text = PDFBox.getText(is);
				title = PDFBox.getTitle(text);
	    	}
	    	else
	    	{
	    		return null;
	    	}
	    	
	    	news.id = sSourceFile.toString();
	    	System.out.println("id:"+news.id);
			news.URL = "http://download.gongkong.com/file/"+sSourceFile.getName();
			news.title = title;
			news.body = new StringBuffer(text);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		return news;
    }
    
    static class News {
    	public String URL;
    	public String id;
    	public String title;
    	public StringBuffer body;

    	public News(){
    		this.URL = "";
    		this.title = "";
    		this.body = new StringBuffer();
    	}
    	
    	public String toString(){
    		return "URL :"+URL+" title :" + title +" body :"+ body.toString() ;
    	}
    }
}
