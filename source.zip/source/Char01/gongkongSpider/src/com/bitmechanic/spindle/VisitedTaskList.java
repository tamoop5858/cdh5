/*
 * Created on 2004-4-29
 *
 * Visited task database implement
 */
package com.bitmechanic.spindle;

import com.sleepycat.bind.serial.SerialBinding;
import com.sleepycat.bind.tuple.TupleBinding;
import com.sleepycat.bind.serial.StoredClassCatalog;
import com.sleepycat.je.Cursor;
import com.sleepycat.je.Database;
import com.sleepycat.je.DatabaseConfig;
import com.sleepycat.je.DatabaseEntry;
import com.sleepycat.je.DatabaseException;
import com.sleepycat.je.Environment;
import com.sleepycat.je.LockMode;
import com.sleepycat.je.OperationStatus;
import com.sleepycat.collections.StoredSortedMap;

import java.util.SortedMap;

/**
 * @author hmllg
 *
 */
public class VisitedTaskList {

	/** 
	 * Task store 
	 *
	 * @link aggregation
	 * @associates <{RobotTask}>
	 */
	private StoredClassCatalog catalog;
	private Database store;
	private SortedMap map;

	/**
	 * Simple constructor, does nothing special
	 */
	public VisitedTaskList(Environment exampleEnv) throws Exception {
		String databaseName= "VisitedTaskList.db";

        DatabaseConfig dbConfig = new DatabaseConfig();
        dbConfig.setAllowCreate(true);
        dbConfig.setTransactional(false);

		// use Integer tuple format and binding for keys
		TupleBinding keyBinding =
			TupleBinding.getPrimitiveBinding(String.class);

		// catalog is needed for serial data format (java serialization)
		Database myClassDb = exampleEnv.openDatabase(null, "catalog.db", dbConfig);
		catalog = new StoredClassCatalog(myClassDb);

		// use String serial format and binding for values
		SerialBinding valueBinding = new SerialBinding(catalog, String.class);
		
		// open a BTREE (sorted) data store
		store = exampleEnv.openDatabase(null, databaseName, dbConfig);
		
		// create a map view of the data store
		this.map = new StoredSortedMap(store, keyBinding, valueBinding, true);
	}
	
	/** Closes the database. */
	public void close()
		throws Exception {

		if (catalog != null) {
			catalog.close();
			catalog = null;
		}
		if (store != null) {
			store.close();
			store = null;
		}
	}
	
	/**
	 * Add a task to the end of the list
	 * @param task a RobotTask object to store in the queue
	 */
	public void add(String task,String source) {
		try{
			map.put(task,source);
		}
		catch(Exception e)
		{}
	}

	/**
	 * Clean up the list, remove all objects
	 */
	public void clear() {
		map.clear();
	}


	/**
	 * Is this robot task stored in the list ?
	 */
	public boolean contains(String task) {
		String val = (String) map.get(task);
		if (val != null) {
			return true;
		}
		return false;
	}


	/**
	 * Remove this object from the list
	 */
	public boolean remove(String task) {
		String val = (String)map.remove(task);
		if (val != null) return true;
		return false;
	}

	/**
	 * Returns if is empty
	 */
	public boolean isEmpty() {
		return map.isEmpty();
	}

	public void removePrefix(String searchKey)
	{
	    Cursor cursor = null;
	    try {
	    	//	     Open the cursor.
	    	DatabaseEntry theKey =      new DatabaseEntry(searchKey.getBytes("UTF-8"));    
	    	DatabaseEntry theData =     new DatabaseEntry("".getBytes("UTF-8"));    
	    	//	     Open a cursor using a database handle    
	    	cursor = store.openCursor(null, null);    
	    	//	     Perform the search    OperationStatus 
	    	OperationStatus retVal = cursor.getSearchKeyRange(theKey, theData, LockMode.DEFAULT);    // NOTFOUND is returned if a record cannot be found whose key begins     
	    	//	     with the search key AND whose data begins with the search data.    
	    	if (retVal == OperationStatus.NOTFOUND) {
	            System.out.println(searchKey +  
	            		" not matched in database " + 
	            		store.getDatabaseName());    
	    	} else {
	            // Upon completing a search, the key and data DatabaseEntry         
	    		//	     parameters for getSearchBothRange() are populated with the         
	    		//	     key/data values of the found record.        
	    		String foundKey = new String(theKey.getData(),"UTF-8");
	    		System.out.println("Found record " + foundKey +" \n"+new String(theKey.getData(),"GBK") );  
	    		
	    		if(!foundKey.startsWith(searchKey))
    			{
    				return;
    			}
	    		cursor.delete();
	    		while (cursor.getNext(theKey, theData, LockMode.DEFAULT) ==
	                OperationStatus.SUCCESS) {
	    			foundKey = new String(theKey.getData(),"UTF-8");
	    			if(!foundKey.startsWith(searchKey))
	    			{
	    				break;
	    			}
	    			System.out.println("Found record " + foundKey +" \n"+new String(theKey.getData(),"GBK") );  
		            cursor.delete();
	    		}
	    	}
	    } catch (Exception e) {    // Exception handling goes here
	    	
	    }
	    finally {
	    	// Make sure to close the cursor   
	    	try {
				cursor.close();
			} catch (DatabaseException e) {
				e.printStackTrace();
			}
	    }
	}
	
	/*public static void main(String argv[]) throws Exception 
	{
		String dbDir = null;//"/home/logistics/db/task"; 
        String redoURL = null;//"http://www.chinawuliu.com.cn/";

        if (argv.length == 2)
        {
        	dbDir = argv[0];
        	redoURL = argv[1];
        }
        else
        {
            usage();
            System.exit(1);
        }

        System.out.println("database dir:"+dbDir);
        System.out.println("black website:"+redoURL);
        
        System.out.println("database dir:"+dbDir);
        //System.out.println("black website:"+blackURL);
        //"/home/spider/db/task"
	    EDBManager taskManager= new EDBManager(dbDir,true);

		//ToDoTaskList todo = taskManager.getTodoTask();
		//todo.removePrefix(blackURL);
	    VisitedTaskList visited = taskManager.getVisitedTaskList();
	    visited.removePrefix(redoURL);
	
	    EDBManager.close();
	}*/

	/**
	 *
	 */
    private static void usage()
    {
        System.out.println("\n\n" +
            "java com.bitmechanic.spindle.VisitedTaskList <dir> <url>\n\n");
    }

}
