package com.bitmechanic.spindle;

public class DocSummary  extends URLSummary{
	
}
