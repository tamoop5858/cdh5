package com.bitmechanic.spindle;

import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;

import java.util.ArrayList;
import java.util.Properties;

import org.htmlparser.util.ParserException;

import com.lietu.classify.Classifier;
import com.lietu.docontent.LCString;
import com.lietu.filter.ExcelReader;
import com.lietu.filter.PDFBox;
import com.lietu.filter.PowerPointReader;
import com.lietu.filter.WordReader;
import com.lietu.ie.ImageExtractor;
import com.lietu.newswalker.FileVisitor;
import com.lietu.newswalker.Filter;
import com.lietu.newswalker.NewsScanner;
import com.lietu.webCat.URLCassify;

/**
 *
 * @author luogang
 * change history:
 * add Spider(prop).
 * 
 */
public class SpiderSolr implements Runnable
{
	FingerPrintDetector fp;
	TitleDetectQ titleDetector = new TitleDetectQ();
    protected static EDBManager taskManager;
    private String dbDir = null;
    private ArrayList<Thread> threadList = null;
    private boolean verbose=false;
    private boolean incremental=false;
    
	/** current tasks */
	protected ToDoTaskList todo = null;
	
	/** a list of all URLs we got already */
	public static VisitedTaskList visited = null;

	/** a list of all URLs we got already */
	public static BadLinkList badLink = null;
	
	private static AVLTreeS mimeTypes = new AVLTreeS();
	
	public static String configFile = "mysqldb.properties";
	private static int threads = 3;
	private static int THREAD_NUM = 3;

    public static int maxLevel =100;
    
    public static int minLevel =2;
	private Classifier theClassifier = null;
	
	private String tempbody = null;
	private BufferedWriter linkWriter = null;
	
    public static void main(String argv[])  throws Exception{
    	Thread.setDefaultUncaughtExceptionHandler(
    	        new DefaultExceptionHandler());

        SpiderSolr s = new SpiderSolr(argv);
        while (true) {
			s.go();
			System.out.println("sleeping......");
			
			Thread.sleep(10 * 1000l);
		}
		//	taskManager.close();
    }

    public SpiderSolr(Properties props)  {
    	verbose= !(Integer.parseInt(props.getProperty("verbose","0"))==0);
    	dbDir = props.getProperty("dbDir");
        incremental = true;
        maxLevel =4;
        threads = Integer.parseInt(props.getProperty("threads","3"));
        
        if (dbDir == null)
            throw new IllegalArgumentException("Missing required argument: -b [database dir]");
        
        if (threads < 1)
            throw new IllegalArgumentException("Invalid number of threads: " +
                threads);
    }

    public SpiderSolr(String argv[]) throws Exception  {
    	
        for (int i = 0; i < argv.length; i++) {
            if (argv[i].equals("-b"))
            	dbDir = argv[++i];
            else if(argv[i].equals("-v"))
                verbose = true;
            else if(argv[i].equals("-a"))
            {
                incremental = true;
                maxLevel =4;
            }
            else if(argv[i].equals("-m"))
                mimeTypes.add(argv[++i]);
            else if(argv[i].equals("-t"))
            	THREAD_NUM = Integer.parseInt(argv[++i]);
            if (argv[i].equals("-c"))
            	configFile = argv[++i];
        }
        threads = THREAD_NUM;

        if (dbDir == null)
            throw new IllegalArgumentException("Missing required argument: -b [database dir]");
        
        theClassifier = new Classifier(dbDir+"/model/model.prj");
        
        if (threads < 1)
            throw new IllegalArgumentException("Invalid number of threads: " +
                threads);

    	taskManager = new EDBManager(dbDir+"/task",incremental);
		todo    = taskManager.getTodoTask();
		visited = taskManager.getVisitedTaskList();
		badLink = taskManager.getBadLink();
		
		fp = new FingerPrintDetector(dbDir+"/fingerprint");
		
		FileOutputStream fos = new FileOutputStream("./Link.txt",true);
		OutputStreamWriter osw = new OutputStreamWriter(fos,"GBK");
		linkWriter = new BufferedWriter(osw);
		linkWriter.write("\n");
		linkWriter.flush();
    }
    
    public void addInitLink() throws Exception  
    {
		StartURLs startSet = new StartURLs(configFile);
		
		NewsSource ret = startSet.getNextURL();
		while( ret!= null )
		{
			if (incremental)
			{
				// get iterator over map entries
				/*Iterator iter = badLink.map.entrySet().iterator();
				try {
					while (iter.hasNext()) {
						java.util.Map.Entry entry =  (java.util.Map.Entry)iter.next();
						//System.out.println(entry.getKey());
						badLink.map.remove(entry.getKey());
						NewsSource newitem = (NewsSource)( entry.getValue());
						todo.add(newitem);
		            	if (verbose)
		            		System.out.println("inc start page from bad link :"+newitem.URL);
					}
				} finally {
					// all database iterators must be closed!!
					StoredIterator.close(iter);
				}*/
				
				//NewsSource source = new NewsSource("http://www.chinamet.com.cn/cn/bizoppo/index.jsp","������Ϣ","cn/bizoppo");
				NewsScanner ds = new NewsScanner( ret );
				
				Filter levelFilter = new Filter(){
				    public boolean filter(NewsSource file){
				    	//System.out.println("enter filter");
				    	if( file.level<5) return true;
				    	//System.out.println("going to return false");
				    	return false;
				    	}
				    };
				    
				ds.addFilter(levelFilter);
				
				Filter expandFilter = new Filter(){
				    public boolean filter(NewsSource file){
					    	//System.out.println("enter filter");
					    	if( file.level<4 && (file.level<2 || file.changed )) return true;
					    	//System.out.println("going to return false");
					    	return false;
				    	}
				    };
				    
				ds.addExpandFilter(expandFilter);
				ds.scanUpdateChanged( new FileVisitor() {
		            public void visitFile(NewsSource newitem) {
		                //System.out.println(file);
						//enqueueURL(file);
		                if (!visited.contains(newitem.URL)) {
			            	if (verbose)
			            		System.out.println("inc start page :"+newitem.URL);
		                    todo.add(newitem);
		        			//visited.add(newitem.URL);
		                    //notifyAll();
		                }
		            }
		        });
			}
			else
			{
				System.out.println("start page :"+ret);
				enqueueURL(ret);
			}
			ret = startSet.getNextURL();
		}
		incremental = true;
	}

    public void go() throws Exception {
		//URL url8 = this.getClass().getResource( "/spider.properties" ); 
		//System.out.println(url8.toString());
    	Properties p = new Properties();
    	InputStream is=this.getClass().getResourceAsStream("/spider.properties");
    	p.load(is);
		is.close();
		String solr = p.getProperty("solr");
    	solrUrl = new URL(solr);

    	long start = System.currentTimeMillis();
    	
        if (mimeTypes.size() == 0) {
            // add default MIME types
            mimeTypes.add("text/html");
            
            mimeTypes.add("text/html;charset=iso-8859-1");
            mimeTypes.add("text/html; charset=iso-8859-1");
			mimeTypes.add("text/html; charset=US-ASCII");
            mimeTypes.add("text/html;charset=utf-8");
			mimeTypes.add("text/html;charset=UTF-8");
			mimeTypes.add("text/html; charset=utf-8");
			mimeTypes.add("text/html; charset=UTF-8");
			mimeTypes.add("text/html; Charset=utf-8");
			mimeTypes.add("text/html;charset=gb2312");
			mimeTypes.add("text/html;charset=GB2312");
			mimeTypes.add("text/html;charset=gbk");
			mimeTypes.add("text/html;charset=GBK");
			mimeTypes.add("text/html; charset=GB2312");
			mimeTypes.add("text/html; Charset=gb2312");
			mimeTypes.add("text/html; charset=gb2312");
			mimeTypes.add("text/html; charset=zh_CN.GB2312");
        }

		if(todo.size()<100)
		{
			//index page
			addInitLink();
		}
		
        // create the index directory -- or append to existing
        if (verbose) {
			System.out.println("Creating index in: " + solr);
            if (incremental) System.out.println("    - using incremental mode");
        }
        
        threadList = new ArrayList<Thread>(THREAD_NUM);

        for (int i = 0; i < THREAD_NUM; i++) {
            Thread t = new Thread(this, "Spider Thread #" + (i+1));
            t.start();
            threadList.add(t);
        }
        
        //current thread wait until child thread exit.
        while (threadList.size() > 0) {
            Thread child = (Thread)threadList.remove(0);
            child.join();
        }
        long elapsed = System.currentTimeMillis() - start;
        
        // save the index
        if (verbose) {
            System.out.println("Indexed  in "+(elapsed/3600000)+" hours. total " + (elapsed/1000) + " seconds");
			System.out.println("Optimizing index");
        }
    }
    
    public void run() {
		NewsSource item;
        try {
            while ((item = dequeueURL()) != null) {
                indexURL(item);
            }
        }
        catch(Exception e) {
            e.printStackTrace();
        }

        threads--;
    }

    public synchronized NewsSource dequeueURL() throws Exception {
        while (true) {
            if (!todo.isEmpty()) {
				NewsSource newitem = (NewsSource)todo.removeFirst();
				visited.add(newitem.URL,newitem.source);
                return newitem;
            }
            else {
                threads--;
                if (threads > 0) {
                    wait();
                    threads++;
                }
                else {
                    notifyAll();
                    return null;
                }
            }
        }
    }
    
    public synchronized void enqueueURL(NewsSource newitem) {
        if (!visited.contains(newitem.URL)) {
            todo.add(newitem);
			//visited.add(newitem.URL,newitem.source);
            notifyAll();
        }
    }

    private void indexURL(NewsSource item){
    	/*if(item.level>maxLevel)
    	{
    		System.out.println("dead loop Exception:"+item.toString());
    		return ;
    	}*/
        if (verbose) System.out.println("  " + Thread.currentThread().getName() +" level:"+item.level+ ": Adding URL: " + item.URL);
        
		URLSummary  summary = loadURL(item);
		//		System.out.println("suburl1:"+summary.suburl1+"\nsuburl2:"+summary.suburl2+"\n"+count++);
        if ( summary!= null ) {
        	if ( summary.body != null){
	            String content = summary.body.toString();
	            if (!"".equals(content) )
	            {
	            	//					System.out.println("This is the content:" + content);
	            	//					 System.out.println("tempbody:"+tempbody);
					//remove head
					String temp = doContent(content);
					
					if ((temp != null)&&!("".equals(temp))) {			
						content = temp.trim();
						//						System.out.println("This is the done content:"
						//								+ content);
					}
					// TODO:
					if ((content != null) && (!"".equals(content))) {
						if (fp.detect(summary.title, content)) {
							System.out.println("detect dup: max level -1 "
									+ maxLevel);
							if (maxLevel > minLevel) {
								maxLevel--;
							}
						} else if (maxLevel < 100) {
							maxLevel++;
						}
						if (verbose)
							System.out.println(" Adding content of URL: "
									+ item.URL);

						if (titleDetector.detect(summary.title)
								&& item.urlDesc != null) {
							// System.out.println("summary.candiateTitle:"+item.urlDesc);
							summary.title = item.urlDesc;
						}

						String catName = URLCassify.check(summary.url.toString());
						if(catName == null){
							//System.out.println("content:"+content);
							//System.out.println("theClassifier:"+theClassifier);
							catName = theClassifier.getCategoryName(content);
						}
						String Image=null;
						//if(!com.lietu.urlValid.UrlValidator.isValid(item.URL.toString()))
						if(item.URL.toString().startsWith("http"))
						{
							try {
								ImageExtractor ce = new ImageExtractor();
								//System.out.println("item.URL.toString():......"+item.URL.toString());
							    Image = ce.processURL(item.URL.toString(),null);
							    System.out.println("Image:......"+Image);
							}
							catch (Exception e) {		
								System.out.println("The requested URL was not found on this server.");
							}
						}
						if (catName != null) {
							try {
								
								// System.out.println("item.rank:"+item.rank);
								StringBuilder xmlContent = new StringBuilder();
								xmlContent.append("<add>");
								xmlContent.append("<doc>");
								XML.writeXML(xmlContent, "field", item.URL
										.toLowerCase(), "name", "id");
								XML.writeXML(xmlContent, "field", item.URL, "name",
										"url");
								XML.writeXML(xmlContent, "field", item.source,
										"name", "source");
								XML.writeXML(xmlContent, "field", catName, "name",
										"cat");
								XML.writeXML(xmlContent, "field", summary.title,
										"name", "title");
								XML.writeXML(xmlContent, "field", content, "name",
										"body");
								XML.writeXML(xmlContent, "field", String
										.valueOf(item.rank), "name", "rank");
								XML.writeXML(xmlContent, "field", summary.url.getHost().toLowerCase(),
										"name",	"site");
							
								XML.writeXML(xmlContent, "field", Image,
										"name",	"img");//neeeded add
								
								xmlContent.append("</doc>");
								xmlContent.append("</add>");
								StringWriter sw = new StringWriter();
								postData(new StringReader(xmlContent.toString()),
										sw);
							} catch (Exception e) {
								e.printStackTrace(System.out);
							}
						}
						else
						{
							if(maxLevel>minLevel)
		            		{
		            			maxLevel-=2;
		            		}
						}
					}
	            }
	            else
	            {
            		System.out.println("content is null: max level -1 " + maxLevel);
            		if(maxLevel>minLevel)
            		{
            			maxLevel--;
            		}
	            }
        	}
            
            int newLevel = item.level+1;
            try {
	            for (int i = 0; i < summary.outURLs.size(); i++) {
	            	// System.out.println("adding
					// link"+(String)summary.outURLs.get(i));
	            	
					linkWriter.write(summary.url.toString().toLowerCase());
					String outLink = summary.outURLs.get(i);
					linkWriter.write(" -> ");
					linkWriter.write(outLink.toLowerCase());
					String linkDesc = summary.URLsDesc.get(i);
					
					int weight = 1;
					if(linkDesc!=null && linkDesc.length()>7)
					{
						weight =  2 ;
					}
					linkWriter.write(" ");
					linkWriter.write(String.valueOf(weight));
					linkWriter.write("\n");
	                enqueueURL(new NewsSource
	                		(outLink,
	                				item.source,
									item.include,
									newLevel,
									linkDesc,item.rank));
	            }
            } catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
    }
    
    static URL solrUrl = null;
    public static final String POST_ENCODING = "UTF-8";
    /**
     * Reads data from the data reader and posts it to solr,
     * writes to the response to output
     * @throws Exception 
     */
    public void postData(Reader data, Writer output) throws Exception {
      HttpURLConnection urlc = null;
      try {
    	  System.out.println("solrUrl:"+solrUrl);
    	 
        urlc = (HttpURLConnection) solrUrl.openConnection();
        
        try {
          urlc.setRequestMethod("POST");
        } catch (ProtocolException e) {
          throw new Exception("Shouldn't happen: HttpURLConnection doesn't support POST??", e);
        }
        urlc.setDoOutput(true);
        urlc.setDoInput(true);
        urlc.setUseCaches(false);
        urlc.setAllowUserInteraction(false);
        urlc.setRequestProperty("Content-type", "text/xml; charset=" + POST_ENCODING);
        
       
        
        OutputStream out = urlc.getOutputStream();
        
        System.out.println("urlc:"+urlc);
        try {
          Writer writer = new OutputStreamWriter(out, POST_ENCODING);
          pipe(data, writer);
          writer.close();
        } catch (IOException e) {
          throw new Exception("IOException while posting data", e);
        } finally {
          if(out!=null) out.close();
        }
        
        InputStream in = urlc.getInputStream();
        try {
          Reader reader = new InputStreamReader(in);
          pipe(reader, output);
          reader.close();
        } catch (IOException e) {
          throw new Exception("IOException while reading response", e);
        } finally {
          if(in!=null) in.close();
        }
        
      } catch (IOException e) {
    	  throw new Exception("Connection error (is Solr running at " + solrUrl + " ?): " + e);
      } finally {
        //if(urlc!=null)
        	urlc.disconnect();
      }
    }

    /**
     * Pipes everything from the reader to the writer via a buffer
     */
    private static void pipe(Reader reader, Writer writer) throws IOException {
      char[] buf = new char[1024];
      int read = 0;
      while ( (read = reader.read(buf) ) >= 0) {
        writer.write(buf, 0, read);
      }
      writer.flush();
    }
    
    private URLSummary loadURL(NewsSource item) {
		HttpURLConnection uc = null;
		
		// timeout value in milliseconds
		HttpTimeoutHandler xHTH = new HttpTimeoutHandler(600000);
		//System.out.println("url:"+item.URL);
		URL theURL = null;
		try{
			theURL = new URL((URL)null, item.URL.replaceAll(" ","%20"), xHTH);
		}
		catch(Exception e)
		{
			e.printStackTrace(System.out);
			return null;
		}

		// Execute the method.
		int statusCode = -1;
		
		// We will retry up to 3 times.
		for (int attempt = 0;statusCode == -1 && attempt < 3; attempt++)
		{
		  try {
			// execute the method.
			//System.out.println("will open connetion");
		  	uc = (HttpURLConnection) theURL.openConnection();
			//System.out.println("close connetion");
			statusCode = 1;
			
			if(uc == null)
			{
				return null;
			}
			String ct = uc.getContentType();
			
			if (ct == null)
			{
				System.out.println("mimeTypes not found is null " +item.URL );
				if(uc!=null)
				{
					uc.disconnect();
				}
				return null;
			}
			if (mimeTypes.find(ct)) {
				if(item.URL.endsWith(".rar"))
				{
					return null;
				}
				URLSummary urlBody = null;
				
				if(item.source == null)
				{
					System.out.println("item.source cannot be null");
					System.exit(-1);
				}
				
				try{
					urlBody = new URLSummary();
				}
				catch (Exception e)
				{
					e.printStackTrace(System.out);
					maxLevel--;
					return null;
				}
				
				urlBody.url = new URL(item.URL);
				//urlBody.accessDate = new Date();
				
				try
				{
					if (item.level<maxLevel)
					{
						urlBody.parseHTML(uc ,item.include, true,ct);
					}
					else
					{
						System.out.println("dead loop Exception:"+item.toString());
						urlBody.parseHTML(uc,item.include, false,ct);
					}
				}
				catch (ParserException pe)
				{
					pe.printStackTrace(System.out);
		            //add to bad link list
		            SpiderSolr.badLink.add(item);
		            return null;
				}
				
				// always release the connection after we're done 
				uc.disconnect();

	            return urlBody;
	        }
			else if("application/pdf".equals(ct)){
				String outStr=null;
				try {
					outStr=PDFBox.getText(uc.getInputStream());
				} catch (Exception e) {
					e.printStackTrace();
					if (uc != null)
					{
						uc.disconnect();						
					}
					return null;
				}
				
				DocSummary urlBody = new DocSummary();
				
				urlBody.url = new URL(item.URL);
				urlBody.body = new StringBuffer(outStr);
				urlBody.title=PDFBox.getTitle(outStr);
				
				uc.disconnect();
				
				return(urlBody);
			}
			else if("application/msword".equals(ct)){
				String outStr=null;
				try {
					outStr=WordReader.readDoc(uc.getInputStream());
				} catch (Exception e) {
					e.printStackTrace();
					if (uc != null)
					{
						uc.disconnect();						
					}
					return null;
				}
				
				DocSummary urlBody = new DocSummary();
				
				urlBody.url = new URL(item.URL);
				urlBody.body = new StringBuffer(outStr);
				urlBody.title=WordReader.getTitle(outStr);
				
				uc.disconnect();
				
				return(urlBody);
			}
			else if("application/vnd.ms-powerpoint".equals(ct)){
				String outStr=null;
				try {
					outStr=PowerPointReader.readDoc(uc.getInputStream());
				} catch (Exception e) {
					e.printStackTrace();
					if (uc != null)
					{
						uc.disconnect();						
					}
					return null;
				}
				
				DocSummary urlBody = new DocSummary();
				
				urlBody.url = new URL(item.URL);
				urlBody.body = new StringBuffer(outStr);
				urlBody.title=PowerPointReader.getTitle(outStr);
				
				uc.disconnect();
				
				return(urlBody);
			}
			else if("application/vnd.ms-excel".equals(ct)){
				String outStr=null;
				try {
					outStr=ExcelReader.readDoc(uc.getInputStream());
				} catch (Exception e) {
					e.printStackTrace();
					if (uc != null)
					{
						uc.disconnect();						
					}
					return null;
				}
				
				DocSummary urlBody = new DocSummary();
				
				urlBody.url = new URL(item.URL);
				urlBody.body = new StringBuffer(outStr);
				urlBody.title=ExcelReader.getTitle(outStr);
				
				uc.disconnect();
				
				return(urlBody);
			}
			else if ("text/plain".equals(ct))
			{
				if(item.URL.endsWith(".rar"))
				{
					return null;
				}
				URLSummary urlBody = new DocSummary();
				urlBody.url = new URL(item.URL);
				//urlBody.accessDate = new Date();
				BufferedReader br = new BufferedReader( new InputStreamReader( uc.getInputStream() ) );
			    String s = null;
			    
			    if ( (s = br.readLine()) != null )
			    {
			    	urlBody.title = s;
					while( (s = br.readLine()) != null ) {
				        //System.out.println(s);
				        urlBody.body.append(s);
					}
			    }
			    
			    uc.disconnect();

	            return urlBody;
			}
	        else {
				System.out.println("mimeTypes not found "+ct );
				
				// always release the connection after we're done 
				uc.disconnect();
	            return null;
	        }
			
		  } catch (IOException e) {
		  	e.printStackTrace(System.out);

            //add to bad link list
            SpiderSolr.badLink.add(item);
		  	return null;
		  }
		  finally
		  {
			  if(uc!= null)
			  {
				  uc.disconnect();
				  uc = null;
			  }
		  }
		}
		
		// Check that we didn't run out of retries.
		if (statusCode == -1) {
		  System.out.println("Failed to recover from exception.");		  
		}
		return null;
    }
    
    public String doContent(String body){
    	ArrayList<String>  com = null;
		String temp = body;
		if ((tempbody == null) && (body != null)) {
			tempbody = body;
			return null;
		}
		if ((tempbody != null) && (body != null)) {
			com = LCString.removeContent(tempbody, body);
		}
		if(com!=null){
			for(int i = 0;i<com.size();i++){
				if(body.contains(com.get(i))){
					//					System.out.println("com"+i+":"+com[i]);
					body = body.replace(com.get(i), "");
				}
			}
		}

		if (!tempbody.equals(temp)) {
			tempbody = temp;
		}
		// System.out.println("comhead:"+comhead);
		// System.out.println("comtail:"+comtail);
		return body;
	}
}
