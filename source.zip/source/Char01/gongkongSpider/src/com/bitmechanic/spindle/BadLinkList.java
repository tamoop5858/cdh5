/*
 * Created on 2005-7-31
 *
 */
package com.bitmechanic.spindle;

import com.sleepycat.je.Database;
import com.sleepycat.je.DatabaseConfig;
import com.sleepycat.je.Environment;
import com.sleepycat.bind.serial.StoredClassCatalog;
import com.sleepycat.bind.serial.SerialBinding;
import com.sleepycat.bind.tuple.TupleBinding;
//import com.sleepycat.collections.MapEntry;
import com.sleepycat.collections.StoredSortedMap;
import com.sleepycat.collections.StoredIterator;

import java.util.SortedMap;
import java.util.Iterator;

/**
 * @author Administrator
 *
 */
public class BadLinkList {

	/** 
	 * Bad Link store 
	 *
	 * @link aggregation
	 * @associates <{RobotTask}>
	 */
	private StoredClassCatalog catalog;
	private Database store;
	public SortedMap map;

	/**
	 * Simple constructor, does nothing special
	 */

	public BadLinkList(Environment exampleEnv) throws Exception {
		String databaseName= "BadLinkList.db";

        DatabaseConfig dbConfig = new DatabaseConfig();
        dbConfig.setAllowCreate(true);
        dbConfig.setTransactional(false);

		// use Integer tuple format and binding for keys
		TupleBinding keyBinding =
			TupleBinding.getPrimitiveBinding(String.class);

		// catalog is needed for serial data format (java serialization)
		Database myClassDb = exampleEnv.openDatabase(null, "meta.db", dbConfig);
		catalog = new StoredClassCatalog(myClassDb);

		// use String serial format and binding for values
		SerialBinding valueBinding = new SerialBinding(catalog, NewsSource.class);
		
		// open a BTREE (sorted) data store
		store = exampleEnv.openDatabase(null, databaseName, dbConfig);
		
		// create a map view of the data store
		this.map = new StoredSortedMap(store, keyBinding, valueBinding, true);
		//System.out.println(this.map.size());
	}

	/** Closes the database. */
	public void close()
		throws Exception {

		if (catalog != null) {
			catalog.close();
			catalog = null;
		}
		if (store != null) {
			store.close();
			store = null;
		}
	}
	
	/**
	 * Add a task to the end of the list
	 * @param task a RobotTask object to store in the queue
	 */
	public void add(NewsSource task) {
		map.put(task.URL,task);
	}

	/**
	 * Clean up the list, remove all objects
	 */
	public void clear() {
		map.clear();
	}

	/**
	 * Is this robot task stored in the list ?
	 */
	public boolean contains(String task) {
		NewsSource val = (NewsSource) map.get(task);
		if (val != null) {
			return true;
		}
		return false;
	}


	/**
	 * Remove this object from the list
	 */
	public boolean remove(String task) {
		String val = (String)map.remove(task);
		if (val != null) return true;
		return false;
	}

	/**
	 * Returns if is empty
	 */
	public boolean isEmpty() {
		return map.isEmpty();
	}
	
	public void print() {
		// get iterator over map entries
		Iterator iter = map.entrySet().iterator();
		try {
			System.out.println("print data");
			while (iter.hasNext()) {
				java.util.Map.Entry entry =  (java.util.Map.Entry)iter.next();
				System.out.println(entry.getKey());
			}
		} finally {
			// all database iterators must be closed!!
			StoredIterator.close(iter);
		}
	}
}
