/*
 * Created on 2004-6-8
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author Administrator
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.bitmechanic.spindle;
import java.net.*;

public class HttpTimeoutFactory implements URLStreamHandlerFactory
{
	int fiTimeoutVal;
	public HttpTimeoutFactory(int iT) { fiTimeoutVal = iT; }
	public URLStreamHandler createURLStreamHandler(String str)
	{
		return new HttpTimeoutHandler(fiTimeoutVal); 
	}
	
}

