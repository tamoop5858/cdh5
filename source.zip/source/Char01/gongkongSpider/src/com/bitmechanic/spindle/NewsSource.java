/*
 * Created on 2004-5-17
 *
 */
package com.bitmechanic.spindle;

/**
 * @author luogang
 *
 */
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.TreeMap;

import org.htmlparser.Node;
import org.htmlparser.PrototypicalNodeFactory;
import org.htmlparser.lexer.Lexer;
import org.htmlparser.lexer.Page;
import org.htmlparser.lexer.nodes.StringNode;
import org.htmlparser.tags.LinkTag;
import org.htmlparser.util.ParserException;

public class NewsSource implements Serializable {
	private static final long serialVersionUID = 920074523009105063L;
	
	public String URL;
	public String source;
	public String include;
	public int level;
	public int rank;
	//add
	public boolean changed;
	public String urlDesc = null;

	public NewsSource(String URL,String source){
		this.URL = URL;
		this.source = source;
		this.level = 1;
	}
	
	public boolean equals(Object that){
		NewsSource thatNews = (NewsSource)that;
		if(thatNews.URL.equals(this.URL))
		{
			return true;
		}
		return false;
	}
	
	public NewsSource(String URL,String source,String include,int rank){
		this.URL = URL;
		this.source = source;
		this.include = include;
		this.level = 1;
		this.rank = rank;
	}

	public NewsSource(String URL,String source,String include,int level,String urlDesc,int rank){
		this.URL = URL;
		this.source = source;
		this.include = include;
		this.level = level;
		this.urlDesc = urlDesc;	
		this.rank = rank;
	}
	
	public NewsSource[] expandUpdateChanged()
	{
		List out = new ArrayList();
		LinkTag linkTag;		
        try
        {
    		HttpTimeoutHandler xHTH = new HttpTimeoutHandler(500000);	// timeout value in milliseconds
    		URL theURL = new URL((URL)null, this.URL, xHTH);

    		HttpURLConnection uc = (HttpURLConnection) theURL.openConnection();
			String ct = uc.getContentType();
			
			Lexer lexer = new Lexer (new Page(uc.getInputStream(), Page.getCharset (ct)));
			
        	lexer.setNodeFactory(new PrototypicalNodeFactory ());
        	ArrayList<String> list = new ArrayList<String>();
        	
            Node node;
            
			while (null != (node = lexer.nextNode ()))
			{
				if (node instanceof LinkTag)
				{
	            	linkTag = (LinkTag)node;
	            	String href = linkTag.getAttribute ("HREF");
	            	if(href!=null)
	            		list.add(href);
				}
			}
			
            for (int i = 0; i < list.size (); i++)
            {
            	String newURL  = list.get (i);
				
    			if (newURL.startsWith("http://") || 
    				(newURL.startsWith("https://") ))
    			{
    				// verify we're on the same host and port
    				URL u = new URL(newURL);
    				if (((include == null) || (newURL.indexOf(include)>=0) ) &&
    						u.getHost().equals(theURL.getHost()) &&
							u.getPort() == theURL.getPort())
    				{
				        if (!SpiderSolr.visited.contains(newURL)) {
				        	changed = true;
				        }
    					out.add(new NewsSource(newURL,source,include,this.level+1,null,this.rank));
    				}
    			}
    			else if (newURL.indexOf("://") == -1 &&
    					 !newURL.startsWith("mailto:") &&
    					 !newURL.startsWith("#") &&
    					 !newURL.startsWith("javascript:") &&
    					 !newURL.startsWith("vbscript:"))
    			{
    				// parse relative url
    				URL u = new URL(theURL,newURL);
    				newURL = u.toString();
    				
    				if (( (include == null) || (newURL.indexOf(include)>=0) )
    						&& (newURL.indexOf("../")<0) )
    				{
				       /* if (!Spider.visited.contains(newURL)) {
				        	changed = true;
				        }*/
    					out.add(new NewsSource(newURL,source,include,this.level+1,null,this.rank));
    				}
    			}
            }
        }
        catch (java.net.UnknownHostException e)
        {
        	try
        	{
				Properties properties = new Properties();
				InputStream is = this.getClass().getResourceAsStream("/"+SpiderSolr.configFile);
				properties.load(is);
				is.close();
				String driver = properties.getProperty("driver");
				//System.out.println(driver);
				String dburl = properties.getProperty("dburl");
				//System.out.println(dburl);
				String user = properties.getProperty("user");
				//System.out.println(user);
				String password = properties.getProperty("password");
				//System.out.println(password);
				Driver drv = (Driver)Class.forName(driver).newInstance();
				DriverManager.registerDriver(drv);
				Connection con = DriverManager.getConnection(dburl,user,password);
				String sql = "update spider set valid=0 where url like '%"+this.URL+"%'";
				System.out.println(sql);
				Statement stmt = con.createStatement();
				stmt.executeUpdate(sql);
				con.close();
				return null;
        	}catch(Exception e2)
        	{
        		return null;
        	}
        }
        catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (java.io.FileNotFoundException e) {
        	try
        	{
				Properties properties = new Properties();
				InputStream is = this.getClass().getResourceAsStream("/"+SpiderSolr.configFile);
				properties.load(is);
				is.close();
				String driver = properties.getProperty("driver");
				//System.out.println(driver);
				String dburl = properties.getProperty("dburl");
				//System.out.println(dburl);
				String user = properties.getProperty("user");
				//System.out.println(user);
				String password = properties.getProperty("password");
				//System.out.println(password);
				Driver drv = (Driver)Class.forName(driver).newInstance();
				DriverManager.registerDriver(drv);
				Connection con = DriverManager.getConnection(dburl,user,password);
				String sql = "update spider set valid=0 where url like '%"+this.URL+"%'";
				System.out.println(sql);
				Statement stmt = con.createStatement();
				stmt.executeUpdate(sql);
				con.close();
				return null;
        	}catch(Exception e2)
        	{
        		return null;
        	}
		} catch (java.io.IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (ParserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
        NewsSource[] resultsArray = new NewsSource[out.size()];
        out.toArray(resultsArray);
        return resultsArray;
	}
	
	public NewsSource[] expand()
	{
		List out = new ArrayList();
		LinkTag linkTag;
		
        try
        {
    		HttpTimeoutHandler xHTH = new HttpTimeoutHandler(500000);	// timeout value in milliseconds
    		URL theURL = new URL((URL)null, this.URL, xHTH);

    		HttpURLConnection uc = (HttpURLConnection) theURL.openConnection();
			String ct = uc.getContentType();
			Lexer lexer = new Lexer (new Page(uc.getInputStream(), Page.getCharset (ct)));
			
        	lexer.setNodeFactory(new PrototypicalNodeFactory ());
        	ArrayList list = new ArrayList();
        	
            Node node;
            
			while (null != (node = lexer.nextNode ()))
			{
				if (node instanceof LinkTag)
				{
	            	linkTag = (LinkTag)node;
	            	list.add(linkTag.getAttribute ("HREF")) ;
				}
			}
			
            for (int i = 0; i < list.size (); i++)
            {
            	String newURL  = (String)list.get (i);
				
    			if (newURL.startsWith("http://") || 
    				(newURL.startsWith("https://") ))
    			{
    				// verify we're on the same host and port
    				URL u = new URL(newURL);
    				if (((include == null) || (newURL.indexOf(include)>=0) ) &&
    						u.getHost().equals(theURL.getHost()) &&
							u.getPort() == theURL.getPort())
    				{
    					out.add(new NewsSource(newURL,source,include,this.level+1,null,this.rank));
    				}
    			}
    			else if (newURL.indexOf("://") == -1 &&
    					 !newURL.startsWith("mailto:") &&
    					 !newURL.startsWith("#") &&
    					 !newURL.startsWith("javascript:") &&
    					 !newURL.startsWith("vbscript:"))
    			{
    				// parse relative url
    				URL u = new URL(theURL,newURL);
    				newURL = u.toString();
    				
    				if (( (include == null) || (newURL.indexOf(include)>=0) )
    						&& (newURL.indexOf("../")<0) )
    				{
    					out.add(new NewsSource(newURL,source,include,this.level+1,null,this.rank));
    				}
    			}
            }
        }
        catch (Exception e)
        {
            e.printStackTrace ();
            //add to bad link list
            SpiderSolr.badLink.add(this);
        }
        NewsSource[] resultsArray = new NewsSource[out.size()];
        out.toArray(resultsArray);
        return resultsArray;
	}
	
	public final String getURL() {

		return URL;
	}

	public final String getSource() {

		return source;
	}

	public final String getInclude() {

		return include;
	}
	
	public String getPageLinkMode()
	{
		TreeMap<Integer,String> pageLink = new TreeMap<Integer,String>();
		LinkTag linkTag;
        try
        {
    		HttpTimeoutHandler xHTH = new HttpTimeoutHandler(1000000);	// timeout value in milliseconds
    		URL theURL = new URL((URL)null, this.URL, xHTH);

    		HttpURLConnection uc = (HttpURLConnection) theURL.openConnection();
			String ct = uc.getContentType();
			Lexer lexer = new Lexer (new Page(uc.getInputStream(), Page.getCharset (ct)));
			
        	lexer.setNodeFactory(new PrototypicalNodeFactory ());
        	ArrayList list = new ArrayList();
        	
            Node node;
            
			while (null != (node = lexer.nextNode ()))
			{
				if (node instanceof LinkTag)
				{
	            	linkTag = (LinkTag)node;
	            	String link = linkTag.getAttribute ("HREF");
	            	list.add(link) ;
	            	node = lexer.nextNode ();
	            	if (node instanceof StringNode)
	            	{
	            		String pageText = node.getText();
	            		if("��һҳ".equals(pageText))
	            		{
	            			pageLink.put(new Integer(2),link);
	            		}
	            		else
	            		{
		            		int pageNo = -1;
		            		try
		            		{
		            			pageNo = Integer.parseInt(pageText);
		            			pageLink.put(new Integer(pageNo),link);
		            		}
		            		catch(NumberFormatException e)
		            		{
		            			
		            		}
	            		}
	            		//if ()
	            		//System.out.println(node);
	            	}
				}
			}
			
        }
        catch (Exception e)
        {
            e.printStackTrace ();
        }
        
        String candiateFormat = null;
        for(Integer e : pageLink.keySet())
        {
        	String pageHref = pageLink.get(e);
        	if(pageHref.indexOf(e.toString())>0)
        	{
        		if (candiateFormat== null)
        		{
        			candiateFormat = pageHref.replaceFirst(e.toString(), "%d");
        			//System.out.println("candiateFormat:"+candiateFormat);
        		}
        		else
        		{
        			if(pageHref .equals(String.format(candiateFormat, e.intValue())))
        			{
        				//System.out.println("ok");

        				return candiateFormat;
        			}
        		}
        	}
        }

		return candiateFormat;
	}


	public String getDetailLinkMode()
	{
		ArrayList<String> pageLink = new ArrayList<String>();
		LinkTag linkTag;
        try
        {
    		HttpTimeoutHandler xHTH = new HttpTimeoutHandler(1000000);	// timeout value in milliseconds
    		URL theURL = new URL((URL)null, this.URL, xHTH);

    		HttpURLConnection uc = (HttpURLConnection) theURL.openConnection();
			String ct = uc.getContentType();
			Lexer lexer = new Lexer (new Page(uc.getInputStream(), Page.getCharset (ct)));
			
        	lexer.setNodeFactory(new PrototypicalNodeFactory ());
        	
            Node node;
            
			while (null != (node = lexer.nextNode ()))
			{
				if (node instanceof LinkTag)
				{
	            	linkTag = (LinkTag)node;
	            	String link = linkTag.getAttribute ("HREF");

	            	node = lexer.nextNode ();
	            	if (node instanceof StringNode)
	            	{
	            		String pageText = node.getText();
	            		if(pageText.length()<=4)
	            		{
	            			continue;
	            		}
	            	}
	            	
	            	int p =link.length() -1;
	            	//System.out.println("link.charAt(p)"+link.charAt(p));
	            	while(link.charAt(p)>='0' && link.charAt(p)<='9')
	            	{
	            		p--;
	            	}
	            	link = link.substring(0,p+1);
	            	//System.out.println("link:"+link);
	            	pageLink.add(link);
				}
			}
			
        }
        catch (Exception e)
        {
            e.printStackTrace ();
        }
        String[] sortedLink = pageLink.toArray(new String[pageLink.size()] );
        java.util.Arrays.sort(sortedLink);
        String last = null;
        
        String commonprefix = null;
        int maxCount=0;
        int curCount=0;
        String lastLCP = null;
        for(int i=0;i<sortedLink.length;++i)
        {
        	if(last != null)
        	{
        		String temp = lcp(sortedLink[i],last);
        		if(!"".equals(temp))
        		{
        			//System.out.println("lcp:"+temp);
        			if(commonprefix == null)
        			{
        				commonprefix = temp;
        				maxCount = 1;
        				curCount = 1;
        			}
        			if(temp.equals(lastLCP))
        			{
        				curCount ++;
        			}
        			else
        			{
        				curCount = 1;
        			}
        			if(curCount>maxCount)
        			{
        				//System.out.println("maxCount:"+maxCount);
        				commonprefix = temp;
        				maxCount = curCount;
        			}

            		lastLCP = temp;
        		}
        	}
        	last = sortedLink[i];
        }

        if(commonprefix != null)
        {
        	int p = commonprefix.indexOf("2007");
        	if(p<0)
        	{
        		p = commonprefix.indexOf("2008");
        	}
        	if(p>=0)
        	{
        		commonprefix = commonprefix.substring(0,p+3);
        	}
        }
		return commonprefix;
	}
	
	public int getTotalPageNum()
	{
		int pageNum = -1;
        try
        {
    		HttpTimeoutHandler xHTH = new HttpTimeoutHandler(500000);	// timeout value in milliseconds
    		URL theURL = new URL((URL)null, this.URL, xHTH);

    		HttpURLConnection uc = (HttpURLConnection) theURL.openConnection();
			String ct = uc.getContentType();
			Lexer lexer = new Lexer (new Page(uc.getInputStream(), Page.getCharset (ct)));
			
        	lexer.setNodeFactory(new PrototypicalNodeFactory ());
        	
            Node node;
            boolean havePageNum = false;
			while (null != (node = lexer.nextNode ()))
			{
				if (node instanceof StringNode)
				{
					String pageText = node.getText();
					//System.out.println("page num:"+pageText);
	            	if("ҳ�Σ�".equals(pageText.trim()))
	            	{
	            		havePageNum = true;
	            	}
	            	else if(havePageNum && pageText.startsWith("/"))
	            	{
	            		int end = pageText.length() ;
	            		if(pageText.endsWith("ҳ"))
	            		{
	            			end --;
	            		}
	            		System.out.println("page num:"+pageText.substring(1,end));
	            		pageNum = Integer.parseInt(pageText.substring(1,end));
            			return pageNum;
	            	}
				}
			}
			
        }
        catch (Exception e)
        {
            e.printStackTrace ();
        }
        
		return pageNum;
	}
	
	public String toString(){
		return "URL :"+URL+" source :" + source +"include :"+include;
	}

    /**
       Returns the longest common prefix of the 
       strings <code>s</code> and <code>t</code>.
       @param s a string
       @param t a string
       @return the longest common prefix of the 
       strings <code>s</code> and <code>t</code>.
    */
    public static String lcp(String s, String t){
    	int i = 0;
		if(s == null) return t;
		if(t == null) return s;
		while(i < s.length() && i < t.length() 
		      && s.charAt(i) == t.charAt(i))
		    i++;
		if(i == 0)
		    return "";
		else
		{
			String lcp = s.substring(0,i);
			int p =lcp.length() -1;
        	//System.out.println("link.charAt(p)"+link.charAt(p));
        	while(lcp.charAt(p)>='0' && lcp.charAt(p)<='9')
        	{
        		p--;
        	}
        	lcp = lcp.substring(0,p+1);
        	return lcp;
		    //return s.substring(0,i);
		}
    }

    /*public static void main (String[] args) throws Exception
    {
    	//http://cn.test1.chinamet.com/cn/proshow/pro_detail.jsp?productid=14122&companyid=10578&companycname=����̫����ҵ���޹�˾
    	//http://www.chinamet.com.cn/cn/bizoppo/index.jsp
    	String url = "http://www.56cn.cn/ShowClass.asp?nclassid=3&nboardid=0&page=61000";
    		//"http://sssddffff.com";
    		//"http://www.chinamet.com.cn/cn/bizoppo/index.jsp";
    	NewsSource source = new NewsSource(url,"������Ϣ",null);
    	NewsSource[] out = source.expand();
    	
    	for(int i=0;i<out.length;i++)
    	{
    		System.out.println((NewsSource)out[i]);
    	}
    	
    	//
    	//
    	//"http://www.gongkong.com/product/include_list/new_4_1.htm"
    	
    	//
    	//http://www.56cn.cn/ShowClass.asp?nClassID=3&nBoardID=0
    	//http://www.vertinfo.com/archionline/indexinfo.asp
    	//http://www.gkong.com/news/News_more.asp?news_class=001
    	NewsSource source = new NewsSource("http://www.gkong.com/news/News_more.asp?news_class=001","������Ϣ","",0);
    	String pageFormat = source.getPageLinkMode();
    	System.out.println(String.format(pageFormat, 8));
    	System.out.println(source.getTotalPageNum());
    	String detail = source.getDetailLinkMode();
    	System.out.println("detail:"+detail);
    	//System.out.println(source.lcp("newsdetail.asp?id=", "newsdetail.asp?id="));
    }*/
}
