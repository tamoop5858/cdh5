/*
 * Created on 2004-4-29
 *
 * ToDo task database implement
 */
package com.bitmechanic.spindle;

import com.sleepycat.je.Cursor;
import com.sleepycat.je.Database;
import com.sleepycat.je.DatabaseConfig;
import com.sleepycat.je.DatabaseEntry;
import com.sleepycat.je.DatabaseException;
import com.sleepycat.je.Environment;
import com.sleepycat.je.LockMode;
import com.sleepycat.je.OperationStatus;
import com.sleepycat.bind.serial.StoredClassCatalog;
import com.sleepycat.bind.serial.SerialBinding;
import com.sleepycat.bind.tuple.TupleBinding;
import com.sleepycat.collections.StoredSortedMap;

import java.util.SortedMap;

/**
 * @author luogang
 *
 * use berceley db as url link store
 */
public class ToDoTaskList {

	/** 
	 * Task store 
	 *
	 * @link aggregation
	 * @associates <{RobotTask}>
	 */
	private Database store;
	private SortedMap map;
	private StoredClassCatalog catalog;
	
	public ToDoTaskList(Environment exampleEnv) throws Exception {
		String databaseName= "ToDoTaskList.db";
        DatabaseConfig dbConfig = new DatabaseConfig();
        dbConfig.setAllowCreate(true);
        dbConfig.setTransactional(false);
        
        // Open the database that you use to store your class information.
        // The db used to store class information does not require duplicates
        // support.
        dbConfig.setSortedDuplicates(false);
        Database myClassDb = exampleEnv.openDatabase(null, "classDb", dbConfig); 

        // Instantiate the class catalog
        catalog = new StoredClassCatalog(myClassDb);

		TupleBinding keyBinding =
			TupleBinding.getPrimitiveBinding(String.class);

		// use String serial format and binding for values
		SerialBinding valueBinding = new SerialBinding(catalog, NewsSource.class);

        store = exampleEnv.openDatabase(null, databaseName, dbConfig);
        
		// create a map view of the data store
		this.map = new StoredSortedMap(store, keyBinding, valueBinding, true);
	}

	/** Closes the database. */
	public void close()
		throws Exception {
        if (catalog != null) {
            catalog.close();
            catalog = null;
        }
		if (store != null) {
			store.close();
			store = null;
		}
	}

	/**
	 * Add a task to the end of the list
	 * @param task a RobotTask object to store in the queue
	 */
	public void add(NewsSource task) {
		map.put(task.URL,task);
	}

	/**
	 * Clean up the list, remove all objects
	 */
	public void clear() {
	    try{
	    	store.truncate(null,false);
	    } catch(Exception e){
	    	System.err.println("database clear error:"+e.toString());
	    }
	}

	/**
	 * Is this robot task stored in the list ?
	 */
	public boolean contains(String task) {
		  String val = (String) map.get(task);
		  if (val != null) {
				return true;
		  }
		  return false;
	}
  
	/**
	 * Get and remove the first element.
	 * @return the first task in the list. This object will also be removed
	 * from the list.
	 * @exception ArrayIndexOutOfBoundsException if the list is empty
	 */
	public NewsSource removeFirst()
	{
	  String url = (String)map.firstKey();
	  if (url != null){
		NewsSource source = (NewsSource)map.get(url);
		map.remove(url);
		return source;

	  }
	  return null;
	}

	/**
	 * Returns if is empty
	 */
	public boolean isEmpty() {
	  return map.isEmpty();
	}
	
	public int size ()
	{
		int size = 0;
		//		 Open the cursor.
		Cursor cursor = null;
		
		try {
			cursor = store.openCursor(null, null);

			//		 Cursors need a pair of DatabaseEntry objects to operate. These hold
			//		 the key and data found at any given position in the database.
			DatabaseEntry foundKey = new DatabaseEntry();
			DatabaseEntry foundData = new DatabaseEntry();
			//		 To iterate, just call getNext() until the last database record has been
			//		 read. All cursor operations return an OperationStatus, so just read
			//		 until we no longer see OperationStatus.SUCCESS
			while (cursor.getNext(foundKey, foundData, LockMode.DEFAULT) ==
			OperationStatus.SUCCESS) {
				//		 getData() on the DatabaseEntry objects returns the byte array
				//		 held by that object. We use this to get a String value. If the
				//		 DatabaseEntry held a byte array representation of some other data
				//		 type (such as a complex object) then this operation would look
				//		 considerably different.
				size ++;
			}
		} catch (DatabaseException e) {
			e.printStackTrace();
		}finally {
			//			 Cursors must be closed.
			try {
				if (cursor!=null)
					cursor.close();
			} catch (DatabaseException e) {
				
				e.printStackTrace();
			}
		}
		
		return size;
	}
	
	public void removePrefix(String searchKey)
	{
	    Cursor cursor = null;
	    try {
	    	//	     Open the cursor.
	    	DatabaseEntry theKey =      new DatabaseEntry(searchKey.getBytes("UTF-8"));    
	    	DatabaseEntry theData =     new DatabaseEntry("".getBytes("UTF-8"));    
	    	//	     Open a cursor using a database handle    
	    	cursor = store.openCursor(null, null);    
	    	//	     Perform the search    OperationStatus 
	    	OperationStatus retVal = cursor.getSearchKeyRange(theKey, theData, LockMode.DEFAULT);    // NOTFOUND is returned if a record cannot be found whose key begins     
	    	//	     with the search key AND whose data begins with the search data.    
	    	if (retVal == OperationStatus.NOTFOUND) {
	            System.out.println(searchKey +  
	            		" not matched in database " + 
	            		store.getDatabaseName());    
	    	} else {
	            // Upon completing a search, the key and data DatabaseEntry         
	    		//	     parameters for getSearchBothRange() are populated with the         
	    		//	     key/data values of the found record.        
	    		String foundKey = new String(theKey.getData(),"UTF-8");
	    		System.out.println("Found record " + foundKey +" \n"+new String(theKey.getData(),"GBK") );  
	    		
	    		if(!foundKey.startsWith(searchKey))
    			{
    				return;
    			}
	    		cursor.delete();
	    		while (cursor.getNext(theKey, theData, LockMode.DEFAULT) ==
	                OperationStatus.SUCCESS) {
	    			foundKey = new String(theKey.getData(),"UTF-8");
	    			if(!foundKey.startsWith(searchKey))
	    			{
	    				break;
	    			}
	    			System.out.println("Found record " + foundKey +" \n"+new String(theKey.getData(),"GBK") );  
		            cursor.delete();
	    		}
	    	}
	    } catch (Exception e) {    // Exception handling goes here
	    	
	    }
	    finally {
	    	// Make sure to close the cursor   
	    	try {
				cursor.close();
			} catch (DatabaseException e) {
				e.printStackTrace();
			}
	    }
	}
}
