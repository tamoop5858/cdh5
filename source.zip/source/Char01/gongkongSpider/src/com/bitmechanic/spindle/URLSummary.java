/*
 * Created on 2004-11-20
 *
 */
package com.bitmechanic.spindle;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;

import org.htmlparser.Node;
import org.htmlparser.PrototypicalNodeFactory;
import org.htmlparser.lexer.Lexer;
import org.htmlparser.lexer.Page;
import org.htmlparser.lexer.nodes.NodeFactory;
import org.htmlparser.lexer.nodes.StringNode;
import org.htmlparser.lexer.nodes.TagNode;
import org.htmlparser.util.ParserException;

import fseg.result.FingerPrint;

/**
 * @author Administrator
 *
 */
public class URLSummary {
	public static NodeFactory typicalFactory =  new PrototypicalNodeFactory ();
	
	public URL url;
	public StringBuffer body = new StringBuffer();
	public String title = "";
	public Date accessDate = new Date();
	public ArrayList<String> outURLs = new ArrayList<String>();
	public ArrayList<String> URLsDesc = new ArrayList<String>();
	
	public void  parseHTML(HttpURLConnection uc,
							String include,
							boolean expand,
							String contentType) throws ParserException
	{
		Node node;
		String stringText;
		
		String charSet = URLSummary.getCharset (contentType);
		
		Lexer lexer = null;
		if(charSet!=null)
		{
			try {
				lexer = new Lexer (new Page(uc.getInputStream(), charSet ));
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return ;
			}
			catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace(System.out);
				return ;
			}
		}
		else
		{
			try {
				lexer = new Lexer (new Page(uc.getInputStream(), "GB2312" ));
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return ;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return ;
			}
		}
		lexer.setNodeFactory(typicalFactory);
		boolean tryAgain = false;
		while (null != (node = lexer.nextNode ()))
		{
			//omit script tag
			if (node instanceof org.htmlparser.tags.ScriptTag)
			{
				while (null != (node = lexer.nextNode ()))
				{
					if (node instanceof org.htmlparser.tags.Tag)
					{
						org.htmlparser.tags.Tag tag  = (org.htmlparser.tags.Tag)node;
						if( tag.isEndTag() && "SCRIPT".equals(tag.getTagName())  )
						{
							//System.out.println("tagname:"+tag.getTagName());
							break;
						}
					}
				}
				if(null == node)
					break;
			}
			//omit script tag
			else if (node instanceof org.htmlparser.tags.StyleTag)
			{
				while (null != (node = lexer.nextNode ()))
				{
					if (node instanceof org.htmlparser.tags.Tag)
					{
						org.htmlparser.tags.Tag tag  = (org.htmlparser.tags.Tag)node;
						if( tag.isEndTag())
							break;
					}
				}
				if(null == node)
					break;
			}
			else if (node instanceof StringNode)
			{
				stringText = node.toPlainTextString();
				if("".equals(title) )
					continue;
				stringText = stringText.replaceAll("[ \t\n\f\r��]+"," ");
				stringText = TextHtml.html2text(stringText.trim());
				if (! "".equals(stringText))
				{
					//System.out.println("stringText.len:"+stringText.length());
					this.body.append(stringText);					
					this.body.append(" ");
					//					System.out.println(this.body);
				}
			}
			else if (node instanceof TagNode)
			{
				TagNode tagNode = (TagNode)node;
				String name = ((TagNode)node).getTagName();
				if(name.equals("OPTION"))
				{
					//omit option
					lexer.nextNode ();
					lexer.nextNode ();
					//System.out.println("tag name:"+name);
				}
				else if (name.equals("A") && !tagNode.isEndTag() && expand)
				{
					String href = tagNode.getAttribute("HREF");
					
					String urlDesc = null;
					node = lexer.nextNode ();
					if(node instanceof StringNode)
					{
						StringNode sNode = (StringNode)node;
						String title = sNode.getText().trim();
						
						if(title.length()>=4)
						{
							urlDesc= title;
							//System.out.println("next node:"+title);
						}
					}

					addLink(this.url,include,href,urlDesc);
				}
				else if (name.equals("FRAME") &&
						!tagNode.isEndTag() && expand)
				{
					// FRAME SRC=
					addLink(url,include,tagNode.getAttribute("SRC"),null);
					// handle internal frame (iframes) as well
				}
				else if (name.equals("TITLE") &&
						!tagNode.isEndTag() )
				{
					node = lexer.nextNode ();
					stringText = node.toPlainTextString().trim();
					if(!"".equals(stringText))
					{
						this.title=stringText;
					}
				}
				else if(name.equals("META") && charSet == null)
				{
					String contentCharSet = tagNode.getAttribute("CONTENT");
					charSet = URLSummary.getCharset (contentCharSet);
					tryAgain = true;
					break;
				}
			}
		}
		if (tryAgain)
		{
			//if(charSet!=null && charSet.equals("GBK") )
			//System.out.println("charset:"+charSet);
			this.body = new StringBuffer();

			try {
				HttpTimeoutHandler xHTH = new HttpTimeoutHandler(600000);
				URL theURL = new URL((URL)null, uc.getURL().toString(), xHTH);
				uc = (HttpURLConnection) theURL.openConnection();
				lexer = new Lexer (new Page(uc.getInputStream(), charSet ));
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			lexer.setNodeFactory(typicalFactory);
			
			while (null != (node = lexer.nextNode ()))
			{
				//System.out.println("node:"+node);
				//omit script tag
				if (node instanceof org.htmlparser.tags.ScriptTag)
				{
					while (null != (node = lexer.nextNode ()))
					{
						if (node instanceof org.htmlparser.tags.Tag)
						{
							org.htmlparser.tags.Tag tag  = (org.htmlparser.tags.Tag)node;
							if( tag.isEndTag() && "SCRIPT".equals(tag.getTagName())  )
							{
								//System.out.println("tagname:"+tag.getTagName());
								break;
							}
						}
					}
					if(null == node)
						break;
				}
				//omit script tag
				else if (node instanceof org.htmlparser.tags.StyleTag)
				{
					while (null != (node = lexer.nextNode ()))
					{
						if (node instanceof org.htmlparser.tags.Tag)
						{
							org.htmlparser.tags.Tag tag  = (org.htmlparser.tags.Tag)node;
							if( tag.isEndTag())
								break;
						}
					}
					if(null == node)
						break;
				}
				else if (node instanceof StringNode)
				{
					stringText = node.toPlainTextString();
					if("".equals(title) )
						continue;
					stringText = stringText.replaceAll("[ \t\n\f\r��]+"," ");
					stringText = TextHtml.html2text(stringText.trim());
					if (! "".equals(stringText))
					{
						//System.out.println("stringText.len:"+stringText.length());
						this.body.append(stringText);					
						this.body.append(" ");
						//					System.out.println(this.body);
					}
				}
				else if (node instanceof TagNode)
				{
					TagNode tagNode = (TagNode)node;
					String name = ((TagNode)node).getTagName();
					//System.out.println("name:"+name);
					if(name.equals("OPTION"))
					{
						//omit option
						lexer.nextNode ();
						lexer.nextNode ();
						//System.out.println("tag name:"+name);
					}
					else if (name.equals("A") && !tagNode.isEndTag() && expand)
					{
						String href = tagNode.getAttribute("HREF");
						
						String urlDesc = null;
						node = lexer.nextNode ();
						if(node instanceof StringNode)
						{
							StringNode sNode = (StringNode)node;
							String title = sNode.getText().trim();
							
							if(title.length()>=4)
							{
								urlDesc= title;
								//System.out.println("next node:"+title);
							}
						}

						addLink(this.url,include,href,urlDesc);
					}
					else if (name.equals("FRAME") &&
							!tagNode.isEndTag() && expand)
					{
						// FRAME SRC=
						addLink(url,include,tagNode.getAttribute("SRC"),null);
						// handle internal frame (iframes) as well
					}
					else if (name.equals("TITLE") &&
							!tagNode.isEndTag() )
					{
						node = lexer.nextNode ();
						stringText = node.toPlainTextString().trim();
						if(!"".equals(stringText))
						{
							this.title=stringText;
						}
					}
				}
			}
		}
	}

    /**
     * Lookup a character set name.
     * <em>Vacuous for JVM's without <code>java.nio.charset</code>.</em>
     * This uses reflection so the code will still run under prior JDK's but
     * in that case the default is always returned.
     * @param name The name to look up. One of the aliases for a character set.
     * @param _default The name to return if the lookup fails.
     */
    public static String findCharset (String name, String _default)
    {
        String ret;

        try
        {
            Class cls;
            Method method;
            Object object;

            cls = Class.forName ("java.nio.charset.Charset");
            method = cls.getMethod ("forName", new Class[] { String.class });
            object = method.invoke (null, new Object[] { name });
            method = cls.getMethod ("name", new Class[] { });
            object = method.invoke (object, new Object[] { });
            ret = (String)object;
        }
        catch (ClassNotFoundException cnfe)
        {
            // for reflection exceptions, assume the name is correct
            ret = name;
        }
        catch (NoSuchMethodException nsme)
        {
            // for reflection exceptions, assume the name is correct
            ret = name;
        }
        catch (IllegalAccessException ia)
        {
            // for reflection exceptions, assume the name is correct
            ret = name;
        }
        catch (InvocationTargetException ita)
        {
            // java.nio.charset.IllegalCharsetNameException
            // and java.nio.charset.UnsupportedCharsetException
            // return the default
            ret = _default;
            System.out.println (
                "unable to determine cannonical charset name for "
                + name
                + " - using "
                + _default);
        }

        return (ret);
    }

    public static String getCharset (String content)
    {
        final String CHARSET_STRING = "charset";
        int index;
        String ret;

        ret = null;
        if (null != content)
        {
            index = content.indexOf (CHARSET_STRING);

            if (index != -1)
            {
                content = content.substring (index + CHARSET_STRING.length ()).trim ();
                if (content.startsWith ("="))
                {
                    content = content.substring (1).trim ();
                    index = content.indexOf (";");
                    if (index != -1)
                        content = content.substring (0, index);

                    //remove any double quotes from around charset string
                    if (content.startsWith ("\"") && content.endsWith ("\"") && (1 < content.length ()))
                        content = content.substring (1, content.length () - 1);

                    //remove any single quote from around charset string
                    if (content.startsWith ("'") && content.endsWith ("'") && (1 < content.length ()))
                        content = content.substring (1, content.length () - 1);

                    ret = findCharset (content, ret);
                }
            }
        }

        return (ret);
    }
	/**
	 * adds a links to the given vector. ignores (but logs) possible errors
	 */
	protected void addLink(URL origURL,String include,
			String newURL,String urlDesc)
	{
		if ((newURL == null) || (newURL.equals(""))) return;
		
		String lcaseNewURL = newURL.toLowerCase();
		//remove jpg or gif files.
		if (lcaseNewURL.endsWith(".gif") || 
			lcaseNewURL.endsWith(".jpg") || 
			lcaseNewURL.endsWith(".doc") ||
			lcaseNewURL.endsWith(".xls") ||
			lcaseNewURL.endsWith(".bmp")) return;
		
		// remove part after # from the URL
		int pos = newURL.indexOf("#");
		if (pos >=0 ) {
			newURL = newURL.substring(0,pos);
		}
     	
		try {
			if (newURL.startsWith("http://") || 
				(newURL.startsWith("https://") ))
			{
				// verify we're on the same host and port
				URL u = new URL(newURL);
				if (((include == null) || (newURL.indexOf(include)>=0) )
						&& u.getHost().equals(origURL.getHost()) &&
						u.getPort() == origURL.getPort() )
				{
					outURLs.add(newURL);
					URLsDesc.add(urlDesc);
					//System.out.println("link "+newURL);
				}
			}
			else if (newURL.indexOf("://") == -1 &&
					 !newURL.startsWith("mailto:") &&
					 !newURL.startsWith("#") &&
					 !newURL.startsWith("javascript:") &&
					 !newURL.startsWith("vbscript:"))
			{
				// parse relative url
				URL u = new URL(origURL,newURL);
				newURL = u.toString();
				if (( (include == null) || (newURL.indexOf(include)>=0) )
						&& (newURL.indexOf("../")<0) )
				{
					outURLs.add(newURL);
					URLsDesc.add(urlDesc);
					//System.out.println("link "+newURL);
				}
			}
			
		}
		catch (Exception e) {
			System.out.println("error during link extraction: "+e.getMessage()+" "+newURL);

    		System.out.println("content is null: max level -1 " + SpiderSolr.maxLevel);
    		if(SpiderSolr.maxLevel>SpiderSolr.minLevel)
    		{
    			SpiderSolr.maxLevel--;
    		}
		}
	}
	
	public String toString()
	{
		StringBuffer s = new StringBuffer();
		s.append("title:");
		s.append(this.title);
		s.append("\nbody:");
		s.append(this.body);
		s.append("\ndate:");
		java.text.SimpleDateFormat frm = new java.text.SimpleDateFormat("yyyy-MM-dd");
		
		s.append(frm.format(accessDate));
		
		for (int i =0 ;i< outURLs.size();i++)
		{
			s.append("\n");
			s.append(outURLs.get(i));
		}
		return s.toString();
	}

	/*public static void main(String[] args) throws Exception {
		String url = //"http://www.ad.siemens.com.cn/Training/education/course_intro.asp?id=E1004**";
//        "http://www.singamas.com/PageChn/Depot/CDepotMainSLQC.shtm";
//        	"http://www.abb.com/product/seitp329/a147c0b843b274e5c1256fa10036b390.aspx";
        	//"http://www.singamas.com/index.html";
        	//"http://www.yokogawa.com/cn/";
        	//"http://www.abb.com.cn/Product/seitp321/ee3e53565b91bf2ac1256f16004aea71.aspx?productLanguage=zh&country=CN";
//        "http://www.freescale.com.cn/Applications/automotive_mc33493.asp";
//        	"http://www.cwx168.com/ProductInfo.asp?ID=323&ParentID=97";
//        	"http://www.adtechcn.com/comnewslist.php?newsid=99";
//        	"http://www.aaeon.com.cn/?tabindex=solutions&tabid=home&cate_id=0122fdf200e6487b81";
//        	"http://www.ad.siemens.com.cn/applic/publicsystem/article.asp?articleid=426";
        	//"http://www.ad.siemens.com.cn/news_events/";
        	//"http://china.keyence.com/newsletters/2005/01_11_2005.php";
			//"http://www.bhconline.com.cn/article.asp?id=1&page=1030";
			//"http://www.ecguard.com/";
			//"http://www.bartec.com.cn/Outing2006.mht";
			//"http://www.bartec.com.cn/asiatechnologyworkshop2007/asiatechnologyworkshop2007.htm";
			//"http://www.fujitsu.com/cn/fmc/tw/news/archives/2006/1121.html";
			//"http://www.silimin.com/download/areve/P225.rar";
			//"http://ask.91.cn/index.php?act=list&did=61";
			"http://www.hn-pc.com/html/Article/2007/200709/20070908/200709087662.html";
        URLSummary urlBody = new URLSummary();
		urlBody.url = new URL(url);
		urlBody.accessDate = new Date();
		
		//parser = new Parser (url);
		HttpURLConnection uc = (HttpURLConnection) urlBody.url.openConnection();
		String ct = uc.getContentType();
		
		System.out.println("ct:" + ct);
		//"UTF-8"
		//"GBK"
		//TODO:iso-8859-1 or UTF-8 or GB2312 or ecode
		//Lexer lexer = new Lexer (new Page(uc.getInputStream(), "GB2312"));
		//URL theURL = new URL(urlBody.url.replaceAll(" ","%20"));
		//
		//lexer = new Lexer (new Page(uc.getInputStream(), Page.getCharset (ct)));
		
		//urlBody.parseHTML( parser.getLexer(),null,true);
		urlBody.parseHTML( uc,null,true,ct);
		System.out.println(urlBody.toString());
		
		String fingerPrint = FingerPrint.getFingerPrint("",urlBody.body.toString());
		//String md5Value = showBytes(FingerPrint.getMD5(fingerPrint));
		System.out.println("FingerPrint:"+fingerPrint);
	}*/
}
