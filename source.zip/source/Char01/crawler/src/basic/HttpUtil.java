package basic;

import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;

/**
 * �򵥵�������ҳ�����ж���ҳ����
 * 
 * @author luogang
 *
 */
public class HttpUtil {
	// ����utf-8�������ҳ
	public static String getContent(CloseableHttpClient httpclient, String url)
			throws Exception {
		String content = null;

		do {
			content = down(httpclient, url, "utf-8");
			if (content != null) {
				break;
			}
			Thread.sleep(1000);
			System.out.println("retry get content ...");
		} while (true);

		return content;
	}

	// ����GBK�������ҳ
	public static String getContentGBK(CloseableHttpClient httpclient,
			String url) throws Exception {
		String content = null;

		do {
			content = down(httpclient, url, "gbk");
			if (content != null) {
				break;
			}
			Thread.sleep(1000);
			System.out.println("retry get content ...");
		} while (true);

		return content;
	}

	public static String down(CloseableHttpClient httpclient, String url,
			String encode) throws Exception {
		HttpGet httpget = new HttpGet(url);

		String content = null;

		HttpResponse response;
		try {
			response = httpclient.execute(httpget);
		} catch (ClientProtocolException e) {
			e.printStackTrace();

			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}

		int code = response.getStatusLine().getStatusCode();
		// System.out.println(code);
		if (code != HttpStatus.SC_OK) {
			throw new Exception("down error httpcode:" + code);
		}

		// �鿴���ص����ݣ���������������쿴��ҳԴ����
		HttpEntity entity = response.getEntity();
		if (entity != null) {

			try {
				content = EntityUtils.toString(entity, encode); // "utf-8"
			} catch (ParseException | IOException e) {
				e.printStackTrace();
			}

			// System.out.println(json);
			try {
				EntityUtils.consume(entity);
			} catch (IOException e) {
				e.printStackTrace();
			}// �ر�������
		}
		return content;
	}
}
