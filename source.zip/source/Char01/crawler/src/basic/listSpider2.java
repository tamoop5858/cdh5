package basic;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class listSpider2 {

	public static void main(String[] args) throws IOException {
		String url = "http://china.cnr.cn/yaowen/";
		Document document = Jsoup.connect(url).timeout(1000).get();
		//System.out.println(document.html()); //��ӡ��ҳԴ����

		Element content = document.getElementById("cntl");
		
		Elements es = content.getElementsByClass("ml20");
		// System.out.println(es);
		for (Element link : es) { // ����ÿ������,:���������ÿһ��Ԫ��д��ǰ��
			Element alink = link.getElementsByTag("a").first();
			if(alink !=null){
				System.out.println(alink.attr("href"));
				System.out.println(alink.text());
			}
		}
	}

}
