package basic;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;

/**
 * @author luogang
 * @2013-12-6
 */
public class six {

	public static void main(String[] args){
		System.out.println(occureTimes("����ʦ��һ������ʦ","��ʦ"));
}
	// ���ִ���
	// �´����ı��г��ִ���
	public static int occureTimes(String input, String newWord) {
		if ("".equals(newWord))
			return 0;
		int index = input.indexOf(newWord);
		int count = 0;
		while (index >= 0) {
			count++;
			// System.out.println("index "+index);
			// input = input.substring(index + 1);
			index = input.indexOf(newWord, index + newWord.length());
		}

		return count;
	}
}
