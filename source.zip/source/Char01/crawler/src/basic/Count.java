package basic;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.Header;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicHeader;

public class Count {

	static List<Header> headers = getHeads();
	
	private static List<Header> getHeads() {
		// headers
		String userAgent = "Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.9.1.2)";
		List<Header> headers = new ArrayList<Header>();
		//Accept			
		headers.add(new BasicHeader("Accept",
				"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"));
		headers.add(new BasicHeader("Accept-Charset",
				"GB2312,utf-8;q=0.7,*;q=0.7"));
		headers.add(new BasicHeader("Accept-Language", "zh-cn,zh;q=0.5"));
		headers.add(new BasicHeader("User-Agent", userAgent));
		headers.add(new BasicHeader("Cookie",
				"__jsluid=159498617c2992772bd44b01c3a5b01a; __jsl_clearance=1443086045.636|0|K5HLN5NJskPxjMFjbq5BauHSOrY%3D; JSESSIONID=46EB836CE400FAEBA379FF1BEC653855"));
		headers.add(new BasicHeader("Host","shixin.court.gov.cn"));
		//Accept-Encoding: gzip, deflate
		headers.add(new BasicHeader("Accept-Encoding","gzip, deflate"));
		//Connection 		keep-alive
		headers.add(new BasicHeader("Connection","keep-alive"));
		//Cache-Control	 		max-age=0
		headers.add(new BasicHeader("Cache-Control","max-age=0"));
		return headers;
	}

	public static void main(String[] args) throws Exception {
		String url = "http://shixin.court.gov.cn/personMore.do";
		//CloseableHttpClient httpclient = HttpClientBuilder.create().build();

		CloseableHttpClient httpClient = HttpClientBuilder.create()
				.setDefaultHeaders(headers).build();

		String content = HttpUtil.getContent(httpClient, url);
		System.out.println(content);
	}

}
