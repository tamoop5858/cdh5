package basic;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class two {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Document document = Jsoup.connect("http://item.jd.com/10400758.html").get();
		System.out.println(document.html());
		Element content = document.select("div.p-name").first();
		System.out.println(content.html());
	}

}
