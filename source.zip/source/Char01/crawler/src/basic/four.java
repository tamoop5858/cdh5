package basic;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Properties;

public class four {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Properties p = new Properties();
			p.put("charSet", "GBK");
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			String dburl = "jdbc:odbc:driver={Microsoft Access Driver (*.mdb)};DBQ=D:/z/cwu.mdb";
			Connection conn = DriverManager.getConnection(dburl, p);
			PreparedStatement stmt= conn.prepareStatement("insert into crawler(bookName)values(?)");
	String name="����ѽ";
	stmt.setString(1, name);
	stmt.executeUpdate();
	conn.close();
			return;
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}
	}

}
