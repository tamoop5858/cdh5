package searchSpider;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.URI;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.RedirectLocations;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;

import util.AutoEncodeHttpUtil;

/**
 * 搜索结果处理
 * @author luogang
 *
 */
public class SearchResult {

	//下载重定向网址到文件
	public static void down2File(String url,String fileName) throws Exception{
		CloseableHttpClient client = HttpClientBuilder.create().build();
		HttpGet request = new HttpGet(url);
		
		HttpContext context = new BasicHttpContext();
		HttpResponse response = client.execute(request, context);
		URI finalUrl = request.getURI();
		RedirectLocations locations = (RedirectLocations) context
				.getAttribute(HttpClientContext.REDIRECT_LOCATIONS);
		if (locations != null) {
			finalUrl = locations.getAll().get(locations.getAll().size() - 1);
		}
		System.out.println(finalUrl);
		HttpEntity entity = response.getEntity();
		
		AutoEncodeHttpUtil httpUtil = new AutoEncodeHttpUtil();
		String content = httpUtil.getHtml(entity);
		
		//String fileName="f:/test/"+i+".html";
		writeToFile(content, fileName, httpUtil.htmlCharSet);
	}
	
	/**
	 * 向文件写入字符串
	 * @param content 字符串
	 * @param fileName 文件名
	 * @param encoding 编码
	 */
	public static void writeToFile(String content,String fileName,String encoding){		
			try {
				FileOutputStream fos = new FileOutputStream(fileName);
				OutputStreamWriter osw=new OutputStreamWriter(fos,encoding);
				BufferedWriter bw=new BufferedWriter(osw);
				bw.write(content);
				bw.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
	}

	//http://www.baidu.com/link?url=tjQTd1keyjB_MrSNGrfDWSdsIzWfvqyNsmlMFx_7kpynFOaNXRR81Sp5R7d4BZMu
	//处理类似这样的网址
	public static String down(String url)throws Exception{
		CloseableHttpClient client = HttpClientBuilder.create().build();

		HttpGet request = new HttpGet(url);

		HttpContext context = new BasicHttpContext();
		HttpResponse response = client.execute(request, context);
		URI finalUrl = request.getURI();
		RedirectLocations locations = (RedirectLocations) context
				.getAttribute(HttpClientContext.REDIRECT_LOCATIONS);
		if (locations != null) {
			finalUrl = locations.getAll().get(locations.getAll().size() - 1);
		}
		System.out.println(finalUrl);
		HttpEntity entity = response.getEntity();
		String ret = AutoEncodeHttpUtil.downHtml(entity);
		System.out.println(ret);
		return ret;
	}
	
}
