package searchSpider;

import java.net.URLEncoder;

import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import util.HttpUtil;

public class BaiduSpider {

	static String charSet = "GBK";

	public static Document search(String newWord) throws Exception {

		String searchWord = URLEncoder.encode(newWord, charSet);
		String url = "http://www.baidu.com/s?wd=" + searchWord;
		// System.out.println(url);

		String content = getContentGBK(url);

		Document doc = Jsoup.parse(content);
		
		if("百度--您的访问出错了".equals(doc.title())){
			System.out.println("被封IP了");
			return null;
		}
		
		return doc;
	}

	// 下载GBK编码的网页
	public static String getContentGBK(String url) throws Exception {
		CloseableHttpClient httpclient = HttpClientBuilder.create().build();
		String content = null;

		do {
			content = HttpUtil.down(httpclient, url, "gbk");
			if (content != null) {
				break;
			}
			httpclient.close();
			httpclient = HttpClientBuilder.create().build();
			Thread.sleep(2000);
			System.out.println("retry get content ...");
		} while (true);

		return content;
	}
	
}
