package searchSpider;

//存储接口
public interface Target {
	public void insertResult(String title,String content); //用户及发布的信息
}
