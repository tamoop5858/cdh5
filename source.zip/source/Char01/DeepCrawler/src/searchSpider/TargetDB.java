package searchSpider;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.commons.dbutils.QueryRunner;

import util.DBUtil;

/**
 * 抓下来的新闻写入到数据库
 * 类似ETL导入的目的表
 * @author luogang
 *
 */
public class TargetDB implements Target {
	Connection con = DBUtil.getConnect();
	
	@Override
	public void insertResult(String title,String content) {
		System.out.println(content);
		QueryRunner runner = new QueryRunner();
		try {
			String sql = "INSERT INTO searchresult(title,content) VALUES (?,?)";
			runner.update(con,sql,
					title, content);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
