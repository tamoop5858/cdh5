package util;

public class URLValid {
	/**
	 * 提取主域名
	 */
	public static String getDomain(String url) {
		int domainStartIdx = url.indexOf("//") + 2;
		int domainEndIdx = url.indexOf('/', domainStartIdx);
		if (domainEndIdx < 0) {
			domainEndIdx = url.length();
		}
		String domain = url.substring(domainStartIdx, domainEndIdx);
		String[] parts = domain.split("\\.");
		if (parts.length > 2) {
			domain = parts[parts.length - 2] + "." + parts[parts.length - 1];

			if (TLDList.getInstance().contains(domain)) {
				domain = parts[parts.length - 3] + "." + domain;
			}
		}
		return domain;
	}
}
