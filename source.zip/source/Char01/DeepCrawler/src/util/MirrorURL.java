package util;

//"http://www.cninfo.com.cn/" 和 "http://disclosure.szse.cn/" 互为镜像
public class MirrorURL {

}
