package util;

public class HttpError {
	private static final int OK = 200; // OK: Success!
	private static final int NOT_MODIFIED = 304; // Not Modified: There was no
													// new data to return.
	private static final int BAD_REQUEST = 400; // Bad Request: The request was
												// invalid. An accompanying
												// error message will explain
												// why. This is the status code
												// will be returned during rate
												// limiting.
	private static final int NOT_AUTHORIZED = 401; // Not Authorized:
													// Authentication
													// credentials were missing
													// or incorrect.
	private static final int FORBIDDEN = 403; // Forbidden: The request is
												// understood, but it has been
												// refused. An accompanying
												// error message will explain
												// why.
	private static final int NOT_FOUND = 404; // Not Found: The URI requested is
												// invalid or the resource
												// requested, such as a user,
												// does not exists.
	private static final int NOT_ACCEPTABLE = 406; // Not Acceptable: Returned
													// by the Search API when an
													// invalid format is
													// specified in the request.
	private static final int INTERNAL_SERVER_ERROR = 500; // Internal Server
															// Error: Something
															// is broken. Please
															// post to the group
															// so the Weibo team
															// can investigate.
	private static final int BAD_GATEWAY = 502; // Bad Gateway: Weibo is down or
												// being upgraded.
	private static final int SERVICE_UNAVAILABLE = 503; // Service Unavailable:
														// The Weibo servers are
														// up, but overloaded
														// with requests. Try
														// again later. The
														// search and trend
														// methods use this to
														// indicate when you are
														// being rate limited.

	/**
	 * 获取异常原因
	 * 
	 * @param statusCode
	 * @return
	 */
	public static String getErrorCause(int statusCode) {
		String cause = null;
		switch (statusCode) {
		case NOT_MODIFIED:
			break;
		case BAD_REQUEST:
			cause = "（错误请求）服务器不理解请求的语法.";
			break;
		case NOT_AUTHORIZED:
			cause = "（未授权） 请求要求进行身份验证.";
			break;
		case FORBIDDEN:
			cause = "（已禁止） 服务器拒绝请求.";
			break;
		case NOT_FOUND:
			cause = "（未找到） 服务器找不到请求的网页.";
			break;
		case NOT_ACCEPTABLE:
			cause = "（不接受） 无法使用请求的内容特性来响应.";
			break;
		case INTERNAL_SERVER_ERROR:
			cause = "（服务器内部错误）服务器遇到错误，无法完成请求.";
			break;
		case BAD_GATEWAY:
			cause = "（错误网关） 服务器作为网关或**，从上游服务器收到了无效的响应.";
			break;
		case SERVICE_UNAVAILABLE:
			cause = "（服务不可用） 目前无法使用服务器（由于超载或进行停机维护）.";
			break;
		default:
			cause = "";
		}
		return cause;
	}
}
