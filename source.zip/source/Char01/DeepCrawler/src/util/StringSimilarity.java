package util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 * 计算两个字符串的相似度 相似度的值在0到1之间
 * 
 * @author luogang
 * 
 */
public class StringSimilarity {

	public static double getLCSSimScore(String s1, String s2) {
		int lcsLength = lcsLen(s1, s2);
		double sim = (double) lcsLength
				/ (double) Math.min(s1.length(), s2.length());
		return sim;
	}

	static int lcsLen(String s1, String s2) {
		int[][] lenLCS = new int[s1.length() + 1][s2.length() + 1]; // 初始化为0的二维数组

		// 实际算法
		for (int i = 1; i <= s1.length(); i++)
			for (int j = 1; j <= s2.length(); j++)
				if (s1.charAt(i - 1) == s2.charAt(j - 1))
					lenLCS[i][j] = 1 + lenLCS[i - 1][j - 1];
				else
					lenLCS[i][j] = Math.max(lenLCS[i - 1][j], lenLCS[i][j - 1]);

		return lenLCS[s1.length()][s2.length()];
	}

	public static double getDiceSimScore(ArrayList<String> s1,
			ArrayList<String> s2) {
		Set<String> intersection = new HashSet<String>(s1);
		intersection.retainAll(s2);
		int totcom = intersection.size();

		return calculateDiceCoefficient(totcom, s1.size(), s2.size());
	}

	/**
	 * Calculate Dice's Coefficient
	 * 
	 * @param intersection
	 *            number of tokens in common between input 1 and input 2
	 * @param size1
	 *            token size of first input
	 * @param size2
	 *            token size of second input
	 * @return Dice's Coefficient as a float
	 */
	public static double calculateDiceCoefficient(int intersection, int size1,
			int size2) {
		return ((2.0 * (double) intersection)) / (double) (size1 + size2);
	}

	// Note that this implementation is case-sensitive!
	public static double diceCoefficient(String s1, String s2) {
		Set<String> nx = new HashSet<String>();
		Set<String> ny = new HashSet<String>();

		for (int i = 0; i < s1.length() - 1; i++) {
			char x1 = s1.charAt(i);
			char x2 = s1.charAt(i + 1);
			String tmp = "" + x1 + x2;
			nx.add(tmp);
		}
		for (int j = 0; j < s2.length() - 1; j++) {
			char y1 = s2.charAt(j);
			char y2 = s2.charAt(j + 1);
			String tmp = "" + y1 + y2;
			ny.add(tmp);
		}

		Set<String> intersection = new HashSet<String>(nx);
		intersection.retainAll(ny);
		double totcombigrams = intersection.size();

		return (2 * totcombigrams) / (nx.size() + ny.size());
	}

	public static String longestCommonSubsequence(String s1, String s2) {
		int[][] num = new int[s1.length() + 1][s2.length() + 1]; // 2D array,

		// Actual algorithm
		for (int i = 1; i <= s1.length(); i++)
			for (int j = 1; j <= s2.length(); j++)
				if (s1.charAt(i - 1) == (s2.charAt(j - 1)))
					num[i][j] = 1 + num[i - 1][j - 1];
				else
					num[i][j] = Math.max(num[i - 1][j], num[i][j - 1]);

		// logger.debug("length of LCS = " + num[s1.length][s2.length]);

		int s1position = s1.length(), s2position = s2.length();
		StringBuilder result = new StringBuilder();

		while (s1position != 0 && s2position != 0) {
			if (s1.charAt(s1position - 1) == s2.charAt(s2position - 1)) {
				result.append(s1.charAt(s1position - 1));
				s1position--;
				s2position--;
			} else if (num[s1position][s2position - 1] >= num[s1position - 1][s2position]) {
				s2position--;
			} else {
				s1position--;
			}
		}
		result.reverse();
		return result.toString();
	}
}
