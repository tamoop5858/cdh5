package util;

import java.io.IOException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.entity.ContentType;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.StandardHttpRequestRetryHandler;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.mozilla.universalchardet.UniversalDetector;

public class AutoEncodeHttpUtil {
	static final String defaultCharSet = "utf-8";
	static HttpRequestRetryHandler retryHandler = new StandardHttpRequestRetryHandler(
			16, true);
	
	static List<Header> headers = getHeads();

	private static List<Header> getHeads() {
		// headers
		String userAgent = "Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.9.1.2)";
		List<Header> headers = new ArrayList<Header>();
		headers.add(new BasicHeader("Accept-Charset","GB2312,utf-8;q=0.7,*;q=0.7"));
		headers.add(new BasicHeader("Accept-Language","zh-cn,zh;q=0.5"));
		headers.add(new BasicHeader("User-Agent",userAgent));
		
		return headers;
	}

	public static String getHtml(URL url) throws Exception {
		String value = null;
		
		// configurations
		int socketTimeout = 9000;
		int connectionTimeout = 9000;
		// request configuration
		RequestConfig requestConfig = RequestConfig.custom()
				.setConnectTimeout(connectionTimeout)
				.setSocketTimeout(socketTimeout).build();
		
		CloseableHttpClient httpClient = HttpClientBuilder.create()
				.setDefaultRequestConfig(requestConfig)
				.setDefaultHeaders(headers)
				.setRetryHandler(retryHandler).build();
		HttpGet httpget = new HttpGet(url.toURI());

		HttpResponse response = httpClient.execute(httpget);

		// 判断页面返回状态判断是否进行转向抓取新链接
		int statusCode = response.getStatusLine().getStatusCode();
		if ((statusCode == HttpStatus.SC_MOVED_PERMANENTLY)
				|| (statusCode == HttpStatus.SC_MOVED_TEMPORARILY)
				|| (statusCode == HttpStatus.SC_SEE_OTHER)
				|| (statusCode == HttpStatus.SC_TEMPORARY_REDIRECT)) {
			// 此处重定向处理 此处还未验证
			String newUri = response.getLastHeader("Location").getValue();
			//System.out.println("重定向:"+newUri);
			httpClient = HttpClientBuilder.create().build();
			httpget = new HttpGet(newUri);
			response = httpClient.execute(httpget);
		}
		
		/*Header[] s = response.getAllHeaders();

		System.out.println("THe header from the httpclient:");

		for (int i = 0; i < s.length; i++) {
			Header hd = s[i];
			System.out.println("Header Name: " + hd.getName() + "       "
					+ " Header Value: " + hd.getValue());
		}*/

		// Get hold of the response entity
		HttpEntity entity = response.getEntity();
		// If the response does not enclose an entity, there is no need
		// to bother about connection release
		if (entity != null) {
			// 将源码流保存在一个byte数组当中，因为可能需要两次用到该流，
			byte[] bytes = EntityUtils.toByteArray(entity);
			// 如果头部Content-Type中包含了编码信息，那么我们可以直接在此处获取

			ContentType contentType = ContentType.getOrDefault(entity);
			Charset cSet = contentType.getCharset();
			String charSet = null;
			if (cSet != null)
				charSet = cSet.toString();
			// 如果头部中没有，那么我们需要 查看页面源码，这个方法虽然不能说完全正确，因为有些粗糙的网页编码者没有在页面中写头部编码信息
			if (charSet == null) {
				// http头信息中无charset
				// 从meta信息中找字符集
				// <meta http-equiv=Content-Type
				// content="text/html;charset=gb2312">
				// <meta http-equiv="content-type" content="text/html;
				// charset=UTF-8" />
				value = new String(bytes, defaultCharSet);
				// 按默认编码转成字符串，因为匹配中无中文，所以串中可能的乱码对匹配没有影响
				Pattern pt = Pattern.compile("<meta(.*?)charset=(.*?)\"",
						Pattern.CASE_INSENSITIVE);
				Matcher mc = pt.matcher(value);
				if (mc.find()) {
					charSet = mc.group(2).trim();
					// System.out.println("find charset meta:"+charSet);
				} else {// 否则是<?xml version="1.0" encoding="gb2312"?>格式的
					pt = Pattern.compile("<?xml(.*?)encoding=\"(.*?)\"",
							Pattern.CASE_INSENSITIVE);
					mc = pt.matcher(value);
					if (mc.find()) {
						charSet = mc.group(2).trim();
					}
				}
			}

			if (charSet == null|| "".equals(charSet)) {
				UniversalDetector detector = new UniversalDetector(null);
				detector.handleData(bytes, 0, bytes.length);
				detector.dataEnd();
				charSet = detector.getDetectedCharset();
				//System.out.println("detect charset:" + charSet+" url "+url);
				if (charSet == null)
					return null;
			}
			if (charSet != null && charSet.toLowerCase().equals("gb2312")) {
				charSet = "GBK";
			}

			if (!defaultCharSet.equals(charSet) || value == null){
				//System.out.println("charset:" + charSet);
				value = new String(bytes, charSet);
			}
		}

		httpClient.close();
		// System.out.println(value);
		return value;
	}

	public String htmlCharSet = "utf-8";  //网页编码
	
	public String getHtml(HttpEntity entity) throws IOException{
		String value = null;
		
		if (entity != null) {
			// 将源码流保存在一个byte数组当中，因为可能需要两次用到该流，
			byte[] bytes = EntityUtils.toByteArray(entity);
			// 如果头部Content-Type中包含了编码信息，那么我们可以直接在此处获取

			ContentType contentType = ContentType.getOrDefault(entity);
			Charset cSet = contentType.getCharset();
			String charSet = null;
			if (cSet != null)
				charSet = cSet.toString();
			// 如果头部中没有，那么我们需要 查看页面源码，这个方法虽然不能说完全正确，因为有些粗糙的网页编码者没有在页面中写头部编码信息
			if (charSet == null) {
				// http头信息中无charset
				// 从meta信息中找字符集
				// <meta http-equiv=Content-Type
				// content="text/html;charset=gb2312">
				// <meta http-equiv="content-type" content="text/html;
				// charset=UTF-8" />
				value = new String(bytes, defaultCharSet);
				// 按默认编码转成字符串，因为匹配中无中文，所以串中可能的乱码对匹配没有影响
				Pattern pt = Pattern.compile("<meta(.*?)charset=(.*?)\"",
						Pattern.CASE_INSENSITIVE);
				Matcher mc = pt.matcher(value);
				if (mc.find()) {
					charSet = mc.group(2).trim();
					// System.out.println("find charset meta:"+charSet);
				} else {// 否则是<?xml version="1.0" encoding="gb2312"?>格式的
					pt = Pattern.compile("<?xml(.*?)encoding=\"(.*?)\"",
							Pattern.CASE_INSENSITIVE);
					mc = pt.matcher(value);
					if (mc.find()) {
						charSet = mc.group(2).trim();
					}
				}
			}

			if (charSet == null|| "".equals(charSet)) {
				UniversalDetector detector = new UniversalDetector(null);
				detector.handleData(bytes, 0, bytes.length);
				detector.dataEnd();
				charSet = detector.getDetectedCharset();
				//System.out.println("detect charset:" + charSet+" url "+url);
				if (charSet == null)
					return null;
			}
			if (charSet != null && charSet.toLowerCase().equals("gb2312")) {
				charSet = "GBK";
			}

			if (!defaultCharSet.equals(charSet) || value == null){
				//System.out.println("charset:" + charSet);
				value = new String(bytes, charSet);
			}
			
			htmlCharSet = charSet;
		}

		return value;
	}
	
	public static String downHtml(HttpEntity entity) throws IOException{
		String value = null;
		
		if (entity != null) {
			// 将源码流保存在一个byte数组当中，因为可能需要两次用到该流，
			byte[] bytes = EntityUtils.toByteArray(entity);
			// 如果头部Content-Type中包含了编码信息，那么我们可以直接在此处获取

			ContentType contentType = ContentType.getOrDefault(entity);
			Charset cSet = contentType.getCharset();
			String charSet = null;
			if (cSet != null)
				charSet = cSet.toString();
			// 如果头部中没有，那么我们需要 查看页面源码，这个方法虽然不能说完全正确，因为有些粗糙的网页编码者没有在页面中写头部编码信息
			if (charSet == null) {
				// http头信息中无charset
				// 从meta信息中找字符集
				// <meta http-equiv=Content-Type
				// content="text/html;charset=gb2312">
				// <meta http-equiv="content-type" content="text/html;
				// charset=UTF-8" />
				value = new String(bytes, defaultCharSet);
				// 按默认编码转成字符串，因为匹配中无中文，所以串中可能的乱码对匹配没有影响
				Pattern pt = Pattern.compile("<meta(.*?)charset=(.*?)\"",
						Pattern.CASE_INSENSITIVE);
				Matcher mc = pt.matcher(value);
				if (mc.find()) {
					charSet = mc.group(2).trim();
					// System.out.println("find charset meta:"+charSet);
				} else {// 否则是<?xml version="1.0" encoding="gb2312"?>格式的
					pt = Pattern.compile("<?xml(.*?)encoding=\"(.*?)\"",
							Pattern.CASE_INSENSITIVE);
					mc = pt.matcher(value);
					if (mc.find()) {
						charSet = mc.group(2).trim();
					}
				}
			}

			if (charSet == null|| "".equals(charSet)) {
				UniversalDetector detector = new UniversalDetector(null);
				detector.handleData(bytes, 0, bytes.length);
				detector.dataEnd();
				charSet = detector.getDetectedCharset();
				//System.out.println("detect charset:" + charSet+" url "+url);
				if (charSet == null)
					return null;
			}
			if (charSet != null && charSet.toLowerCase().equals("gb2312")) {
				charSet = "GBK";
			}

			if (!defaultCharSet.equals(charSet) || value == null){
				//System.out.println("charset:" + charSet);
				value = new String(bytes, charSet);
			}
		}

		return value;
	}
}
