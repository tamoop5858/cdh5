package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class DBUtil {

	public static Connection getMysqlConnection() throws Exception {
		// this will load the MySQL driver, each DB has its own driver
		Class.forName("com.mysql.jdbc.Driver");
		// setup the connection with the DB.
		Connection conn = DriverManager
				.getConnection("jdbc:mysql://localhost/feedback?"
						+ "user=sqluser&password=sqluserpw");
		return conn;
	}
	
	public static Connection getAccessConnection()throws Exception {
		Properties p = new Properties();
		p.put("charSet", "GBK");
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		String dburl = "jdbc:odbc:driver={Microsoft Access Driver (*.mdb)};DBQ=./crawler.mdb";
		Connection conn = DriverManager.getConnection(dburl, p);
		return conn;
	}
	
	public static Connection getOracleConnection()throws Exception {
		 Class.forName("oracle.jdbc.driver.OracleDriver"); 
				 Connection conn =  DriverManager.getConnection(
		  "jdbc:oracle:thin:@192.168.5.253:1521:orcl", "weiwei2",
		  "weiwei2");
		 return conn;
	}
	
	public static Connection getSqliteConnection()throws Exception {
		try {
			Class.forName("org.sqlite.JDBC");
			String absolute_path_to_sqlite_db = "./db/stock.sqlite";
			// "/usr/local/resin-3.0.25/bin/dic/words.db";
			return DriverManager.getConnection("jdbc:sqlite:"
					+ absolute_path_to_sqlite_db);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static Connection getConnect() {
		try {
			return getSqliteConnection(); //getAccessConnection();//
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public static String getScalar(String sql,String arg) throws SQLException{
		Connection con = DBUtil.getConnect();
		//String sql = "SELECT fullname FROM stocks where stockname=?";
		Statement stmt = con.createStatement();
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, arg);

		ResultSet rs = ps.executeQuery();
		String fullName = null;
		if (rs.next()) {
			fullName = rs.getString(1);
		}
		stmt.close();
		return fullName;
	}

}
