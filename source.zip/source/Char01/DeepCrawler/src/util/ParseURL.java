package util;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.StringTokenizer;

/**
 * 解析URL地址中的参数
 * @author luogang
 *
 */
public class ParseURL {
	public HashMap<String,String> searchparms;
	public String baseURL;//不带参数的网址

	// dump to the console the URL, the search and search values
	// the URL http://myserver.com/mypage.html?value1=x&value2=y&value3=z
	// the search value1=x&value2=y&value3=z
	// the values value1=x
	// value2=y
	// value3=z
	//
	// then the values are stored in a Hashtable for easy reference.
	// ex. String name = searchparms.get("value2")
	public ParseURL(String completeURL) {
		int i;
		// String completeURL = getDocumentBase().toString();
		//System.out.println("Complete URL: " + completeURL);
		i = completeURL.indexOf("?");
		if (i > -1) {
			String searchURL = completeURL
					.substring(completeURL.indexOf("?") + 1);
			//System.out.println("Search URL: " + searchURL);

			//StringTokenizer st = new StringTokenizer(searchURL, "&");
			//while (st.hasMoreTokens()) {
			//	String searchValue = st.nextToken();
				//System.out.println("value :" + searchValue);
			//}
			initHashtable(searchURL);
			//dumpHashtable();
			baseURL = completeURL.substring(0,completeURL.indexOf("?"));// the URL http://myserver.com/mypage.html
		} else {
			baseURL = completeURL;
		}
	}

	public void initHashtable(String search) {
		searchparms = new HashMap<String,String>();
		StringTokenizer st1 = new StringTokenizer(search, "&");
		while (st1.hasMoreTokens()) {
			StringTokenizer st2 = new StringTokenizer(st1.nextToken(), "=");
			String key = st2.nextToken();// value2=y
			String value = "";
			if(st2.hasMoreTokens()){
				value = st2.nextToken();
			}
			searchparms.put(key, value);
		}
	}

	public void dumpHashtable() {
		//Set<String> keys =  searchparms.keySet();
		System.out.println("--------");
		for (Entry<String, String> e :searchparms.entrySet()) {
			//String s = (String) keys.nextElement();
			System.out.println("key : " + e.getKey() + " value : " + e.getValue());
		}
		System.out.println("--------");
	}
}
