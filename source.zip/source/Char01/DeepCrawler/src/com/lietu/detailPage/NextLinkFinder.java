package com.lietu.detailPage;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


/**
 * 找下一页链接
 * TODO 支持iframe
 * @author luogang
 *
 */
public class NextLinkFinder {

	public static Element nextPageLink(Document doc){
		Elements nodeList = doc.getElementsByTag("a");
		for (Element n : nodeList) {
			String text = n.text();
			//System.out.println("Element text "+ text);
			if("下一页".equals(text)){
				//System.out.println("Element "+ n);
				return n;
			}
		}
		return null;
	}

}
