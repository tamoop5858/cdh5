package com.lietu.detailPage;

import java.net.URL;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import util.AutoEncodeHttpUtil;
import util.UrlResolver;

import com.lietu.ie.AdjList;
import com.lietu.ie.BodyWords;
import com.lietu.ie.FuncTree;


//TODO 提取新闻中的图片
public class DetailPageExtractor {
	private static final double linkTextRadio = 0.25; // 链接文字比

	// 计算链接数
	public static int calcLinks(Element node) {
		Elements links = node.select("a[href]");
		return links.size();
	}

	// 计算内容长度
	public static double calcWords(Element node) {
		String con = node.text();
		if (con.length() == 0) {
			return 1 + linkTextRadio;
		} else {
			return con.length();
		}
	}

	static AVLTree sign = new AVLTree(',', ';', '.', '"', '\'', '?', '。', ':', '，');
	
	// 计算标点符号的个数，判断正文块简单的方法是：取标点符号数量最多的块
	public static int calcSign(Element node) {
		int sum = 0;
		String text = node.text();
		for(int i=0;i<text.length();++i){
			if(sign.find(text.charAt(i)))
				sum++;
		}
		return sum;
	}
	
	//删除噪音节点
	public static int removeNoise(Element node){
		int signs = calcSign(node); // 符号出现的情况
		if (signs < 1) {
			try{
				// 删除没有标点符号的节点
				node.remove();
			}catch(java.lang.IllegalArgumentException e){}
			return -1;
		}
		
		int links = calcLinks(node);; // 链接数
		double words = calcWords(node); // 文字长度
		double cellRatio = links / words;
		if (cellRatio > linkTextRadio) { // 根据链接文字比删除非正文的块
			try{
				node.remove();
			}catch(java.lang.IllegalArgumentException e){}
			return -1;
		}
		
		return signs;
	}

	//分隔符号放到AVLTree
	static AVLTree titleSplit = new AVLTree('_', '|', '-'); //-
	
	// 提取标题
	private static String drawTitle(Document doc) {
		//System.out.println("enter split title");
		// 先取页面的title部分的值
		String tit = doc.title();
		
		//提取分隔符号的前面部分作为标题
		for(int i=0;i<tit.length();++i){
			if(titleSplit.find(tit.charAt(i))){
				//System.out.println("split title");
				tit = tit.substring(0, i);
				return tit;
			}
		}
		
		return tit;
	}

	//TODO
	public static DetailInfo extract(String url) throws Exception {
		String htmlContent = AutoEncodeHttpUtil.getHtml(new URL(url));
		//System.out.println("htmlContent "+htmlContent);
		if(htmlContent == null)
			return null;
		
		Document doc = Jsoup.parse(htmlContent);
		
		String title = drawTitle(doc);// 标题
		DetailInfo info=new DetailInfo(title);
		String nextPageURL = getNextURL(url,doc);
		info.nextPageURL = nextPageURL;
		DetailInfo news = getRest(info,htmlContent,doc);
		
		return news;
	}
	
	private static String getNextURL(String baseUrl,Document doc) {
		Element nextPageLink = NextLinkFinder.nextPageLink(doc);
		if(nextPageLink==null)
			return null;
		String linkHref = UrlResolver.resolveUrl(baseUrl, nextPageLink.attr("href")); // 得到URL绝对地址
		return linkHref;
	}

	private static String drawSource(String str) {
		Pattern pt = Pattern.compile("来源[：:].*?([\u4e00-\u9fff]+)",
				Pattern.CASE_INSENSITIVE);
		Matcher mc = pt.matcher(str);
		if (mc.find()) {
			String time = mc.group(1);
			return time;
		}
		return null;
	}
	
	static boolean alignFilter(Element node){
		String align = node.attr("align");
		if(align==null){
			return false;
		}
		else if("right".equals(align) || "center".equals(align)){ //右对齐或者居中对齐的不太可能是正文
			try{
				node.remove();
			}catch(java.lang.IllegalArgumentException e){}
			return true;
		}
		return false;
	}

	static boolean nameFilter(Element node){
		String name = node.attr("class");
		if(name==null){
			name = node.attr("id");
			if(name==null){
				return false;
			}
		}
		
		if(name.startsWith("footer")){ //脚注
			try{
				node.remove();
			}catch(java.lang.IllegalArgumentException e){}
			return true;
		}
		return false;
	}
	
	static ArrayList<Element> getBlocks(Element bodyNode){
		ArrayList<Element> nodes = new ArrayList<Element>();
		
		Elements elements = bodyNode.getAllElements();
		for(Element node:elements){
			if (!node.hasText()) {
				//System.out.println("删除"+node);
				node.remove();
			}

			String nodeName = node.nodeName();
			if("td".equals(nodeName) || "div".equals(nodeName)){
				if(alignFilter(node)){ //块被过滤掉了
					continue;
				}
				if(nameFilter(node)){
					continue;
				}
				nodes.add(node);
				//System.out.println("add node "+node.outerHtml());
			}
			//else if("div".equals(nodeName)){
			//	nodes.add(node);
			//}
			else if("center".equals(nodeName)){
				nodes.add(node);
			}
		}
		
		return nodes;
	}
	
	//看是否所有的p都位于同一个块中
	public static String getPBlock(Element bodyNode){
		Element parentNode = null;
		Elements ps = bodyNode.getElementsByTag("p");
		Element first = null;
		Element last = null;
		int count = 0;
		int total = 0;
		
		for(Element p:ps){
			if(p.hasAttr("class")){
				continue;
			}
			total++;
			//System.out.println("p: " + p);
		}
		
		for(Element p:ps){
			//System.out.println("p: " + p);
			if(parentNode == null){
				parentNode = p.parent();
				first = p;
				continue;
			}
			if(p.parent() != parentNode ){
				break;
			}
			else{
				last = p;
			}
			count++;
		}
		double ratio = (double) count / (double) total;
		//System.out.println("count: " + count+" ratio "+ratio);
		if(count>2 && ratio>0.62){
			return getText(parentNode, first, last);
		}
		return null;
	}
	
	public static String getText(Element parentNode,Element first,Element last){
		StringBuilder sb = new StringBuilder();
		Elements allE = parentNode.getAllElements();
		boolean inRange = false;
		for(Element e:allE){
			if(e==first){
				inRange = true;
			}
			if(inRange){
				sb.append(e.text());
			}
			if(last == e){
				break;
			}
		}
		return sb.toString();
	}
	
	public static String getBody(Element bodyNode){
		String content = getPBlock(bodyNode);
		if(content!=null){
			//System.out.println("get max node "+maxNode.outerHtml());
			return content;
		}
		
		// 开始遍历节点,进行去噪处理,抽取正文
		ArrayList<Element> nodes = getBlocks(bodyNode);
		
		//去掉ul
		removeUL(bodyNode);
		
		Iterator<Element> itr = nodes.iterator();
		HashMap<Element,Integer> signMap = new HashMap<Element,Integer>();
		
		while (itr.hasNext()) {
			Element node = itr.next();
			//System.out.println("tag: " + node.nodeName());
			int currentSigns = DetailPageExtractor.removeNoise(node);
			//看标点符号数量是否多于一定值
			if(currentSigns>3){
				signMap.put(node, currentSigns);
			}
		}
		
		Element maxNode = null;
		int maxSigns = -1;
		for(Entry<Element, Integer> e:signMap.entrySet()){
			Element node = e.getKey();
			//不包含有效DIV的才计数
			Elements subDivs = node.getElementsByTag("div");
			//System.out.println("subDiv num: " + subDivs.size());
			if(subDivs.size()>0){
				continue;
			}
			//System.out.println("node: " + node.outerHtml());
			int currentSigns = e.getValue();
			if(currentSigns>maxSigns){
				maxNode = node;
				maxSigns = currentSigns;
			}
		}
		
		if(maxNode != null){
			//System.out.println("maxSigns: " + maxSigns);
			//System.out.println("maxNode: " + maxNode.text());
			//System.out.println("body: " + bodyNode.text());
			//String realContent = maxNode.text();
			return clean(maxNode);
		}
		
		// 正文
		//String content = bodyNode.text();
		//System.out.println("body: " + content);
		
		return clean(bodyNode);
	}
	
	private static void removeUL(Element bodyNode) {
		Elements uls = bodyNode.getElementsByTag("ul");
		for(Element ul:uls){
			Elements lis = ul.getElementsByTag("li");
			if(repeatA(lis)){
				ul.remove();
			}
		}
	}

	//判断是否重复序列
	private static boolean repeatA(Elements lis) {
		Elements prevSeq = null;
		
		for(Element li:lis){
			Elements currentSeq = li.getAllElements();
			if(prevSeq==null){
				currentSeq=null;
				continue;
			}
			if(currentSeq.size()!=prevSeq.size()){
				continue;
			}
			for(int i=0;i<currentSeq.size();++i){
				Element prevE=prevSeq.get(i);
				Element curE=currentSeq.get(i);
				if(!prevE.nodeName().equals(curE.nodeName())){
					return false;
				}
			}
		}
		return true;
	}

	//避免Jsoup的bug
	static String clean(Element maxNode){
		//Elements e = maxNode.select("noscript"); //NOSCRIPT //"noscript"
		//System.out.println("删除 "+e.size());
		//e.remove();
		String realContent = maxNode.text();
		realContent=realContent.replaceAll("(?is)<script.*?>.*?</script>", "");
		realContent=realContent.replaceAll("(?is)<noscript.*?>.*?</noscript>", "");
		return realContent;
	}
	
	public static void getMeta(DetailInfo info,Document doc){
		//从meta信息中得到发布时间 <meta name="publishtime" content="2013-12-11">
		//从meta信息中得到来源 <meta name="source" content="通州时讯 王欢">
		Elements metaInfo = doc.select("meta");
		for (Element meta : metaInfo) {
			if((info.uptime == null) && ("publishtime".equalsIgnoreCase(meta.attr("name")) )){
				String pubtime = meta.attr("content");
				try {
					info.uptime = PageExtractor.formatter.parse(pubtime.trim());
				} catch (ParseException e) {
					e.printStackTrace();
				}
				//System.out.println("Name: " + meta.attr("name") + " - Content: "
				//		+ meta.attr("content"));
			}
			else if((info.source == null) && ("source".equalsIgnoreCase(meta.attr("name")))){
				info.source = meta.attr("content");
				if(info.source==null)
					continue;
				StringTokenizer st = new StringTokenizer(info.source);
				if(st.hasMoreTokens()){
					info.source = st.nextToken();
				}
				if(st.hasMoreTokens()){
					info.author = st.nextToken();
				}
				//System.out.println("Name: " + meta.attr("name") + " - Content: "
				//		+ meta.attr("content"));
			}
		}
	}

	//得到剩下的内容
	public static DetailInfo getRest(DetailInfo info, String htmlContent,Document doc){
		
		getMeta(info,doc);
		
		//看是否有完整的文章块
		Elements articles = doc.select("article");
		
		if(articles!=null){
			Element articleNode = articles.first();
			if(articleNode!=null){
				return ArticleExtractor.extract(articleNode,info);
			}
		}

		if(info.uptime == null){  //没找到发布时间
			//uptime = drawTime(htmlContent);
			info.uptime = DatePattern.getDate(htmlContent);
		}
		
		//TODO 使用提取表达式
		if(info.source == null){
			info.source = drawSource(htmlContent);
		}
		//System.out.println("\n\n\n"+htmlContent+"\n\n\n");

		// 取body
		Element bodyNode = doc.select("body").first();

		info.content = getBody(bodyNode);
		
		if(valid(info.content)){
			//提取的正文已经足够好了
			return info;
		}
		//从内容中提取并去掉摘要
		AdjList g = PageExtractor.ie.getLattice(info.content);
		
		FuncTree funcTree = PageExtractor.ie.getFuncTree(g, info.content);
		info.content = funcTree.findType("body");
		
		if(info.author==null){
			String candiAuthor = funcTree.findType("author");
			candiAuthor = StringUtils.strip(candiAuthor,"  　");
			if(candiAuthor!=null && PageExtractor.validAuthor(candiAuthor)){
				info.author = candiAuthor;
			}
		}
		//System.out.println("从树中发现作者:"+author);
		//String source = funcTree.findType("source");
		//System.out.println("从树中发现来源:"+source);
		
		//System.out.println("pre body:"+funcTree.preBody);
		//String body = funcTree.findType("body");
		//System.out.println("正文:"+body);
		return info;
	}
	
	public static boolean valid(String text){
		String word = BodyWords.contains(text);
		if(word==null){
			return true;
		}
		return false;
	}
	
	public static DetailInfo extract(String anchor, String url) throws Exception {
		String htmlContent = AutoEncodeHttpUtil.getHtml(new URL(url));
		if(htmlContent == null)
			return null;
		return extract(anchor,url,htmlContent);
	}
	
	public static DetailInfo extract(String anchor, String url,String htmlContent) throws Exception {
		Document doc = Jsoup.parse(htmlContent);
		//System.out.println("htmlContent.............\n"+htmlContent);
		String title = null;
		// 提取标题，处理长标题被截短的情况
		if(anchor.length()<18 && anchor.length()>1){
			title = anchor;
			//System.out.println("anchor设置为标题:"+title);
		}else{
			title = PageExtractor.getTitle(doc,anchor);
			if(title==null ||"".equals(title)){
				//System.out.println("h标题为空");
				title = drawTitle(doc);// 从网页内容中提取标题
			}
			//System.out.println("extract 标题 "+title );
		}
		//System.out.println("title "+title );
		DetailInfo info=new DetailInfo(title);
		
		//判断详细页是否有动态翻页链接
		info.isJSPage = JSClassify.isJSPage(doc);
		String nextPageURL = getNextURL(url,doc);
		info.nextPageURL = nextPageURL;
		
		return getRest(info,htmlContent,doc);
	}
}
