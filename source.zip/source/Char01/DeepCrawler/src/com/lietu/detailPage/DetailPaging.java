package com.lietu.detailPage;

/**
 * 详细页分页合并
 * 详细页分页的情况比较少见
 * @author luogang
 *
 */
public class DetailPaging {

}
