package com.lietu.detailPage;

import java.util.Date;

import org.apache.commons.lang3.StringUtils;

/**
 * 从详细页中提取的内容
 * 
 * @author luogang
 *
 */
public class DetailInfo {
	public String title; // 标题
	public Date uptime; // 发布时间
	public String source; // 来源
	public String content; // 正文
	public String author;// 作者
	public String nextPageURL;// 下一页网址，用于详细页翻页
	public boolean isJSPage;// 是否存在Javascript链接

	public DetailInfo(String t, Date u, String s, String au, String c,
			boolean isJS) {
		title = t;
		uptime = u;
		source = s;
		author = au;
		if (c != null) {
			// 去掉空格
			content = StringUtils.strip(c, "  　");
		}
		isJSPage = isJS;
	}

	public DetailInfo(String t) {
		title = t;
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("标题:" + title + "\n");
		if (uptime != null) {
			sb.append("发布时间:" + PageExtractor.formatter.format(uptime) + "\n");
		}
		if (source != null) {
			sb.append("来源:" + source + "\n");
		}
		if (author != null) {
			sb.append("作者:" + author + "\n");
		}
		sb.append("正文:" + content + "\n");
		sb.append("是否动态页面:" + isJSPage + "\n");

		if (nextPageURL != null) {
			sb.append("下一页:" + nextPageURL + "\n");
		}
		return sb.toString();
	}
}
