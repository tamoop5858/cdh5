package com.lietu.detailPage;

import org.apache.commons.lang3.StringUtils;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.lietu.ie.AdjList;
import com.lietu.ie.FuncTree;

/**
 * 根据 <article> 标签提取
 * @author luogang
 *
 */
public class ArticleExtractor {

	public static DetailInfo extract(Element articleNode, DetailInfo info) {
		//标题
		if(info.title==null){
			info.title = PageExtractor.getTitle(articleNode);
			/*Elements nodes = articleNode.getElementsByTag("h1");
			if(nodes!=null){
				Element titleNode = nodes.first();
				info.title= titleNode.text();
			}*/
		}
		
		//正文
		Elements nodes = articleNode.getElementsByClass("article-contents");
		if(nodes!=null){
			Element bodyNode = nodes.first();
			info.content = bodyNode.text();
		}
		
		//TODO 使用提取表达式
		if(info.uptime == null){  //没找到发布时间
			String content = articleNode.text();
			info.uptime = DatePattern.getDate(content);
		}
		
		if(info.source == null || info.content==null){
			String content = articleNode.text();
			AdjList g = PageExtractor.ie.getLattice(content);
			
			FuncTree funcTree = PageExtractor.ie.getFuncTree(g, content);
			
			if(info.author==null){
				String candiAuthor = funcTree.findType("author");
				candiAuthor = StringUtils.strip(candiAuthor,"  　");
				if(candiAuthor!=null && PageExtractor.validAuthor(candiAuthor)){
					info.author = candiAuthor;
				}
			}
			
			if(info.source == null){
				String candiSource = funcTree.findType("source");
				candiSource = StringUtils.strip(candiSource,"  　");
				if(candiSource!=null){
					info.source = candiSource;
					//System.out.println("来源:"+candiSource);
				}
			}
			
			if(info.content==null){
				info.content = funcTree.findType("body");
			}
		}
		
		return info;
	}

}
