package com.lietu.detailPage;

import java.util.HashSet;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * 判断是否存在Javascript链接
 * @author luogang
 *
 */
public class JSClassify {
	static HashSet<String> nosense = getNosense();
	
	public static HashSet<String> getNosense(){
		HashSet<String> ret = new HashSet<String>();
		ret.add("javascript:Dd('sendmail').submit();void(0);");
		ret.add("javascript:Print();");
		ret.add("javascript:window.close()");
		return ret;
	}

	//判断是否存在Javascript链接
	public static boolean isJSPage(Document doc){
		Elements links = doc.select("a[href]"); // 带有href属性的a标签
		for (Element link : links) { // 遍历每个链接
			String linkHref = link.attr("href"); // 得到href属性中的值，也就是url地址
			if(validJSLink(linkHref)){
				//System.out.println("validJSLink "+link);
				if(validText(link)){
					return true;
				}
				
			}
		}
		return false;
	}
	
	private static boolean validText(Element link) {
		String anchor = link.ownText();
		//System.out.println(anchor);
		if("[下一页]".equals(anchor) || "下一页".equals(anchor)){
			//System.out.println(link.attr("href"));
			return true;
		}
		return false;
	}

	public static boolean validJSLink(String linkHref){
		int pos = linkHref.indexOf("javascript:");
	
		if(pos>=0){
			if(nosense.contains(linkHref)){
				return false;
			}
			return true;
		}
		return false;
	}
	
}
