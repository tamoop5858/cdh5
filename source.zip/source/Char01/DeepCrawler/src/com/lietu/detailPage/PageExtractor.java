package com.lietu.detailPage;

import java.text.SimpleDateFormat;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.lietu.ie.TextExtractor;

/**
 * 网页提取的公用类
 * @author luogang
 *
 */
public class PageExtractor {
	public static TextExtractor ie = new TextExtractor("template.txt");
	public static SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

	//验证提取出来的作者是否合法
	public static boolean validAuthor(String author){
		if(author.length()>10)
			return false;
		return true;
	}
	
	//根据h1标签提取标题
	public static String getTitle(Element articleNode){
		Elements nodes = articleNode.getElementsByTag("h1");
		if(nodes!=null){
			Element titleNode = nodes.first();
			if(titleNode==null)
				return null;
			return titleNode.text();
		}
		return null;
	}

	//根据h1或者h2标签提取标题
	public static String getTitle(Document doc,String anchor){
		//TODo doc.title();
		//System.out.println("h1 h2 "); "h1"
		Elements nodes = doc.getElementsByTag("h1");
		
		if(nodes==null|| nodes.size()==0){
			nodes = doc.getElementsByTag("h2");
			//System.out.println("h2 ");
		}
		
		if(nodes==null|| nodes.size()==0){
			//System.out.println("return null ");
			return null;
		}
		
		String firstTitle = null;
		
		for(Element titleNode:nodes){
			if(titleNode.childNodes().size()>0 && titleNode.childNode(0).hasAttr("href")){
				continue;
			}
			String contentTitle = titleNode.text();
			//System.out.println("contentTitle "+contentTitle);
			if(anchor.equals(contentTitle)){
				return anchor;
			}
			if(firstTitle ==null){
				firstTitle = contentTitle;
			}
		}
		
		return firstTitle;
	}
}
