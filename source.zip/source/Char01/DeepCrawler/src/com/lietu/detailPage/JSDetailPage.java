package com.lietu.detailPage;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlAnchor;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

public class JSDetailPage {

	public static class JSDetailInfo{
		public String content; //通过解析js提取出来的正文
		public String nextURL;
		
		public JSDetailInfo(String c) {
			content = c;
		}

		public JSDetailInfo(String c, String n) {
			content = c;
			nextURL = n;
		}

		@Override
		public String toString() {
			return "JSDetailInfo [content=" + content + ", nextURL=" + nextURL
					+ "]";
		}
	}

	public static JSDetailInfo getContent(String url){
		final WebClient webClient = new WebClient(BrowserVersion.CHROME);
		webClient.getOptions().setTimeout(20000);
		webClient.getOptions().setJavaScriptEnabled(true);
		webClient.getOptions().setThrowExceptionOnScriptError(false);

		try {
			HtmlPage page = webClient.getPage(url);
			String content = page.getWebResponse().getContentAsString();
			HtmlAnchor nextAnchor = null;
			try{
				//page.getAnchorByHref(href)
				//page.getAnchors()
				nextAnchor = page.getAnchorByText("下一页");
			} catch (com.gargoylesoftware.htmlunit.ElementNotFoundException e){
				return new JSDetailInfo(content);
			}
			
			if(nextAnchor == null)
				return new JSDetailInfo(content);
			//System.out.println("下一页 Anchor: "+myAnchor);
			
			final HtmlPage newPage = nextAnchor.click();
			String nextURL = newPage.executeJavaScript("document.location").getJavaScriptResult().toString();
			//System.out.println("下一页 URL: "+nextURL);
			return new JSDetailInfo(content,nextURL);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
}
