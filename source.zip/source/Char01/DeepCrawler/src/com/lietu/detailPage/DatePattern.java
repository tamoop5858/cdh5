package com.lietu.detailPage;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DatePattern {
	public static Date getDate(String input) {
		if (input == null){
			return null;
		}
		
		Date date = null;
		String postdate = null;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");	
		Pattern p = Pattern.compile("\\d{2,4}-\\d{1,2}-\\d{1,2}\\s");
		Matcher m = p.matcher(input);
		if(m.find()){
			if (valid(m, input)){
				postdate = m.group();
				if(postdate != null){
					int pot = postdate.indexOf("-");
					if(pot == 2){
						postdate = "20"+postdate;
					}
					
					try {
						date = formatter.parse(postdate.trim());
					} catch (ParseException e) {
						e.printStackTrace();
					}
					return date;
				}
				//System.out.println(postdate);
			}
			
		}
		
		if(postdate == null || "".equals(postdate)){
			p = Pattern.compile("\\d{2,4}-\\d{1,2}-\\d{1,2}$");
			m = p.matcher(input);
			if(m.find()){
				if (valid(m, input)){
					postdate = m.group();
					if(postdate != null){
						int pot = postdate.indexOf("-");
						if(pot == 2){
							postdate = "20"+postdate;
						}
						try {
							date = formatter.parse(postdate.trim());
						} catch (ParseException e) {
							e.printStackTrace();
						}
						return date;
					}
					//System.out.println(postdate);
				}
			}
		}
		
		if(postdate == null || "".equals(postdate)){
			p = Pattern.compile("\\d{2,4}-\\d{1,2}-\\d{1,2}");
			m = p.matcher(input);
			if(m.find()){
				if (valid(m, input)){
					postdate = m.group();
					if(postdate != null){
						int pot = postdate.indexOf("-");
						if(pot == 2){
							postdate = "20"+postdate;
						}
						try {
							date = formatter.parse(postdate.trim());
						} catch (ParseException e) {
							e.printStackTrace();
						}
						return date;
					}
					//System.out.println(postdate);
				}
			}
		}
		
		if(postdate == null || "".equals(postdate)){
			p = Pattern.compile("\\d{2,4}/\\d{1,2}/\\d{1,2}\\s");
			m = p.matcher(input);
			if(m.find()){
				if (valid(m, input)){
					postdate = m.group();
					if(postdate != null){
						int pot = postdate.indexOf("/");
						if(pot == 2){
							postdate = "20"+postdate;
						}
						try {
							formatter = new SimpleDateFormat("yyyy/MM/dd");
							date = formatter.parse(postdate.trim());
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						return date;
					}
					//System.out.println(postdate);
				}
			}
		}
		
		if(postdate == null || "".equals(postdate)){
			p = Pattern.compile("\\d{2,4}/\\d{1,2}/\\d{1,2}$");
			m = p.matcher(input);
			if(m.find()){
				if (valid(m, input)){
					postdate = m.group();
					if(postdate != null){
						int pot = postdate.indexOf("/");
						if(pot == 2){
							postdate = "20"+postdate;
						}
						try {
							formatter = new SimpleDateFormat("yyyy/MM/dd");
							date = formatter.parse(postdate.trim());
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						return date;
					}
					//System.out.println(postdate);
				}
			}
		}
		
		if(postdate == null || "".equals(postdate)){
			p = Pattern.compile("\\d{2,4}\\.\\d{1,2}\\.\\d{1,2}");
			m = p.matcher(input);
			if(m.find()){
				if (valid(m, input)){
					postdate = m.group();
					if(postdate != null){
						int pot = postdate.indexOf(".");
						if(pot == 2){
							postdate = "20"+postdate;
						}
						try {
							formatter = new SimpleDateFormat("yyyy.MM.dd");
							date = formatter.parse(postdate.trim());
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						return date;
					}
					//System.out.println(postdate);
				}
			}
		}
		
		if(postdate == null || "".equals(postdate)){
			p = Pattern.compile("\\d{2,4}\\.\\d{1,2}\\.\\d{1,2}\\s");
			m = p.matcher(input);
			if(m.find()){
				if (valid(m, input)){
					postdate = m.group();
					if(postdate != null){
						int pot = postdate.indexOf(".");
						if(pot == 2){
							postdate = "20"+postdate;
						}
						try {
							formatter = new SimpleDateFormat("yyyy.MM.dd");
							date = formatter.parse(postdate.trim());
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						return date;
					}
					//System.out.println(postdate);
				}
			}
		}
		
		if(postdate == null || "".equals(postdate)){
			p = Pattern.compile("\\d{2,4}\\.\\d{1,2}\\.\\d{1,2}$");
			m = p.matcher(input);
			if(m.find()){
				if (valid(m, input)){
					postdate = m.group();
					if(postdate != null){
						int pot = postdate.indexOf(".");
						if(pot == 2){
							postdate = "20"+postdate;
						}
						try {
							formatter = new SimpleDateFormat("yyyy.MM.dd");
							date = formatter.parse(postdate.trim());
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						return date;
					}
					//System.out.println(postdate);
				}
			}
		}
		
		if(postdate == null || "".equals(postdate)){
			//\s 匹配任何空白字符，包括空格、制表符、换页符等等。等价于 [ \f\n\r\t\v]。
			//\S 匹配任何非空白字符。等价于 [^ \f\n\r\t\v]。
			p = Pattern.compile("\\d{2,4}年\\d{1,2}月\\d{1,2}日");
			m = p.matcher(input);
			if(m.find()){
				if (valid(m, input)){
					postdate = m.group();
					if(postdate != null){
						int pot = postdate.indexOf("年");
						if(pot == 2){
							postdate = "20"+postdate;
						}
						try {
							formatter = new SimpleDateFormat("yyyy年MM月dd日");
							date = formatter.parse(postdate.trim());
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						return date;
					}
				}
				//System.out.println(postdate);
			}
		}
		return date;
	}
	
	public static String toChangeDate(Date time){
		Date systemdate = new Date();
		SimpleDateFormat  formatter = new SimpleDateFormat(
		"yyyy-MM-dd'T'00:00:00.000'Z'");
		if(null != time){
			try{			

			if(systemdate.after(time)){
				return formatter.format(time);
			}
			}catch(Exception err){}
		}	
		//return formatter.format(systemdate);
		return null;
	}
	
	//根据位置检查日期是否合理
	public static boolean valid(Matcher m, String input) {
		return true;
		/*int i = input.length(); 
		int s = m.start();
		if (s < 60) {
			return true;
		} else if (i - s <60) {
			return true;
		} else if (i/s > 5) {
			return true;
		} else if (i/(i-s) > 5) {
			return true;
		}
		return false;*/
	}
}
