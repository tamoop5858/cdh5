package com.lietu.ie;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Trie tree Node
 * 
 * @author luogang
 * 
 */
public class TrieNode {
	public int id; //节点的唯一编号
	static int maxId=0;
	public ArrayList<Token> ruleName;  //规则名
	private Map<String, TrieNode> children = new HashMap<String, TrieNode>();

	public TrieNode() {
		id = maxId++;
	}

	@Override
	public int hashCode() {
		return id;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TrieNode other = (TrieNode) obj;
		if (id != other.id)
			return false;
		return true;
	}

	public boolean isTerminal() {
		return ruleName!=null;
	}

	public void setValue(ArrayList<Token> lhs) {
		this.ruleName = lhs;
	}

	public Map<String, TrieNode> getChildren() {
		return children;
	}
	
	public TrieNode next(String e){
		return children.get(e);
	}

	public void addChild(String r,TrieNode n){
		children.put(r, n);
	}
	
	public String toString(){
		return "id:"+String.valueOf(id);
		/*StringBuilder sb = new StringBuilder();
		if(ruleName!=null)
			sb.append("可结束节点:"+ruleName.toString());
		if(children!=null){
			sb.append("孩子:"+children.toString());
		}
		return sb.toString();*/
	}

	public ArrayList<Token> getNodeValue() {
		return ruleName;
	}
}
