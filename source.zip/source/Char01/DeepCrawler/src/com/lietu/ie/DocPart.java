package com.lietu.ie;

public class DocPart {
	public String text; //词本身
	public String type;  //词性

	public int start; //开始位置
	public int end; //结束位置

	public DocPart(String t,String y,int s,int e) {
		text = t;
		type = y;
		start = s;
		end = e;
	}

	@Override
	public String toString() {
		return "DocPart [text=" + text + ", type=" + type + ", start=" + start
				+ ", end=" + end + "]";
	}
}
