package com.lietu.ie;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

/**
 * 规则
 * @author luogang
 *
 */
public class Rule {
	public ArrayList<String> rhs = new ArrayList<String>(); // 右边的Token序列
	public ArrayList<Token> lhs = new ArrayList<Token>(); // 左边的Token序列
	public HashMap<String, HashSet<String>> words = new HashMap<String, HashSet<String>>();

	public void addWord(String w, String type) {
		HashSet<String> ret = words.get(w);
		if (ret == null) {
			ret = new HashSet<String>();
			ret.add(type);
			words.put(w, ret);
		} else {
			ret.add(type);
		}
	}

	@Override
	public String toString() {
		return "Rule [左边类型序列=" + lhs + ", 右边类型序列=" + rhs + ", 基本词=" + words + "]";
	}
}
