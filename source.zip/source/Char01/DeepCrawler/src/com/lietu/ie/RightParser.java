package com.lietu.ie;

import java.util.ArrayList;
import java.util.StringTokenizer;

public class RightParser {
	public final static String PositionSplit = "p-";
	
	public final static char startVariable='{';  //开始变量的符号 不用<和>的原因是为了避免和html标签冲突
	public final static char endVariable='}'; //结束变量的符号

	//不忽略空格
	public static Rule parse(String right, String ruleName) {
		if (right == null)
			return null;
		//right = right.trim();

		Rule rule = new Rule();

		int senLen = right.length();// 首先计算出传入的这句话的字符长度
		int i = 0;// i是用来控制匹配的起始位置的变量

		while (i < senLen)// 如果i小于此句话的长度就进入循环
		{
			//i = matchSpace(right, i); // 跳过空格
			String semName = ruleName + PositionSplit + i; // 根据规则加上编号生成语义类的名字
			int offset = matchOptionWords(right, i, semName, rule);
			if (offset > i) {
				i = offset + 1;
				rule.rhs.add(semName);
				rule.lhs.add(new Token(semName,false));
				continue;
			}
			offset = matchNormalWord(right, i);// 普通的词
			//System.out.println("i: " + i + " offset "+offset);
			if (offset > i)// 已经匹配上
			{
				// 下次匹配点在这个词之后
				int start = i;
				int end = offset;
				String word = right.substring(start, end);
				// logger.debug("word: " + word);
				rule.addWord(word, semName);
				i = offset;
				rule.rhs.add(semName);
				rule.lhs.add(new Token(semName,false));
				continue;
			}
			StringBuilder content = new StringBuilder();
			offset = matchRuleName(right, i, content);
			if (offset > i)// 匹配上规则
			{
				// 下次匹配点在这个词之后
				String rightRuleName = content.toString();
				//System.out.println("规则名: " + rightRuleName);
				i = offset + 1;
				//System.out.println("匹配规则后： i: " + i + " offset "+offset +" senLen "+senLen);
				rule.rhs.add(TernarySearchTrie.UNKNOW_TYPE);
				rule.lhs.add(new Token(rightRuleName,true));
				continue;
			}
		}

		return rule;
	}

	public static int matchRuleName(String sentence, int offset,
			StringBuilder bracketContent) {
		if (sentence.charAt(offset) == startVariable) {
			bracketContent.setLength(0); // 方括号中的内容
			int i = offset + 1;
			boolean endWithBracket = false;
			while (i < sentence.length()) {
				char c = sentence.charAt(i);
				if (c == endVariable) {
					endWithBracket = true;
					break;
				}
				bracketContent.append(c);
				i++;
			}

			if (endWithBracket && bracketContent.length() > 0) {
				return i;
			}
		}

		return offset;
	}

	public static int matchNormalWord(String sentence, int offset) {
		int i = offset;
		while (i < sentence.length()) {
			char c = sentence.charAt(i);
			if (c == '[' || c == startVariable) {
				break;
			}
			i++;
		}
		return i;
	}

	// 一个小的语义类
	public static int matchOptionWords(String sentence, int offset,
			String semName, Rule rule) {
		if (sentence.charAt(offset) == '[') {
			StringBuilder bracketContent = new StringBuilder(); // 方括号中的内容
			int i = offset + 1;
			boolean endWithBracket = false;
			while (i < sentence.length()) {
				char c = sentence.charAt(i);
				if (c == ']') {
					endWithBracket = true;
					break;
				}
				bracketContent.append(c);
				i++;
			}

			if (endWithBracket && bracketContent.length() > 0) {
				ArrayList<String> words = getOptionWords(bracketContent
						.toString());
				addWords(words, semName, rule);
				return i;
			}
		}

		return offset;
	}

	public static void addWords(ArrayList<String> words, String semName,
			Rule rule) {
		for (String w : words) {
			String type = semName; // 语义类的名字
			rule.addWord(w, type); // 终结符放入词典三叉树
		}
	}

	// 得到可选终结符和非终结符
	public static ArrayList<String> getOptionWords(String t) {
		// logger.debug("input " + t);
		ArrayList<String> words = new ArrayList<String>();
		StringTokenizer st = new StringTokenizer(t, "|"); // |分隔
		while (st.hasMoreTokens()) {
			String s = st.nextToken();
			// logger.debug("get OptionWord " + s);
			words.add(s);
		}
		return words;
	}
}
