package com.lietu.ie;

import java.util.ArrayDeque;
import java.util.ArrayList;

import org.apache.commons.lang3.StringUtils;

/**
 * 功能树
 * 用于提取详细页中的内容文本。例如，preBody 中包含 作者、日期、来源等
 * @author luogang
 *
 */
public class FuncTree {
	public ArrayList<TreeNode> tree; // 顶层节点数组
	public TreeNode preBody; //正文的前面部分，包含：作者、日期、来源等
	public int end;
	public String text;
	
	public FuncTree(String text){
		end = text.length();
		tree = new ArrayList<TreeNode>();
		preBody = new TreeNode();  //preBody作为孩子节点
		tree.add(preBody);
		this.text = text;
	}
	
	public void addChild(TreeNode e){
		preBody.lower.add(e);
		if(preBody.end<e.end){
			preBody.end = e.end;
		}
	}

	public void addChildren(ArrayList<TreeNode> e){
		preBody.lower.addAll(e);
	}
	
	public void finish(){
		//根据 preBody的最大的位置，增加 body节点
		String c = text.substring(preBody.end);
		
		//去掉空格
		c = StringUtils.strip(c,"  　");
		TreeNode body = new TreeNode(c,"body",preBody.end,end);
		tree.add(body);
	}

	// 找到类型集合中类型对应的词
	public String findType(String type) {
		for (TreeNode w : tree) {
			if (type.equals(w.type))
				return w.text;

			if (w.lower == null)
				continue;

			ArrayDeque<TreeNode> queue = new ArrayDeque<TreeNode>();
			queue.add(w);

			for (TreeNode headNode = queue.poll(); headNode != null; headNode = queue
					.poll()) {
				// logger.debug("head node "+headNode );

				for (int k = 0; k < headNode.lower.size(); ++k) {
					TreeNode currentNode = headNode.lower.get(k);

					if (type.equals(currentNode.type))
						return currentNode.text;

					if (currentNode.lower != null) {
						queue.add(currentNode);
					}
				}
			}
		}
		return null;
	}

}
