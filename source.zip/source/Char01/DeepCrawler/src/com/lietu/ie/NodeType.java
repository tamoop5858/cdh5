package com.lietu.ie;

public class NodeType {
	public String type; // 类型
	//public String termText;
	public int start;
	public int end;
	
	public NodeType(String t){
		type = t;
	}

	public NodeType(String type, int start, int end) {
		this.type = type;
		this.start = start;
		this.end = end;
	}
	
	@Override
	public String toString() {
		return "NodeType [type=" + type + ", start=" + start + ", end=" + end+ "]";
	}

}
