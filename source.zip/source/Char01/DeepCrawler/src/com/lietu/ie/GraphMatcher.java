package com.lietu.ie;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

import com.lietu.ie.Trie.NextValue;

/**
 * 匹配文本提取规则
 * @author luogang
 * @2014-1-26 
 */
public class GraphMatcher {

	public static class StatePair {
		ArrayList<NodeType> path;
		int s1; // 词序列中的状态，也就是位置
		TrieNode s2; // 词性Trie树中的状态，也就是节点

		public StatePair(ArrayList<NodeType> p, int state1, TrieNode state2) {
			path = p;
			this.s1 = state1;
			this.s2 = state2;
		}

		@Override
		public String toString() {
			return "StatePair [s1=" + s1 + ", s2=" + s2.id + "]";
		}

		@Override
		public int hashCode() {
			return s1 + 5*s2.id;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			StatePair other = (StatePair) obj;
			if (s1 != other.s1)
				return false;
			if (s2 == null) {
				if (other.s2 != null)
					return false;
			} else if (s2.id!=other.s2.id)
				return false;
			return true;
		}
	}

	public static final class MatchValue {
		public ArrayList<NodeType> posSeq; // 词性序列

		public MatchValue(ArrayList<NodeType> p, ArrayList<Token> tokens) {
			//System.out.println("path "+p+" tokens "+tokens);
			posSeq = new ArrayList<NodeType>();
			
			//根据在词图上走过的路，和涉及到的token序列合并UNKNOW类型
			//例如：
			//path [NodeType [type=2p-0, start=84, end=89], 
			//      NodeType [type=UNKNOW, start=89, end=106], 
			//      NodeType [type=UNKNOW, start=106, end=107], 
			//      NodeType [type=UNKNOW, start=107, end=112], 
			//      NodeType [type=UNKNOW, start=112, end=113], 
			//      NodeType [type=UNKNOW, start=113, end=120], 
			//      NodeType [type=UNKNOW, start=120, end=121], 
			//      NodeType [type=UNKNOW, start=121, end=126], 
			//      NodeType [type=UNKNOW, start=126, end=127], 
			//      NodeType [type=UNKNOW, start=127, end=130], 
			//      NodeType [type=2p-11, start=130, end=131]]
			//       tokens [Token [type=2p-0, toExtract=false], Token [type=办公时间, toExtract=true], Token [type=2p-11, toExtract=false]]
			int unknowEnd = -1; // 未知词缓存
			int unknowStart = -1; // 未知词缓存

			Iterator<Token> itr = tokens.iterator();
			for(NodeType n:p){
				//System.out.println("n "+n.type);
				//合并UNKNOW类型
				if(TernarySearchTrie.UNKNOW_TYPE.equals(n.type)){
					if(unknowStart<0){ //第一个未知词的开始位置
						unknowStart = n.start;
					}
					unknowEnd = n.end;
				}
				else if(unknowEnd>0){ //已经到普通类型了 
					//把未知词缓存加入到输出结果
					Token t = itr.next();
					posSeq.add(new NodeType(t.type,unknowStart,unknowEnd));
					
					//重置未知词缓存
					unknowEnd = -1;
					unknowStart = -1;
					
					//增加普通词
					t = itr.next();
					posSeq.add(new NodeType(t.type,n.start,n.end));
				}
				else{ //不需要合并未知类型
					Token t = itr.next();
					posSeq.add(new NodeType(t.type,n.start,n.end));
				}
			}
			
			//处理句尾的未知类型
			if(unknowEnd>0){
				Token t = itr.next();
				posSeq.add(new NodeType(t.type,unknowStart,unknowEnd));
			}
			
			//System.out.println("posSeq "+posSeq);
		}
		
		public String toString() {
			return " 词性序列:" + posSeq;
		}
	}

	/**
	 * 取得词图和规则树都可以向前进的步骤
	 * 
	 * @param edges
	 *            词图上的边
	 * @param s
	 *            规则树上的类型
	 * @return 共同的有效输入
	 */
	public static ArrayList<NextInput> intersection(CnTokenLinkedList edges,
			Set<String> s) {
		if(s==null)
			return null;
		ArrayList<NextInput> tmp = new ArrayList<NextInput>();
		
		for (CnToken x : edges) {
			if(x.types==null){
				continue;
			}
			//System.out.println("cn token "+x);
			for (String t : x.types) {
				//如果 Set<String> 中包括 UNKNOW，则 Set<String> 可以匹配任意类型
				if (s.contains(t) || s.contains(TernarySearchTrie.UNKNOW_TYPE)) { // 规则树上的类型包含词所属的类型
					NodeType nodeType = new NodeType(t,x.start,x.end);
					tmp.add(new NextInput(x.end, nodeType,x.termText));
				}
			}
		}
		return tmp;
	}

	/**
	 * 图的指定位置开始和trie树匹配
	 * 
	 * @param g
	 *            人名特征词图
	 * @param offset
	 *            开始位置
	 * @return 边序列，以及对应的类型序列
	 */
	public static MatchValue intersect(AdjList g, int offset,Trie ruleTrie) {
		Deque<StatePair> todo = new ArrayDeque<StatePair>(); // 存储遍历状态的堆栈
		HashSet<StatePair> visited = new HashSet<StatePair>();
		ArrayList<NodeType> path = new ArrayList<NodeType>(); // 类型序列
		
		HashMap<Integer,MatchValue> candidateValues = new HashMap<Integer,MatchValue>();
		//MatchValue candidateValue = null; //候选值，用于最长匹配
		
		todo.add(new StatePair(path, offset, ruleTrie.rootNode));
		MatchValue candidateValue;
		while (!todo.isEmpty()) { // 堆栈内容不空
			StatePair stackValue = todo.pop(); // 弹出堆栈
			//System.out.println("stackValue.s2 "+ stackValue.s2  +" stackValue.s1: "+stackValue.s1);
			visited.add(stackValue);
			
			// 取出图中当前节点对应的边
			CnTokenLinkedList edges = g.edges(stackValue.s1);
			if (edges == null){
				//System.out.println("edges is null");
				continue;
			}
			//System.out.println("edges is "+edges);

			// 取出树中当前节点对应的类型 
			TrieNode currNode = stackValue.s2;
			if(currNode==null){
				continue;
			}
			
			ArrayList<NextValue> nextValues = Trie.next(edges, currNode);
			for (NextValue nextValue : nextValues) {
				TrieNode state2 = nextValue.node;
				
				int end = nextValue.end;
				//System.out.println("end "+end +" stackValue.s1: "+stackValue.s1);
				ArrayList<NodeType> p = new ArrayList<NodeType>(
						stackValue.path); // 复制一个新的数组
				p.add(new NodeType(nextValue.type,nextValue.start,end)); // 把当前的Type加入到路径
				
				StatePair toAdd = new StatePair(p, end, state2);
				if(!visited.contains(toAdd) && !todo.contains(toAdd)){
					todo.add(toAdd); // 压入堆栈
					//System.out.println("add todo "+toAdd);
				}
				//System.out.println("state2 "+state2 + " state2 "+state2.isTerminal());
				if (state2!=null && state2.isTerminal()) { // 是可以结束的节点
					//System.out.println("end "+end);
					candidateValue = candidateValues.get(state2.id);
					if(candidateValue==null){
						//System.out.println("state2.getNodeValue() "+state2.getNodeValue() +" p "+p);
						candidateValue = new MatchValue(p,state2.getNodeValue());
						candidateValues.put(state2.id, candidateValue);
					}
					else if(candidateValue.posSeq.size()>p.size()){ //最长匹配
						//System.out.println("state2.getNodeValue() "+state2.getNodeValue() +" p "+p);
						candidateValue = new MatchValue(p,state2.getNodeValue());
						candidateValues.put(state2.id, candidateValue);
					}
				}
			}
		}

		return getLeftLongest(candidateValues);
	}
	
	public static MatchValue getLeftLongest(HashMap<Integer,MatchValue> candidateValues){
		MatchValue ret = null;
		for(Entry<Integer, MatchValue> e:candidateValues.entrySet()){
			if(ret == null){
				ret = e.getValue();
			}
			else{
				if(ret.posSeq.size()<e.getValue().posSeq.size()){
					ret = e.getValue();
				}
			}
		}
		return ret;
	}
}
