package com.lietu.ie;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

/**
 * 词性标注 Trie tree
 * 
 * @author luogang
 * 
 */
public class Trie implements Iterable<StackValue> {
	public TrieNode rootNode = new TrieNode(); // 根节点

	// 放入键/值对
	public void addRule(ArrayList<Token> lhs, ArrayList<String> rhs) {
		TrieNode currNode = rootNode; // 当前节点
		for (int i = 0; i < rhs.size(); ++i) { // 从前往后找键中的类型
			String c = rhs.get(i);
			Map<String, TrieNode> map = currNode.getChildren();
			currNode = map.get(c); // 向下移动当前节点
			if (currNode == null) {
				currNode = new TrieNode();
				map.put(c, currNode);
				if(c.equals(TernarySearchTrie.UNKNOW_TYPE)){  //UNKNOW_TYPE可以匹配任意多次
					currNode.addChild(TernarySearchTrie.UNKNOW_TYPE, currNode);
				}
			}
		}
		currNode.setValue(lhs); // 设置成可以结束的节点
	}
	
	// 根据键查找对应的值
	public boolean find(ArrayList<String> key) {
		TrieNode currNode = rootNode; // 当前节点
		for (int i = 0; i < key.size(); ++i) { // 从前往后找
			String t = key.get(i);
			Map<String,TrieNode> map = currNode.getChildren();
			currNode = map.get(t);// 向下移动当前节点
			if (currNode == null) {
				currNode = map.get(TernarySearchTrie.UNKNOW_TYPE);
				
				if(currNode == null){
					return false;
				}
			}
		}
		if (currNode.isTerminal()) {
			return true;
		}
		return false;
	}
	
	public static ArrayList<NextValue> next(CnTokenLinkedList edges,TrieNode currNode){
		Map<String,TrieNode> map = currNode.getChildren();
		ArrayList<NextValue> ret = new ArrayList<NextValue>();
		
		for (CnToken x : edges) {
			if(x.types==null){
				continue;
			}
			String realType=null; //实际匹配上的类型
			//System.out.println("cn token "+x);
			for (String t : x.types) {
				currNode = map.get(t);// 向下移动当前节点
				if (currNode == null) {
					//看是否有任意类型可供匹配
					currNode = map.get(TernarySearchTrie.UNKNOW_TYPE);
					
					if(currNode == null){
						continue;
					}
					else{
						realType=TernarySearchTrie.UNKNOW_TYPE;
					}
				}
				else{
					realType=t;
				}
				//add next value
				//ret.add(new NextValue(x.end,currNode,t));
				ret.add(new NextValue(x.start,x.end,currNode,realType));
			}
		}
		
		return ret;
	}
	
	public static class NextValue {
		public int start;
		public int end; // 词的结束位置,词图中的下一个状态编号
		public TrieNode node;
		public String type;
		
		//public NextValue(int s,int e, TrieNode n) {
		public NextValue(int s,int e, TrieNode n, String t) {
			start = s;
			end = e;
			node = n;
			type = t;
		}

		@Override
		public String toString() {
			return "NextValue [end=" + end + ", node=" + node + "]";
		}
		
	}

	public Set<String> edges(TrieNode currNode) {
		return currNode.getChildren().keySet();
	}

	public Trie() {
	}

	public static TrieNode next(TrieNode currNode, String edge) {
		return currNode.getChildren().get(edge);
	}

	private final class TrieIterator implements Iterator<StackValue> { // 用于迭代的类
		Stack<StackValue> stack = new Stack<StackValue>(); // 记录当前遍历到的位置
		ArrayDeque<StackValue> values = new ArrayDeque<StackValue>();

		public TrieIterator(final TrieNode begin) { // 构造方法
			stack.add(new StackValue(begin,new ArrayList<String>()));
		}

		public boolean hasNext() { // 是否还有更多的元素可以遍历
			return (!values.isEmpty()) || (!stack.isEmpty());
		}

		public StackValue next() { // 向下遍历
			if(!values.isEmpty()){
				return values.pop();
			}
			
			while (!stack.isEmpty()) {
				final StackValue stackValue = stack.pop();
				final Set<String> ret = edges(stackValue.node);
				for (final String edge : ret) {
					//同步向前遍历
					final TrieNode state1 = Trie.next(stackValue.node, edge);
					if (state1 == null) {
						continue;
					}
					final ArrayList<String> rhs = new ArrayList<String>(stackValue.rhs);
					rhs.add(edge);
					final StackValue s = new StackValue(state1,rhs);
					stack.add(s);
					if (state1.isTerminal()) {//可结束状态
						values.add(s);
					}
				}
				if(!values.isEmpty()){
					return values.pop();
				}
			}
			
			return null;
		}

		public void remove() { // 从集合中删除当前元素
			throw new UnsupportedOperationException(); // 不支持删除当前元素这个操作
		}
	}

	@Override
	public Iterator<StackValue> iterator() {
		return new TrieIterator(this.rootNode);
	}
}
