package com.lietu.ie;

import java.util.HashSet;

public class WordEntry {
	public String word; // 词
	public HashSet<String> types; // 词的各种词性

	public WordEntry(String w, String type) {
		word = w;
		types = new HashSet<String>();
		types.add(type);
	}

	public WordEntry(String w, HashSet<String> value) {
		word = w;
		types = value;
	}

	public void addType(String type) {
		if (types == null)
			types = new HashSet<String>();
		types.add(type);
	}

	public void addType(HashSet<String> value) {
		if (types == null)
			types = new HashSet<String>();
		types.addAll(value);
	}

}
