package com.lietu.ie;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;

/**
 * 内容不应该出现的词
 * @author luogang
 *
 */
public class BodyWords {
	private static BodyWords dic = null;

	/**
	 * 
	 * @return the singleton of basic dictionary
	 */
	public static BodyWords getInstance() {
		if (dic == null) {
			dic = new BodyWords();
		}
		return dic;
	}

	public final class TSTNode {
		public String data = null;

		protected TSTNode loNode;
		protected TSTNode eqNode;
		protected TSTNode hiNode;

		public char splitChar;

		public TSTNode(char key) {
			this.splitChar = key;
		}

		public String toString() {
			return "data  是" + data + "   spliter是" + splitChar;
		}

		public void addValue(String w) {
			data = w;
		}
	}

	public TSTNode rootNode;

	public BodyWords() {
		try {
			URI uri = BodyWords.class
					.getClass()
					.getResource("/com/lietu/ie/bodyWords.txt")
					.toURI();
			File txtFile = new File(uri);
			InputStream file = new FileInputStream(txtFile);
			// 打开输入流
			BufferedReader in = new BufferedReader(new InputStreamReader(file,
					"UTF-8"));
			String line;
			try {
				while (((line = in.readLine()) != null)) {
					if ("".equals(line))
						continue;
					// logger.debug(line);
					addWord(line);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (URISyntaxException e1) {
			e1.printStackTrace();
		}
	}

	//检查内容中不应该出现的词
	public static String contains(String text) {
		BodyWords dic = BodyWords.getInstance();

		int offset = 0;

		while (offset < text.length()) {
			String ret = dic.matchLong(text, offset);
			//logger.debug(question + " match:" + ret);
			if (ret != null) {
				return ret;
			}
			offset++;
		}
		return null;
	}

	public void addWord(String key) {
		if (rootNode == null) {
			rootNode = new TSTNode(key.charAt(0));
		}

		int charIndex = 0;
		TSTNode currentNode = rootNode;
		while (true) {
			int compa = (key.charAt(charIndex) - currentNode.splitChar);
			if (compa == 0) {
				charIndex++;
				if (charIndex == key.length()) {
					currentNode.addValue(key); // 增加值到节点
					break;
				}
				if (currentNode.eqNode == null) {
					currentNode.eqNode = new TSTNode(key.charAt(charIndex));
				}
				currentNode = currentNode.eqNode;
			} else if (compa < 0) {
				if (currentNode.loNode == null) {
					currentNode.loNode = new TSTNode(key.charAt(charIndex));
				}
				currentNode = currentNode.loNode;
			} else {
				if (currentNode.hiNode == null) {
					currentNode.hiNode = new TSTNode(key.charAt(charIndex));
				}
				currentNode = currentNode.hiNode;
			}
		}
	}

	public String matchLong(String key, int offset) {
		String ret = null;
		if (key == null || rootNode == null || "".equals(key)) {
			return ret;
		}
		TSTNode currentNode = rootNode;
		int charIndex = offset;
		while (true) {
			if (currentNode == null) {
				return ret;
			}
			int charComp = key.charAt(charIndex) - currentNode.splitChar;

			if (charComp == 0) {
				charIndex++;

				if (currentNode.data != null) {
					ret = currentNode.data; // 候选最长匹配词
				}
				if (charIndex == key.length()) {
					return ret; // 已经匹配完
				}
				currentNode = currentNode.eqNode;
			} else if (charComp < 0) {
				currentNode = currentNode.loNode;
			} else {
				currentNode = currentNode.hiNode;
			}
		}
	}

}
