package com.lietu.ie;

/**
 * 左边的词序列
 * @author luogang
 *
 */
public class Token {
	public String type;//标注类型
	public boolean toExtract;//要提取的类型
	
	public Token(String r, boolean b) {
		type = r;
		toExtract = b;
	}
	
	public Token(String r) {
		type = r;
	}

	@Override
	public String toString() {
		return "Token [type=" + type + ", toExtract=" + toExtract + "]";
	}
}
