package com.lietu.ie;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.Stack;
import java.util.Map.Entry;

/**
 * 词典树
 * @author luogang
 *
 */
public class TernarySearchTrie implements Iterable<String>{
	public static final String UNKNOW_TYPE = "UNKNOW";

	public final static class TSTNode {
		public WordEntry data;

		protected TSTNode left;
		protected TSTNode mid;
		protected TSTNode right;

		public char spliter;

		public TSTNode(char key) {
			this.spliter = key;
		}

		public TSTNode() {
		}

		public String toString() {
			return "data: " + data + "   spliter:" + spliter;
		}

		public void addWord(String word, String type) {
			if(data==null){
				data = new WordEntry(word,type);
			}
			else{
				data.addType(type);
			}
		}

		public void addWord(String word, HashSet<String> value) {
			if(data==null){
				data = new WordEntry(word,value);
			}
			else{
				data.addType(value);
			}
		}

		public boolean isTerminal() {
			return (data!=null);
		}
	}

	public TSTNode rootNode;

	public TernarySearchTrie() {
	}
	
	public void addWords(HashMap<String,HashSet<String>> words) {
		for(Entry<String, HashSet<String>> e:words.entrySet()){
			TSTNode currentNode = creatTSTNode(e.getKey());
			currentNode.addWord(e.getKey(),e.getValue());
		}
	}

	public void addWord(String word, String type) {
		TSTNode currentNode = creatTSTNode(word);
		currentNode.addWord(word,type);
	}

	// 创建一个结点
	public TSTNode creatTSTNode(String key) throws NullPointerException,
			IllegalArgumentException {
		if (key == null) {
			throw new NullPointerException("空指针异常");
		}
		int charIndex = 0;
		if (rootNode == null) {
			rootNode = new TSTNode(key.charAt(0));
		}
		TSTNode currentNode = rootNode;
		while (true) {
			int compa = (key.charAt(charIndex) - currentNode.spliter);
			if (compa == 0) {
				charIndex++;
				if (charIndex == key.length()) {
					return currentNode;
				}
				if (currentNode.mid == null) {
					currentNode.mid = new TSTNode(key.charAt(charIndex));
				}
				currentNode = currentNode.mid;
			} else if (compa < 0) {
				if (currentNode.left == null) {
					currentNode.left = new TSTNode(key.charAt(charIndex));
				}
				currentNode = currentNode.left;
			} else {
				if (currentNode.right == null) {
					currentNode.right = new TSTNode(key.charAt(charIndex));
				}
				currentNode = currentNode.right;
			}
		}
	}

	public static final class MatchRet {
		public WordEntry wordEntry; //词类型
		public int end;  //结束位置
		
		public String toString(){
			return wordEntry+" end:"+end;
		}
	}

	public void matchWord(String key, int offset, MatchRet ret) {
		ret.wordEntry = null;
		if (key == null || rootNode == null || "".equals(key)) {
			return;
		}
		TSTNode currentNode = rootNode;
		int charIndex = offset;
		while (true) {
			if (currentNode == null) {
				return;
			}
			int charComp = key.charAt(charIndex) - currentNode.spliter;

			if (charComp == 0) {
				charIndex++;

				if (currentNode.data != null) {
					ret.wordEntry = currentNode.data; // 候选最长匹配词
					ret.end = charIndex;
				}
				if (charIndex == key.length()) {
					return; // 已经匹配完
				}
				currentNode = currentNode.mid;
			} else if (charComp < 0) {
				currentNode = currentNode.left;
			} else {
				currentNode = currentNode.right;
			}
		}
	}

	public int nodeNums(){
		TSTNode currNode = rootNode;
		if (currNode == null)
			return 0;
		int count = 0;
		//logger.debug("count ");
		// 用于存放节点数据的队列
		Deque<TSTNode> queueNode = new ArrayDeque<TSTNode>();
		queueNode.addFirst(currNode);

		// 广度优先遍历所有树节点，将其加入至数组中
		while (!queueNode.isEmpty()) {
			count++;
			// 取出队列第一个节点
			currNode = queueNode.pollFirst();

			// 处理左子节点
			if (currNode.left != null) {
				queueNode.addLast(currNode.left);
			}

			// 处理中间子节点
			if (currNode.mid != null) {
				queueNode.addLast(currNode.mid);
			}

			// 处理右子节点
			if (currNode.right != null) {
				queueNode.addLast(currNode.right);
			}
		}
		
		return count;
	}

	private Set<Character> edges(TSTNode currNode) {
		if(currNode==null||currNode.mid==null)
			return null;
		HashSet<Character> ret = new HashSet<Character>();
		Deque<TSTNode> queueNode = new ArrayDeque<TSTNode>();
		queueNode.addFirst(currNode.mid);
		
		// 广度优先遍历所有树节点，将其加入至数组中
		while (!queueNode.isEmpty()) {
			// 取出队列第一个节点
			currNode = queueNode.pollFirst();
			ret.add(currNode.spliter);

			// 处理左子节点
			if (currNode.left != null) {
				queueNode.addLast(currNode.left);
			}

			// 处理中间子节点
			if (currNode.mid != null) {
				queueNode.addLast(currNode.mid);
			}

			// 处理右子节点
			if (currNode.right != null) {
				queueNode.addLast(currNode.right);
			}
		}
		
		return ret;
	}

	public TSTNode next(TSTNode stackValue, char edge) {
		TSTNode currentNode = stackValue.mid;
		while (true) {
			if (currentNode == null) {
				return null;
			}
			int charComp = edge - currentNode.spliter;

			if (charComp == 0) {
				return currentNode;
			} else if (charComp < 0) {
				currentNode = currentNode.left;
			} else {
				currentNode = currentNode.right;
			}
		}
	}
	
	private final class TrieIterator implements Iterator<String> { // 用于迭代的类
		Stack<StackValue> stack = new Stack<StackValue>(); // 记录当前遍历到的位置
		TernarySearchTrie trie;
		ArrayDeque<String> values = new ArrayDeque<String>();

		public TrieIterator(final TernarySearchTrie.TSTNode begin,final TernarySearchTrie t) { // 构造方法
			stack.add(new StackValue(begin));
			trie = t;
		}

		public boolean hasNext() { // 是否还有更多的元素可以遍历
			return (!values.isEmpty()) || (!stack.isEmpty());
		}

		public String next() { // 向下遍历
			if(!values.isEmpty()){
				return values.pop();
			}
			
			while (!stack.isEmpty()) {
				final StackValue stackValue = stack.pop();
				final Set<Character> ret = edges(stackValue.node);
				if(ret==null)
					continue;
				for (char edge : ret) {
					//同步向前遍历
					final TSTNode state1 = trie.next(stackValue.node, edge);
					if (state1 == null) {
						continue;
					}
					final StringBuilder rhs = new StringBuilder(stackValue.rhs);
					rhs.append(edge);
					final StackValue s = new StackValue(state1,rhs);
					stack.add(s);
					if (state1.isTerminal()) {//可结束状态
						values.add(rhs.toString());
					}
				}
				if(!values.isEmpty()){
					return values.pop();
				}
			}
			
			return null;
		}

		public void remove() { // 从集合中删除当前元素
			throw new UnsupportedOperationException(); // 不支持删除当前元素这个操作
		}
	}

	public final static class StackValue {
		public TSTNode node;
		public StringBuilder rhs;

		public StackValue(TSTNode n) {
			node = n;
			rhs = new StringBuilder();
			rhs.append(n.spliter);
		}

		public StackValue(TSTNode n, StringBuilder r) {
			node = n;
			rhs = r;
		}

		public String toString() {
			return node.toString() + " rhs:" + rhs;
		}
	}

	@Override
	public Iterator<String> iterator() {
		return new TrieIterator(this.rootNode,this);
	}

	public boolean matchAll(String sentence, int offset,
			ArrayList<WordEntry> wordMatch) {
		wordMatch.clear(); // 清空返回数组中的词
		if (sentence == null || rootNode == null || "".equals(sentence)) {
			return false;
		}
		//logger.debug("offset "+offset) ;
		TSTNode currentNode = rootNode;
		int charIndex = offset;
		while (true) {
			if (currentNode == null) {
				if (wordMatch.size() > 0) {
					return true;
				}
				return false;
			}
			int charComp = sentence.charAt(charIndex) - currentNode.spliter;
			if (charComp == 0) {
				if (currentNode.data != null) {
					// logger.debug(currentNode.data) ;
					wordMatch.add(currentNode.data);
				}
				//logger.debug("charIndex "+charIndex) ;
				charIndex++; // 继续往前找
				if (charIndex >= sentence.length()) {
					if (wordMatch.size() > 0) {
						return true;
					}
					return false;
				}
				currentNode = currentNode.mid;
			} else if (charComp < 0) {
				currentNode = currentNode.left;
			} else {
				currentNode = currentNode.right;
			}
		}
	}
}
