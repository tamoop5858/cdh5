package com.lietu.ie;

/**
 * 对块分类的凭证
 * @author luogang
 *
 */
public class Evidence {
	public int signs; //标点符号的个数，判断正文块简单的方法是：取标点符号数量最多的块
	public int copyRightTextNum; //
}
