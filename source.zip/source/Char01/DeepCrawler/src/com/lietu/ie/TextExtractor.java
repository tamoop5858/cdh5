package com.lietu.ie;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;

/**
 * 
 * 通过标注文本提取信息
 * 
 * @author luogang
 * 
 */
public class TextExtractor {
	public TernarySearchTrie dic; // 基本词和对应的类型
	public Trie rule; // 文法树

	public TextExtractor() {
		dic = new TernarySearchTrie(); // 基本词和对应的类型
		rule = new Trie();
	}

	// 加载文法文件
	public TextExtractor(String grammarFile) {
		dic = new TernarySearchTrie(); // 基本词和对应的类型
		rule = new Trie();

		String fileName = "/com/lietu/ie/" + grammarFile;
		URL url = TextExtractor.class.getClass().getResource(fileName);

		try {
			BufferedInputStream stream = new BufferedInputStream(
					url.openStream(), 256);

			String charSet = "UTF-8"; // "GBK"
			Reader reader = new InputStreamReader(stream, charSet);// 打开输入流

			BufferedReader read = new BufferedReader(reader);
			String line;
			int count = 0;
			while ((line = read.readLine()) != null) {
				// System.out.println(line);
				String ruleName = String.valueOf(count++);
				String right = line;
				Rule rightRule = add(ruleName, right);
				//System.out.println("规则名: " + ruleName + " 规则内容: " +rightRule);
			}
			read.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// 加载数组形式的模板
	public TextExtractor(ArrayList<String> grammarContent) {
		dic = new TernarySearchTrie(); // 基本词和对应的类型
		rule = new Trie();
		int count = 0;
		for (String line : grammarContent) {
			String ruleName = String.valueOf(count++);
			String right = line;
			add(ruleName, right);
		}
	}

	public Rule add(String ruleName, String right) {
		Rule rightRule = RightParser.parse(right, ruleName);
		// System.out.println("规则名: " + ruleName + " 规则内容: " + rightRule);
		rule.addRule(rightRule.lhs, rightRule.rhs);
		dic.addWords(rightRule.words);
		return rightRule;
	}

	public AdjList getLattice(String text) { // 返回切分词图
		int sLen = text.length();// 字符串长度
		AdjList g = new AdjList(sLen);// 存储所有被切分的可能的词

		ArrayList<WordEntry> wordMatch = new ArrayList<WordEntry>();
		StringBuilder unknowBuffer = new StringBuilder(); // 未知词缓存
		// 已经处理的最大位置
		int maxEnd = 0;
		// 生成切分词图
		for (int i = 0; i < sLen; ++i) {
			// logger.debug("i:"+i);
			boolean match = dic.matchAll(text, i, wordMatch);// 到词典中查询

			if (match)// 已经匹配上
			{
				for (WordEntry word : wordMatch) {
					// logger.debug(word);
					int end = i + word.word.length();// 词的开始位置
					if (end > maxEnd) {
						maxEnd = end;
					}
					g.addEdge(new CnToken(i, end, word.word, word.types));
				}
				if (unknowBuffer.length() > 0) {
					// 增加未知词
					String word = unknowBuffer.toString();
					int start = i - word.length();
					HashSet<String> wordTypes = new HashSet<String>();
					wordTypes.add(TernarySearchTrie.UNKNOW_TYPE);
					if (start > maxEnd) {
						maxEnd = start;
					}
					g.addEdge(new CnToken(start, i, word, wordTypes));
					unknowBuffer.setLength(0); // 重置缓存
				}
			} else if (i >= maxEnd) {
				unknowBuffer.append(text.charAt(i));
			}
		}
		// 处理句尾没有匹配到的词
		if (unknowBuffer.length() > 0) {
			// 增加未知词
			String word = unknowBuffer.toString();
			int start = text.length() - word.length();

			HashSet<String> wordTypes = new HashSet<String>();
			wordTypes.add(TernarySearchTrie.UNKNOW_TYPE);
			g.addEdge(new CnToken(start, text.length(), word, wordTypes));
			unknowBuffer.setLength(0); // 重置缓存
		}
		// System.out.println("getLattice g :"+g);

		return g;
	}

	public FuncTree getFuncTree(AdjList g, String text) {
		//System.out.println("text "+text);
		FuncTree funcTree = new FuncTree(text);

		// 提取信息
		for (int offset = 0; offset < text.length(); ++offset) {
			GraphMatcher.MatchValue match = GraphMatcher.intersect(g, offset,
					rule);
			if (match == null) {
				continue;
			}
			//System.out.println("匹配结果 "+match);
			for (int i = 0; i < match.posSeq.size(); ++i) {
				NodeType n = match.posSeq.get(i);
				//System.out.println("NodeType "+n);
				TreeNode treeNode = new TreeNode(text.substring(n.start,
						n.end), n.type, n.start, n.end);
				funcTree.addChild(treeNode);
				//System.out.println("new part word:"+treeNode);
			}
		}
		funcTree.finish();
		return funcTree;
	}

}
