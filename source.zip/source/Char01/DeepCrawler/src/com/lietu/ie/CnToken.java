/*
 * Created on 2005-9-7
 *
 */
package com.lietu.ie;

import java.util.HashSet;

/**
 * 
 * 有向边
 */
public class CnToken {
	public String termText;
	public HashSet<String> types; //词的各种词性 
	public int start;
	public int end;
	
	public CnToken(int vertexFrom, int vertexTo, String word) {
		start = vertexFrom;
		end = vertexTo;
		termText = word;
	}
	
	public CnToken(int vertexFrom, int vertexTo, String word,HashSet<String> t) {
		start = vertexFrom;
		end = vertexTo;
		termText = word;
		HashSet<String> typs = new HashSet<String>(t.size());
		for(String wt:t){
			typs.add(wt);
		}
		types = typs;
	}
	
	public CnToken(int vertexFrom, int vertexTo, String word,String n) {
		start = vertexFrom;
		end = vertexTo;
		termText = word;
		HashSet<String> types = new HashSet<String>(1);
		types.add(n);
		this.types = types;
	}
	
	public String toString() {
		return "text:" + termText + " start:" + start + " end:" + end+" types:"+types;
	}

}