package com.lietu.ie;

import java.util.ArrayList;

/**
 * 功能树中的节点
 * @author luogang
 *
 */
public class TreeNode {
	public String text; //词本身
	public String type;  //词性

	public int start; //开始位置
	public int end; //结束位置

	public ArrayList<TreeNode> lower; //用来得到树结构的下层

	public TreeNode() {
		lower = new ArrayList<TreeNode>();
	}

	public TreeNode(String t,String y,int s,int e) {
		text = t;
		type = y;
		start = s;
		end = e;
	}

	@Override
	public String toString() {
		return "TreeNode [text=" + text + ", type=" + type + ", start=" + start
				+ ", end=" + end + ", lower=" + lower + "]";
	}
	
}
