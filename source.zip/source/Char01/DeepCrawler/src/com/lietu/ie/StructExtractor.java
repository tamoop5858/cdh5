package com.lietu.ie;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import org.apache.commons.lang3.StringUtils;

import com.lietu.ie.GraphMatcher.MatchValue;

/**
 * 
 * 从文本中提取结构化信息，
 * 提取方法是：依据上下文规则
 * 例如从http://eservice.beijing.gov.cn/sj/xzfwzy/fwsx/201209/t20120912_105347.htm
 * 提取结构化信息
 * @author luogang
 *
 */
public class StructExtractor {

	public TernarySearchTrie dic; // 基本词和对应的类型
	public Trie rule; // 文法树

	// 加载数组形式的模板
	public StructExtractor(ArrayList<String> grammarContent) {
		dic = new TernarySearchTrie(); // 基本词和对应的类型
		rule = new Trie();
		int count = 0;
		for (String line : grammarContent) {
			String ruleName = String.valueOf(count++);
			String right = line;
			add(ruleName, right);
		}
	}
	
	public StructExtractor(String right) {
		dic = new TernarySearchTrie(); // 基本词和对应的类型
		rule = new Trie();
		String ruleName = "0";
		add(ruleName, right);
	}

	public Rule add(String ruleName, String right) {
		Rule rightRule = RightParser.parse(right, ruleName);
		// System.out.println("规则名: " + ruleName + " 规则内容: " + rightRule);
		rule.addRule(rightRule.lhs, rightRule.rhs);
		dic.addWords(rightRule.words);
		return rightRule;
	}

	public AdjList getLattice(String text) { // 返回切分词图
		int sLen = text.length();// 字符串长度
		AdjList g = new AdjList(sLen);// 存储所有被切分的可能的词

		ArrayList<WordEntry> wordMatch = new ArrayList<WordEntry>();
		StringBuilder unknowBuffer = new StringBuilder(); // 未知词缓存
		// 已经处理的最大位置
		int maxEnd = 0;
		// 生成切分词图
		for (int i = 0; i < sLen; ++i) {
			// logger.debug("i:"+i);
			boolean match = dic.matchAll(text, i, wordMatch);// 到词典中查询

			if (match)// 已经匹配上
			{
				for (WordEntry word : wordMatch) {
					// logger.debug(word);
					int end = i + word.word.length();// 词的开始位置
					if (end > maxEnd) {
						maxEnd = end;
					}
					g.addEdge(new CnToken(i, end, word.word, word.types));
				}
				if (unknowBuffer.length() > 0) {
					// 增加未知词
					String word = unknowBuffer.toString();
					int start = i - word.length();
					HashSet<String> wordTypes = new HashSet<String>();
					wordTypes.add(TernarySearchTrie.UNKNOW_TYPE);
					if (start > maxEnd) {
						maxEnd = start;
					}
					g.addEdge(new CnToken(start, i, word, wordTypes));
					unknowBuffer.setLength(0); // 重置缓存
				}
			} else if (i >= maxEnd) {
				unknowBuffer.append(text.charAt(i));
			}
		}
		// 处理句尾没有匹配到的词
		if (unknowBuffer.length() > 0) {
			// 增加未知词
			String word = unknowBuffer.toString();
			int start = text.length() - word.length();

			HashSet<String> wordTypes = new HashSet<String>();
			wordTypes.add(TernarySearchTrie.UNKNOW_TYPE);
			g.addEdge(new CnToken(start, text.length(), word, wordTypes));
			unknowBuffer.setLength(0); // 重置缓存
		}
		// System.out.println("questionGrammar g :"+g);

		return g;
	}
	
	public HashMap<String, String> match(String text,HashSet<String> keys){
		AdjList g = getLattice(text);
		//System.out.println(g);
		
		//根据模板切分文本
		ArrayList<DocPart> interest = getInterest(g,text);
		
		return StructExtractor.extract(keys, interest);
	}
	
	public String find(String text,String key){
		AdjList g = getLattice(text);
		//System.out.println(g);
		
		//根据模板切分文本
		ArrayList<DocPart> interest = getInterest(g,text);
		
		for (DocPart d : interest) {
			if (key.equals(d.type)) {
				return d.text;
			}
		}
		
		return null;
	}

	public ArrayList<DocPart> getInterest(AdjList g, String text) {
		ArrayList<DocPart> docParts = new ArrayList<DocPart>(); // 顶层节点数组

		// 提取信息
		for (int offset = 0; offset < text.length(); ++offset) {
			MatchValue match = GraphMatcher.intersect(g, offset, rule);
			if(match==null){
				continue;
			}
			// logger.debug("匹配结果 "+match);
			//System.out.println("offset " + offset + " " + match);
			// System.out.println("new word:"+sentence.substring(m.start,
			// m.end));
			for (int i = 0; i < match.posSeq.size(); ++i) {
				// NodeType n = m.posSeq.get(i);
				NodeType token = match.posSeq.get(i);
				DocPart treeNode = new DocPart(text.substring(token.start,
						token.end), token.type, token.start, token.end);
				docParts.add(treeNode);
				//System.out.println(treeNode);
				// System.out.println("new part word:"+sentence.substring(token.start,token.end));
			}
		}

		return docParts;
	}

	public static HashMap<String, String> extract(HashSet<String> keys,
			ArrayList<DocPart> interest) {
		HashMap<String, String> data = new HashMap<String, String>(); // 提取出来的数据

		for (DocPart d : interest) {
			if (!keys.contains(d.type)) { // 如果对这个键不感兴趣，则忽略它
				continue;
			}
			String value = d.text;
			if (!StringUtils.isEmpty(value)) {
				data.put(d.type, value); // 填入键/值对
			}
		}
		return data;
	}
	
	// 找到类型集合中类型对应的词
	public static String findType(String type, ArrayList<DocPart> interest) {
		for (DocPart d : interest) {
			if (type.equals(d.type)) {
				return d.text;
			}
		}
		return null;
	}
}
