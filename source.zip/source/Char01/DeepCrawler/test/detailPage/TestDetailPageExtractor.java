package detailPage;

import junit.framework.TestCase;

import com.lietu.detailPage.DetailInfo;
import com.lietu.detailPage.DetailPageExtractor;

public class TestDetailPageExtractor extends TestCase {

	public static void main(String[] args) throws Exception {
		testTitle();
		//testTitle2();
		//testTitle3();
		//testBasic();
		//testTitle4();
		//testPaging();
	}
	
	public static void testBasic() throws Exception {
		String url = //"http://www.bjtzh.gov.cn/n95/n534/n700/c9169697/content.html";
		// "http://www.bjtzh.gov.cn/n95/n534/n700/c9175359/content.html";
				//"http://www.zhinengjiaotong.com/news/show-459544.html";
				//"http://www.zhinengjiaotong.com/news/show-460245.html";
				//"http://news.bitauto.com/abroad/20140330/1106390606.html";
				//"http://news.bitauto.com/xcpd/20140219/1406353971.html";
		 ///"http://www.zhinengjiaotong.com/news/show-460192.html";
		 //"http://www.zhinengjiaotong.com/news/show-460548.html";
				//"http://www.zhinengjiaotong.com/news/show-460225.html";
		//"http://www.zhinengjiaotong.com/news/show-460493.html";
				//"http://www.zhinengjiaotong.com/news/show-460493.html";
				//"http://sc.sina.com.cn/news/z/2014-02-13/0832178700.html";
				//"http://www.zhinengjiaotong.com/news/show-459923.html";
		//"http://www.zhinengjiaotong.com/news/show-456707.html";
				//"http://zfxxgk.beijing.gov.cn/columns/91/5/469206.html";
				//"http://baby.sina.com.cn/news/2014-05-04/092863983.shtml";
				//"http://hebei.hebnews.cn/2014-04/18/content_3891586.htm";
				//"http://zhengwu.beijing.gov.cn/rsgz/rsrm/t1217906.htm";
				"http://auto.sohu.com/20131202/n391081185.shtml";
		//String content = HttpUtil.getHtml(new URL(url));
		//System.out.println(content);
		// HttpUtil.downHtml(url);
		// DetailExtractor extarct = new DetailExtractor();
		DetailInfo ret = DetailPageExtractor.extract(url);
		System.out.println(ret);
		
		//System.out.println(".....................");
		//String text = Jsoup.clean(ret.content,Whitelist.none());
		//System.out.println(text);
	}
	
	public static void testPaging()throws Exception{
		String url = "http://hebei.hebnews.cn/2014-04/30/content_3913585.htm";
		//String content = HttpUtil.getHtml(new URL(url));
		//System.out.println(content);
		// HttpUtil.downHtml(url);
		// DetailExtractor extarct = new DetailExtractor();
		DetailInfo ret = DetailPageExtractor.extract(url);
		System.out.println(ret);
	}
	
	public static void testTitle() throws Exception {
		//String url ="http://news.bitauto.com/xcpd/20140203/1906341423.html";
		//String anchor="2014新车展望之紧凑型车 奔驰CLA领衔";
		//String url ="http://auto.sohu.com/20131202/n391081185.shtml";
		//String anchor="推荐手动/自动家尊版 奇瑞瑞虎5全系导购";
		
		String url ="http://auto.sohu.com/20140522/n399872219.shtml";
		String anchor="第1页 :全新家族式前脸，外观设计保守";
		
		DetailInfo news = DetailPageExtractor.extract(anchor,url);
		System.out.println(news);
	}

	public static void testTitle2() throws Exception {
		String url ="http://www.zhinengjiaotong.com/news/show-186070.html";
		String anchor="关于《公路工程技术标准》（JTG B01-2003）电子版的说明";
		DetailInfo news = DetailPageExtractor.extract(anchor,url);
		System.out.println(news);
	}
	
	public static void testTitle3() throws Exception {
		String url ="http://zhengwu.beijing.gov.cn/zwzt/jpxx/zcwjjd/t1349936.htm";
		String anchor="[证件]4月11日起外地车进京办证范围扩至六环";
		DetailInfo news = DetailPageExtractor.extract(anchor,url);
		System.out.println(news);
	}

	public static void testTitle4() throws Exception {
		String url ="http://finance.sina.com.cn/money/lcgh/20140418/094818843124.shtml";
		String anchor="月入四千只够日常开销 月光女神怎样存钱攒嫁妆]";
		DetailInfo news = DetailPageExtractor.extract(anchor,url);
		System.out.println(news);
	}
}
