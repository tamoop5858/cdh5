package detailPage;

import com.lietu.detailPage.JSDetailPage;
import com.lietu.detailPage.JSDetailPage.JSDetailInfo;

public class TestJSDetail {

	public static void main(String[] args) {
		String url="http://sc.sina.com.cn/news/z/2014-02-13/0832178700.html";
		JSDetailInfo info = JSDetailPage.getContent(url);
		//System.out.println(info.nextURL);
		System.out.println(info);
	}

}
