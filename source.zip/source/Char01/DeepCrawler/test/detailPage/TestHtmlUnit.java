package detailPage;

import java.io.IOException;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlAnchor;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

public class TestHtmlUnit {

	public static void main(String[] args) throws Exception {
		final WebClient webClient = new WebClient(BrowserVersion.CHROME);
		webClient.getOptions().setTimeout(20000);
		webClient.getOptions().setJavaScriptEnabled(true);
		webClient.getOptions().setThrowExceptionOnScriptError(false);

		String theURL = "http://disclosure.szse.cn/m/sme/drgg.htm";//"http://zfxxgk.beijing.gov.cn/columns/91/5/469206.html";//"http://zhengwu.beijing.gov.cn/gzdt/ldhd/default.htm";
		HtmlPage page = webClient.getPage(theURL);
		String theContent = page.getWebResponse().getContentAsString();
		System.out.println(theContent);
	}
	
	public static String getLink(HtmlAnchor jsAnchor) throws IOException {
		final HtmlPage newPage = jsAnchor.click();
		newPage.getUrl();
		
		String jsURL = newPage.executeJavaScript("document.location")
				.getJavaScriptResult().toString();
		return jsURL;
	}

}
