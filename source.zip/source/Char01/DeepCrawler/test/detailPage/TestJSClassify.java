package detailPage;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.lietu.detailPage.JSClassify;

//两种写法：<a href="#" onclick="myJsFunc();">Run JavaScript Code</a> 和
//<a href="javascript:void(0)" onclick="myJsFunc();">Run JavaScript Code</a>

public class TestJSClassify {

	public static void main(String[] args) throws IOException {
		String url = //"http://www.zhinengjiaotong.com/news/show-460566.html";
		"http://www.bjtzh.gov.cn/n95/n534/n700/c9169697/content.html";
				//"http://info.tangshan.gov.cn/";
				//"http://zhengwu.beijing.gov.cn/fggz/zfgz/t1201769.htm";
				//"http://sc.sina.com.cn/news/z/2014-02-13/0832178700.html";
		Document doc = Jsoup.connect(url).get();
		System.out.println(JSClassify.isJSPage(doc));
	}
	
	public static void testExtract() throws IOException {
		//String url="http://sc.sina.com.cn/news/z/2014-02-13/0832178700.html";
		String url = "http://www.zhinengjiaotong.com/news/show-460566.html";
				//"http://www.bjtzh.gov.cn/n95/n534/n700/c9169697/content.html";
		Document doc = Jsoup.connect(url).get();
		
		Elements links = doc.select("a[href]"); // 带有href属性的a标签
		for (Element link : links) { // 遍历每个链接
			String linkHref = link.attr("href"); // 得到href属性中的值，也就是url地址
			if(linkHref.indexOf("javascript:")>=0){
				System.out.println(linkHref);
			}
		}
	}
	
}
