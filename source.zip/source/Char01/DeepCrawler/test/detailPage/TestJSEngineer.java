package detailPage;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class TestJSEngineer {

	public static void main(String[] args) throws ScriptException {
		ScriptEngineManager factory = new ScriptEngineManager();
		ScriptEngine engine = factory.getEngineByName("JavaScript");

		String script = "var szzbAffiches=[[\"002168\",\"finalpage/2015-03-28/1200755819.PDF\",\"深圳惠程：长春高琦聚酰亚胺材料有限公司审计报告\",\"PDF\",\"2601\",\"2015-03-28\",\"2015-03-28 00:00\"]];";
		
		//"var total = 2;";  
		engine.eval(script+"var JavaArray = Java.to(szzbAffiches,\"java.lang.String[][]\");");  // 加载JavaScript
		java.lang.String[][] arr=(String[][]) engine.get("JavaArray");
		System.out.println(arr[0][1]);
	}

}
