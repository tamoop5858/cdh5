package detailPage;

import java.io.IOException;

import junit.framework.TestCase;

import org.apache.commons.lang3.StringUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.lietu.detailPage.DetailInfo;
import com.lietu.detailPage.DetailPageExtractor;

public class TestContentExtract extends TestCase{
	public static void main(String[] args) throws Exception {
		
		//testMeta();
		//testTrim();
	}
	
	public static void testTrim() {
		String content = "        4日，福州一辆车驶进竖立有智能化电子公交站牌的车站。";
		//System.out.println(content.trim());
		System.out.println(StringUtils.strip(content,"  "));
	}

	public static void testMeta() throws IOException {
		String url = //"http://www.bjtzh.gov.cn/n95/n534/n700/c9169697/content.html";
				"http://www.zhinengjiaotong.com/news/show-460225.html";
		Document doc = Jsoup.connect(url).get();
		Elements metaInfo = doc.select("meta");
		for (Element meta : metaInfo) {
			System.out.println("Name: " + meta.attr("name") + " - Content: "
					+ meta.attr("content"));
		}
		
		for (Element meta : metaInfo) {
			if("publishtime".equalsIgnoreCase(meta.attr("name"))){
				System.out.println(meta.attr("content"));
			}
			//System.out.println("Name: " + meta.attr("name") + " - Content: "
			//		+ meta.attr("content"));
		}
	}

	public static void testBasic() throws Exception {
		String url = //"http://www.bjtzh.gov.cn/n95/n534/n700/c9169697/content.html";
		 //"http://www.bjtzh.gov.cn/n95/n534/n700/c9175359/content.html";
				"http://www.zhinengjiaotong.com/news/show-459544.html";
				//"http://www.zhinengjiaotong.com/news/show-460245.html";
				//"http://news.bitauto.com/abroad/20140330/1106390606.html";
				//"http://news.bitauto.com/xcpd/20140219/1406353971.html";
		 ///"http://www.zhinengjiaotong.com/news/show-460192.html";
		 //"http://www.zhinengjiaotong.com/news/show-460548.html";
				//"http://www.zhinengjiaotong.com/news/show-460225.html";
		//"http://www.zhinengjiaotong.com/news/show-460493.html";
				//"http://www.zhinengjiaotong.com/news/show-460493.html";
				//"http://sc.sina.com.cn/news/z/2014-02-13/0832178700.html";
				//"http://www.zhinengjiaotong.com/news/show-459923.html";
		//"http://www.zhinengjiaotong.com/news/show-456707.html";
		//String content = HttpUtil.getHtml(new URL(url));
		// HttpUtil.downHtml(url);
		// DetailExtractor extarct = new DetailExtractor();
		DetailInfo ret = DetailPageExtractor.extract(url);
		System.out.println(ret);
	}

}
