package searchSpider;

import java.net.URL;

import util.AutoEncodeHttpUtil;
import util.HttpUtil;

public class TestGoogle {

	public static void main(String[] args) throws Exception {
		String url = "http://gg.tmeishi.com/simple/in.php?leix=search&tbm=isch&tbm=&q=sqlite&lr=&newwindow=1&hl=zh-CN&gbv=1&sei=7waBVtuvA-G4mAXqyqCACg";
				//"http://gg.tmeishi.com/simple/in.php?leix=search&newwindow=1&q=sqlite&tbm=&lr=&cr=&hl=zh-CN";
		// System.out.println(url);

		String content = AutoEncodeHttpUtil.getHtml(new URL(url));
				//HttpUtil.getContentGBK(url);
		System.out.println(content);

	}

}
