package searchSpider;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import junit.framework.TestCase;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.lietu.detailPage.DetailInfo;
import com.lietu.detailPage.DetailPageExtractor;

public class TestSearchResult extends TestCase {

	public static void main(String[] args) throws Exception {
		String searchWord="深圳泥石流";
		Document doc = BaiduSpider.search(searchWord);
		if(doc==null)
			return;
		String className = "t";
		Elements es = doc.getElementsByClass(className);
		//System.out.println(es);
		int i=0;
		for(Element e:es){
			i++;
			String url = e.child(0).attr("href");
			System.out.println(url);
			String title = e.text();
			System.out.println(title);
			String fileName="f:/test/"+i+".html";
			SearchResult.down2File(url,fileName);//TODO 提取新闻页面的正文
			//String content = down(url); //处理重定向
			//content = TextHtml.html2text(content);
			//writeString(content,"f:/test/"+i+".html");
		}
	}
	
	public static void testDb()throws Exception{
		Target target = new TargetDB(); //存入数据库
		String searchWord="深圳泥石流";
		Document doc = BaiduSpider.search(searchWord);
		if(doc==null)
			return;
		String className = "t";
		Elements es = doc.getElementsByClass(className);
		//System.out.println(es);
		int i=0;
		for(Element e:es){
			i++;
			String url = e.child(0).attr("href");
			System.out.println(url);
			String title = e.text();
			System.out.println(title);
			DetailInfo ret = DetailPageExtractor.extract(url);
			System.out.println(ret);
			target.insertResult(title, ret.content);
			//String newscontent = AutoEncodeHttpUtil.getHtml(new URL(url));

			//System.out.println(newscontent);
		}
	}
	
	public static void writeString(String s, String savePath) throws IOException {
		File f = new File(savePath);
		FileWriter fw = new FileWriter(f);
		BufferedWriter bw = new BufferedWriter(fw);
		bw.write(s);
		bw.close();
	}

	public static void testBasic()throws Exception{
		String searchWord="深圳泥石流";
		Document doc = BaiduSpider.search(searchWord);
		if(doc==null)
			return;
		String className = "t";
		Elements es = doc.getElementsByClass(className);
		//System.out.println(es);
		int i=0;
		for(Element e:es){
			i++;
			String url = e.child(0).attr("href");
			System.out.println(i +" " +url);
			String title = e.text();
			System.out.println(title);
			//String newscontent = AutoEncodeHttpUtil.getHtml(new URL(url));

			//System.out.println(newscontent);
			//String ret = HttpUtil.getContentGBK(url);
		}
	}

}
