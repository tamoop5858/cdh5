

import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import edu.uci.ics.crawler4j.crawler.Page;
import edu.uci.ics.crawler4j.crawler.WebCrawler;
import edu.uci.ics.crawler4j.parser.HtmlParseData;
import edu.uci.ics.crawler4j.url.WebURL;

public class MyCrawler extends WebCrawler {
	private static double linkTextRadio = 0.25; 

	@Override
	public boolean shouldVisit(WebURL url) {
//		String href = url.getURL().toLowerCase();
//		return !FILTERS.matcher(href).matches()
//				&& href.startsWith("http://www.ics.uci.edu/");
		return false;
	}

	/**
	 * * This function is called when a page is fetched and ready * to be
	 * processed by your program.
	 */
	@Override
	public void visit(Page page) {
		String url = page.getWebURL().getURL();
		System.out.println("URL: " + url);
		if (page.getParseData() instanceof HtmlParseData) {
			HtmlParseData htmlParseData = (HtmlParseData) page.getParseData();
			String html = htmlParseData.getHtml();
			Document doc = Jsoup.parse(html);
			Element body = doc.getElementsByTag("body").first();
			drawCon(body);
			System.out.println(body.text());
		}
	}
	public static int calcLinks(Element node) {
		int num=node.getElementsByTag("a").size();
		return num;
	}
	public static double calcWords(Element node) {
		int num=node.text().length();
		if (num == 0) {
			return 1 + linkTextRadio;
		} else {
			return num;
		}
	}
	public static int calcSign(Element node) {
		String[] sign = { ",", ";", ".", "\"", "'", "\\?", "��", ":", "��" };
		int num=0;
		for(String str:sign){
			num+=node.text().split(str).length-1;
		}
		return num;
	}
	public static void drawCon(Element node) {
		if(node==null){
			return;
		}else{
			int links; // ������
			double words; // ���ֳ���
			int signs; // ��ų��ֵ����
			double cellRatio;
			for(Element current:node.children() ){
				if (!current.hasText()) {
					//ɾ������ڵ�
					current.remove();
				} else{
					links=calcLinks(current);
					words=calcWords(current);
					cellRatio=links/words;
					signs=calcSign(current);
					if(cellRatio>linkTextRadio){
						current.remove();
					}else if(signs<1){
						current.remove();
					}else{
						drawCon(current);
					}
				}
			}
		}
	}
}