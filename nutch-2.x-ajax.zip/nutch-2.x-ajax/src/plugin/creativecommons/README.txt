Support for crawling and searching Creative-Commons licensed content. 
