package com.futuredata.bigdata.framework.beans.factory;

public interface BeanFactory {

}
