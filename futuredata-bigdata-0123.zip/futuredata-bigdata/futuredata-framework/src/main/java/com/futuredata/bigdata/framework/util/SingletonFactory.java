package com.futuredata.bigdata.framework.util;

public final class SingletonFactory {

}
