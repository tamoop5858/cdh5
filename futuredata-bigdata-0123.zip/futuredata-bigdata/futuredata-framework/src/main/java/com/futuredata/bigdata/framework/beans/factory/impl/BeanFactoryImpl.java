package com.futuredata.bigdata.framework.beans.factory.impl;

public class BeanFactoryImpl {

}
