package com.futuredata.bigdata.gora.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.ByteBuffer;

import org.apache.gora.query.Result;
import org.apache.nutch.storage.UrlInfo;
import org.apache.nutch.storage.WebPage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.futuredata.bigdata.gora.dao.UrlInfoDao;
import com.futuredata.bigdata.gora.dao.WebPageInfoDao;
import com.futuredata.bigdata.gora.output.OutputFileManager;

public class WebPageService {

    private static final Logger log = LoggerFactory.getLogger(WebPageService.class);

    private UrlInfoDao urlInfoDao;
    private WebPageInfoDao webPageInfoDao;
    
    // operate URL info
    public void queryKey(String key) {

	UrlInfo uriInfo = urlInfoDao.queryByKey(key);

	printUrlInfo(uriInfo);
    }

    // operate URL info
    public void queryAll() throws IOException, Exception {

	Result<String, UrlInfo> result = urlInfoDao.queryAll();

	printUrlInfo(result);
    }

    // operate URL info
    public void deleteKey(String key) throws Exception {

	urlInfoDao.deleteByKey(key);
    }

    // operate URL info
    public void deleteAll() throws Exception {

	urlInfoDao.deleteAll();
    }

    // operate webPage info
    public void getKey(String key) {

	WebPage webPage = webPageInfoDao.queryByKey(key);

	printWebPage(webPage);
    }

    // operate webPage info
    public void getAll() throws Exception {

	Result<String, WebPage> webPage = webPageInfoDao.queryAll();

	printWebPage(webPage);
    }

    public void printCrawledWebPage() throws Exception {

	// 1. read crawled urlInfo by urlInfoDao
	Result<String, UrlInfo> urlInfoResult = urlInfoDao.queryAll();

	while (urlInfoResult.next()) {

	    String urlInfoKey = urlInfoResult.getKey();
	    UrlInfo urlInfo = urlInfoResult.get();

	    // 2. read crawled webPageinfo by webPageInfoDao
	    // TODO
	    String webPageInfoKey = urlInfoKey;

	    WebPage webPage = webPageInfoDao.queryByKey(webPageInfoKey);

	    // 3. write crawled webPageinfo by webPageInfoDao
	    writeWebPageToFile(webPageInfoKey, webPage);

	    // 4. delete crawled urlInfo by urlInfoDao
	    urlInfoDao.deleteByKey(urlInfoKey);
	}
    }

    public void init() {

	urlInfoDao = new UrlInfoDao();
	webPageInfoDao = new WebPageInfoDao();
    }

    public void destroy() {

	urlInfoDao.destroy();

	webPageInfoDao.destroy();
    }

    private void writeWebPageToFile(String webPageKey, WebPage webPage) throws Exception {

	OutputFileManager outputFileManager = new OutputFileManager();

	String filePath = outputFileManager.getOutputFilePath(webPageKey);

	ByteBuffer contentByteBuffer = webPage.getContent();

	File file = new File(filePath);

	try (PrintStream ps = new PrintStream(new FileOutputStream(file))) {

	    ps.append(new String(contentByteBuffer.array()));

	} catch (FileNotFoundException e) {

	    e.printStackTrace();
	}
    }

    private void printUrlInfo(Result<String, UrlInfo> result) throws IOException, Exception {

	while (result.next()) {
	    // advances the Result object and breaks if at end

	    // obtain current key
	    String resultKey = result.getKey();
	    // obtain current value object
	    UrlInfo resultUrlInfo = result.get();

	    // print the results
	    System.out.println(resultKey + ":");

	    printUrlInfo(resultUrlInfo);
	}

	System.out.println("Number of UrlInfo from the query:" + result.getOffset());
    }

    private void printUrlInfo(UrlInfo urlinfo) {

	if (urlinfo == null) {

	    System.out.println("No result to show");
	} else {

	    System.out.println(urlinfo.toString());
	}
    }

    private void printWebPage(Result<String, WebPage> result) throws Exception {

	while (result.next()) {
	    // advances the Result object and breaks if at end

	    // obtain current key
	    String resultKey = result.getKey();
	    // obtain current value object
	    WebPage webPage = result.get();

	    // print the results
	    System.out.println(resultKey + ":");

	    printWebPage(webPage);
	}

	System.out.println("Number of UrlInfo from the query:" + result.getOffset());
    }

    private void printWebPage(WebPage webpage) {

	if (webpage == null) {

	    System.out.println("No result to show");
	} else {

	    ByteBuffer contentByteBuffer = webpage.getContent();

	    if (contentByteBuffer == null) {

		System.out.println("Content IS null");
	    } else {

		System.out.println(new String(contentByteBuffer.array()));
	    }
	}
    }
}
