package com.futuredata.bigdata.gora.action;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.futuredata.bigdata.gora.service.WebPageService;

public class WebPageAction {

    private static final Logger log = LoggerFactory.getLogger(WebPageAction.class);

    public void execute(String[] args) {

	String para0 = args[0];
	String para1 = args[1];

	WebPageService service = new WebPageService();

	try {

	    service.init();

	    if ("-query".equals(para0) && "key".equals(para1)) {

		service.queryKey(para1);

	    } else if ("-query".equals(para0) && "all".equals(para1)) {

		service.queryAll();

	    } else if ("-delete".equals(para0) && "key".equals(para1)) {

		service.deleteKey(para1);

	    } else if ("-delete".equals(para0) && "all".equals(para1)) {

		service.deleteAll();

	    } else if ("-get".equals(para0) && "key".equals(para1)) {

		service.getKey(para1);

	    } else if ("-get".equals(para0) && "all".equals(para1)) {

		service.getAll();

	    } else if ("-print".equals(para0)) {

		// write web page to file
		service.printCrawledWebPage();

	    } else {

		System.err.println(USAGE);
		System.exit(1);
	    }

	} catch (Exception e) {

	    // TODO Auto-generated catch block
	    e.printStackTrace();
	} finally {

	    service.destroy();
	}
    }

    public static void main(String[] args) throws Exception {

	WebPageAction action = new WebPageAction();

	action.execute(args);
    }

    private static final String USAGE = "LogManager -query key    \n" + "           -query all    \n"
	    + "           -delete key    \n" + "           -delete all    \n" + "           -get key     \n"
	    + "           -get all    \n" + "           -print    \n";

}
