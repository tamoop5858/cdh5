package com.futuredata.bigdata.gora.output;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.futuredata.bigdata.gora.config.ConfigManager;
import com.futuredata.bigdata.gora.config.FuturedataGoraConfig;

public class OutputFileManager {

    public String getOutputFilePath(String defaultFileName) throws Exception {

	FuturedataGoraConfig config = ConfigManager.getInstance().getConfig();

	String fileName = getFileNameByRule(defaultFileName);

	return config.getOutputFilepath() + "/" + fileName;
    }

    private String getFileNameByRule(String fileName) throws Exception {

	if (fileName == null || fileName == "") {

	    SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
	    fileName = df.format(new Date());
	} else {
	    fileName = convertUrlToFileName(fileName);
	}

	return fileName + ".html";
    }

    private String convertUrlToFileName(String url) throws Exception {

	String filename = URLEncoder.encode(url, "UTF-8");

	return filename;
    }
}
