package futuredata.task;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.concurrent.Callable;
import futuredata.config.HttpConfig;
import futuredata.search.EdinetSearcher;
import futuredata.search.NegaSearcher;

public class CrawlerTask implements Callable<Boolean> {

    private HttpConfig httpConfig;

    private WebPage webpage;

    public CrawlerTask(HttpConfig httpConfig, String saveFilePath) {

        this.httpConfig = httpConfig;

        this.webpage = new WebPage();

        webpage.setSavePath(saveFilePath);
        webpage.setStatus(false);
    }

    @Override
    public Boolean call() {

        try {

            // TimeUnit.MILLISECONDS.sleep((int) (Math.random() * 1000));
            readWebPage(httpConfig, webpage);

            saveWebPage(webpage);

        } catch (Exception e) {

            e.printStackTrace();
        }

        return webpage.status;
    }

    private void readWebPage(HttpConfig httpConfig, WebPage webpage) {

        String content = "";

        EdinetSearcher edinetSearcher = new EdinetSearcher();

        NegaSearcher negaSearcher = new NegaSearcher();

        if ("get".equals(httpConfig.getHttpMethod())) {

            content = edinetSearcher.search(httpConfig);

        } else if ("post".equals(httpConfig.getHttpMethod())) {

            content = negaSearcher.search(httpConfig);
        }

        webpage.setContent(content);
    }

    private void saveWebPage(WebPage webpage) {

        if (webpage.getContent().isEmpty()) {

            webpage.setStatus(false);
        } else {

            File file = new File(webpage.getSavePath());

            try (PrintStream ps = new PrintStream(new FileOutputStream(file))) {

                ps.append(webpage.getContent());

                webpage.setStatus(true);

            } catch (FileNotFoundException e) {

                e.printStackTrace();

                webpage.setStatus(false);
            }
        }

    }

    public class WebPage {

        private Boolean status;

        private String content;

        private String savePath;

        public String getSavePath() {
            return savePath;
        }

        public void setSavePath(String savePath) {
            this.savePath = savePath;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public Boolean getStatus() {
            return status;
        }

        public void setStatus(Boolean status) {
            this.status = status;
        }
    }
}
