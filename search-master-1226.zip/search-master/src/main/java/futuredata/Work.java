package futuredata;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import futuredata.config.Config;
import futuredata.config.ConfigManager;
import futuredata.config.HttpConfig;
import futuredata.task.CrawlerTask;
import futuredata.thread.ExecutorProcessPool;

public class Work {

    private static final Logger LOG = LoggerFactory.getLogger(Work.class);

    public static void main(String args[]) {

        Work w = new Work();
        w.crealerWork();
    }

    public void crealerWork() {

        FileManager fileManager = new FileManager();
        String inputFilePath = fileManager.getInputPath();
        String outputDirectoryPath = fileManager.getOutputPath();

        Config config = ConfigManager.converyXmlToJavaBean(inputFilePath, Config.class);

        ExecutorProcessPool pool = ExecutorProcessPool.getInstance();

        List<Future<?>> futureList = new ArrayList<Future<?>>();

        for (HttpConfig httpConfig : config.getHttpConfigList()) {

            String saveFilePath = outputDirectoryPath + "\\" + httpConfig.getSaveName() + ".txt";

            Future<?> future = pool.submit(new CrawlerTask(httpConfig, saveFilePath));

            futureList.add(future);
        }

        int totalCount = config.getHttpConfigList().size();
        int correntCount = 0;

        for (Future<?> future : futureList) {

            try {
                if ((Boolean) future.get()) {

                    correntCount++;
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
        }

        pool.shutdown();

        LOG.info("処理件数:" + totalCount + "、正常件数:" + correntCount + "、異常件数:" + (totalCount - correntCount));
    }
}
